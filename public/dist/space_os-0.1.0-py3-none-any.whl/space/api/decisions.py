from typing import Any

from fastapi import APIRouter, Request

from space.api.deps import resolve_identity
from space.api.errors import error_boundary
from space.api.types import DecisionCreate, DecisionView
from space.core.errors import ValidationError
from space.core.types import AgentId, DecisionId
from space.os import agents, decisions, projects

router = APIRouter(prefix="/api/decisions", tags=["decisions"])


def _view(d, agent_map: dict[AgentId, str]) -> dict[str, Any]:
    return {
        "id": d.id,
        "agent_id": d.agent_id,
        "identity": agent_map.get(d.agent_id, "unknown"),
        "content": d.content,
        "rationale": d.rationale,
        "images": d.images,
        "created_at": d.created_at,
    }


@router.get("", response_model=list[DecisionView])
@error_boundary
def list_decisions():
    items = decisions.fetch()
    agent_ids = list({d.agent_id for d in items})
    agent_batch = agents.batch_get(agent_ids)
    agent_map = {aid: a.identity for aid, a in agent_batch.items()}
    return [_view(d, agent_map) for d in items]


@router.get("/{decision_id}", response_model=DecisionView)
@error_boundary
def get_decision(decision_id: str):
    d = decisions.get(DecisionId(decision_id))
    agent = agents.get(d.agent_id)
    return _view(d, {d.agent_id: agent.identity if agent else "unknown"})


@router.post("")
@error_boundary
def create_decision(request: Request, body: DecisionCreate):
    ident = resolve_identity(request)
    if not ident:
        raise ValidationError("Identity required to create decision")

    agent = agents.get(ident)
    project_id = projects.require_scope()
    decision = decisions.create(
        project_id,
        agent.id,
        body.content,
        body.rationale,
        images=body.images,
    )
    return _view(decision, {agent.id: agent.identity})


@router.post("/{decision_id}/archive")
@error_boundary
def archive_decision(decision_id: str):
    d = decisions.archive(DecisionId(decision_id))
    agent = agents.get(d.agent_id)
    return _view(d, {d.agent_id: agent.identity if agent else "unknown"})


@router.delete("/{decision_id}")
@error_boundary
def delete_decision(decision_id: str):
    decisions.delete(DecisionId(decision_id))
    return {"ok": True}


@router.post("/{decision_id}/action")
@error_boundary
def action_decision(decision_id: str):
    d = decisions.action(DecisionId(decision_id))
    agent = agents.get(d.agent_id)
    return _view(d, {d.agent_id: agent.identity if agent else "unknown"})


@router.post("/{decision_id}/reject")
@error_boundary
def reject_decision(decision_id: str):
    d = decisions.reject(DecisionId(decision_id))
    agent = agents.get(d.agent_id)
    return _view(d, {d.agent_id: agent.identity if agent else "unknown"})
