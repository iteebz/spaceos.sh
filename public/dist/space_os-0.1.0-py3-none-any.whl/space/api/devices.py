from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from space.core.models import Agent
from space.lib import devices, store
from space.os import agents

router = APIRouter(prefix="/api", tags=["devices"])


class WhoAmIResponse(BaseModel):
    identity: str
    agent_id: str
    device_id: str | None = None
    device_name: str | None = None


class HumanOption(BaseModel):
    identity: str
    agent_id: str


class UnregisteredResponse(BaseModel):
    registered: bool = False
    your_ip: str
    humans: list[HumanOption]


class RegisterDeviceRequest(BaseModel):
    owner_identity: str
    name: str | None = None


class RegisterDeviceResponse(BaseModel):
    device_id: str
    owner_id: str
    tailscale_ip: str
    name: str | None


@router.get("/whoami")
def whoami(request: Request) -> WhoAmIResponse | UnregisteredResponse:
    client_ip = request.client.host if request.client else None
    if not client_ip:
        raise HTTPException(status_code=400, detail="Could not determine client IP")

    device = devices.get_by_ip(client_ip)
    if device:
        agent = agents.get(device.owner_id)
        return WhoAmIResponse(
            identity=agent.identity,
            agent_id=agent.id,
            device_id=device.id,
            device_name=device.name,
        )

    humans = agents.fetch(type="human")
    if len(humans) == 1:
        device = devices.register(owner_id=humans[0].id, tailscale_ip=client_ip)
        return WhoAmIResponse(
            identity=humans[0].identity,
            agent_id=humans[0].id,
            device_id=device.id,
            device_name=device.name,
        )

    return UnregisteredResponse(
        your_ip=client_ip,
        humans=[HumanOption(identity=h.identity, agent_id=h.id) for h in humans],
    )


class PushTokenRequest(BaseModel):
    push_token: str


@router.post("/devices/push-token")
def update_push_token(request: Request, body: PushTokenRequest):
    client_ip = request.client.host if request.client else None
    if not client_ip:
        raise HTTPException(status_code=400, detail="Could not determine client IP")

    device = devices.get_by_ip(client_ip)
    if not device:
        raise HTTPException(status_code=404, detail="Device not registered")

    devices.update_push_token(device.id, body.push_token)
    return {"ok": True}


@router.post("/devices/register", response_model=RegisterDeviceResponse)
def register_device(request: Request, body: RegisterDeviceRequest):
    client_ip = request.client.host if request.client else None
    if not client_ip:
        raise HTTPException(status_code=400, detail="Could not determine client IP")

    try:
        agent = store.resolve(body.owner_identity, "agents", Agent)
    except Exception as e:
        raise HTTPException(
            status_code=404, detail=f"Agent not found: {body.owner_identity}"
        ) from e

    device = devices.register(
        owner_id=agent.id,
        tailscale_ip=client_ip,
        name=body.name,
    )

    return RegisterDeviceResponse(
        device_id=device.id,
        owner_id=device.owner_id,
        tailscale_ip=device.tailscale_ip,
        name=device.name,
    )
