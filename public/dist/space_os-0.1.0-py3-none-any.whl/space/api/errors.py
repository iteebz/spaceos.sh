import inspect
from collections.abc import Callable
from functools import wraps
from typing import Any

from fastapi import HTTPException

from space.core.errors import SpaceError
from space.lib import logs


def _handle_error(e: Exception, func_name: str) -> HTTPException:
    if isinstance(e, SpaceError):
        return HTTPException(status_code=e.status_code, detail=str(e))
    if isinstance(e, ValueError):
        return HTTPException(status_code=400, detail=str(e))
    logs.write("api", e, func_name)
    return HTTPException(status_code=500, detail="Internal server error")


def error_boundary[F: Callable[..., Any]](func: F) -> F:
    @wraps(func)
    async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return await func(*args, **kwargs)
        except HTTPException:
            raise
        except Exception as e:
            raise _handle_error(e, func.__name__) from e

    @wraps(func)
    def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return func(*args, **kwargs)
        except HTTPException:
            raise
        except Exception as e:
            raise _handle_error(e, func.__name__) from e

    if inspect.iscoroutinefunction(func):
        return async_wrapper  # type: ignore[return-value]
    return sync_wrapper  # type: ignore[return-value]
