from fastapi import APIRouter

from space.api.errors import error_boundary
from space.api.types import CamelModel
from space.os import search

router = APIRouter(prefix="/api/search", tags=["search"])


class SearchResultView(CamelModel):
    source: str
    content: str
    reference: str
    timestamp: str | None = None


@router.get("", response_model=list[SearchResultView])
@error_boundary
def query(q: str, scope: str = "all", limit: int = 20):
    results = search.query(q, scope=scope, limit=limit)
    return [
        SearchResultView(
            source=r.source,
            content=r.content,
            reference=r.reference,
            timestamp=r.timestamp,
        )
        for r in results
    ]
