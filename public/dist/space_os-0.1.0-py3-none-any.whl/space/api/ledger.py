from fastapi import APIRouter, HTTPException

from space.api.errors import error_boundary
from space.api.types import LedgerItemView, ThreadView
from space.os import ledger

router = APIRouter(prefix="/api/ledger", tags=["ledger"])


def _to_view(item: ledger.LedgerItem) -> LedgerItemView:
    return LedgerItemView(
        type=item.type,
        id=item.id,
        content=item.content,
        agent_id=item.agent_id,
        identity=item.identity,
        created_at=item.created_at,
        rationale=item.rationale,
        status=item.status,
        decision_id=item.decision_id,
        decision_content=item.decision_content,
    )


@router.get("", response_model=list[LedgerItemView])
@error_boundary
def recent(limit: int = 50):
    return [_to_view(item) for item in ledger.fetch(limit=limit)]


@router.get("/thread/{item_type}/{item_id}", response_model=ThreadView)
@error_boundary
def get_thread(item_type: str, item_id: str):
    if item_type not in ("decision", "insight", "task"):
        raise HTTPException(status_code=400, detail="Invalid type")
    item, items = ledger.thread(item_type, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Not found")
    return ThreadView(item=_to_view(item), items=[_to_view(i) for i in items])
