import contextlib
import os
import time
from pathlib import Path
from typing import Any

import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from starlette.middleware.base import BaseHTTPMiddleware

from space.api import (
    agents,
    decisions,
    devices,
    email,
    insights,
    ledger,
    projects,
    realtime,
    replies,
    search,
    spawns,
    stats,
    swarm,
    tasks,
    upload,
)
from space.core.types import ProjectId
from space.lib import backup, logs, store
from space.os import projects as projects_os

START_TIME = time.time()


class ProjectScopeMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        project_id = request.headers.get("X-Project-Id")
        if project_id:
            projects_os.set_request_scope(ProjectId(project_id))
        try:
            return await call_next(request)
        finally:
            projects_os.set_request_scope(None)


@contextlib.asynccontextmanager
async def lifespan(_app: FastAPI):
    logs.reset("api")
    yield


app = FastAPI(title="Space API", lifespan=lifespan)

app.add_middleware(ProjectScopeMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


app.include_router(agents.router)
app.include_router(devices.router)
app.include_router(email.router)
app.include_router(ledger.router)
app.include_router(decisions.router)
app.include_router(insights.router)
app.include_router(projects.router)
app.include_router(realtime.router)
app.include_router(replies.router)
app.include_router(search.router)
app.include_router(spawns.router)
app.include_router(stats.router)
app.include_router(swarm.router)
app.include_router(tasks.router)
app.include_router(upload.router)


class ClientLogEntry(BaseModel):
    level: str
    message: str
    context: dict[str, Any] | None = None
    timestamp: str | None = None


@app.post("/api/logs")
def client_log(entries: list[ClientLogEntry]):
    return logs.client([entry.model_dump() for entry in entries])


@app.post("/api/logs/clear")
def clear_app_log():
    return logs.clear("app")


@app.get("/api/health")
def health():
    uptime_seconds = int(time.time() - START_TIME)
    db_ok = False
    db_error = None

    try:
        with store.ensure() as conn:
            conn.execute("SELECT 1").fetchone()
        db_ok = True
    except Exception as e:
        db_error = str(e)

    return {
        "uptime_seconds": uptime_seconds,
        "database": {
            "connected": db_ok,
            "error": db_error,
        },
    }


@app.get("/api/backup")
def backup_status():
    backup_dir = Path.home() / ".space_backups" / "data"
    if not backup_dir.exists():
        return {"last_backup": None}

    snapshots = sorted(backup_dir.iterdir(), reverse=True)
    if not snapshots:
        return {"last_backup": None}

    return {"last_backup": snapshots[0].name}


@app.post("/api/backup")
def run():
    try:
        result = backup.execute()
        return {"ok": True, **result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


def main():
    reload = os.environ.get("SPACE_API_RELOAD", "1") == "1"
    uvicorn.run(
        "space.api.main:app",
        host="0.0.0.0",
        port=8228,
        log_level="info",
        access_log=False,
        reload=reload,
        reload_includes=["space/**/*.py"] if reload else None,
        reload_excludes=["*.db", "*.db-*"] if reload else None,
        reload_delay=0.5,
        timeout_keep_alive=320,
        timeout_graceful_shutdown=5,
        limit_concurrency=100,
    )


if __name__ == "__main__":
    main()
