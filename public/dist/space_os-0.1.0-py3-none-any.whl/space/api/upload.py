import time
import uuid
from pathlib import Path

from fastapi import APIRouter, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response

from space.api.errors import error_boundary
from space.core.types import AgentId
from space.lib import paths
from space.os import agents


def _resolve_identity(entity_id: str) -> tuple[str, str]:
    agent = agents.get(AgentId(entity_id))
    return agent.identity, agent.type


router = APIRouter(prefix="/api/upload", tags=["upload"])


MAX_FILE_SIZE = 10 * 1024 * 1024
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp"}


@router.post("/image")
async def upload_image(file: UploadFile):
    try:
        uploads = paths.dot_space() / "images" / "uploads"
        uploads.mkdir(parents=True, exist_ok=True)

        suffix = Path(file.filename or "image.jpg").suffix.lower()
        if suffix not in ALLOWED_EXTENSIONS:
            raise HTTPException(status_code=400, detail="Invalid file type")

        content = await file.read(MAX_FILE_SIZE + 1)
        if len(content) > MAX_FILE_SIZE:
            raise HTTPException(status_code=413, detail="File too large (max 10MB)")

        file_id = str(uuid.uuid4())[:8]
        filename = f"{file_id}{suffix}"
        filepath = uploads / filename
        filepath.write_bytes(content)

        return {"filename": filename}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/avatar/{entity_id}")
@error_boundary
async def upload_avatar(entity_id: str, file: UploadFile):
    agent = agents.get(AgentId(entity_id))

    suffix = Path(file.filename or "avatar.png").suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=400, detail="Invalid file type")

    content = await file.read(MAX_FILE_SIZE + 1)
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(status_code=413, detail="File too large (max 10MB)")

    avatars = paths.dot_space() / "images" / "avatars"
    avatars.mkdir(parents=True, exist_ok=True)

    for old in avatars.glob(f"{agent.identity}.*"):
        old.unlink()

    timestamp = int(time.time())
    filename = f"{agent.identity}.{timestamp}{suffix}"
    filepath = avatars / filename
    filepath.write_bytes(content)

    agents.update(agent.id, avatar_path=filename)

    return {"filename": filename, "entity_id": entity_id}


@router.delete("/avatar/{entity_id}")
@error_boundary
async def delete_avatar(entity_id: str):
    agent = agents.get(AgentId(entity_id))

    avatars = paths.dot_space() / "images" / "avatars"
    matches = list(avatars.glob(f"{agent.identity}.*"))
    if not matches:
        raise HTTPException(status_code=404, detail="Avatar not found")
    for path in matches:
        path.unlink()

    agents.update(agent.id, avatar_path="")

    return {"deleted": entity_id}


@router.head("/avatar/{entity_id}")
@error_boundary
async def check_avatar(entity_id: str):
    identity, _ = _resolve_identity(entity_id)
    avatar = paths.avatar_path(identity)
    if not avatar:
        raise HTTPException(status_code=404, detail="Avatar not found")
    return Response(status_code=200, headers={"Cache-Control": "max-age=31536000, immutable"})


@router.get("/avatar/{entity_id}")
@error_boundary
async def get_avatar(entity_id: str):
    identity, _ = _resolve_identity(entity_id)
    avatar = paths.avatar_path(identity)
    if not avatar:
        raise HTTPException(status_code=404, detail="Avatar not found")
    return FileResponse(
        avatar, media_type="image/*", headers={"Cache-Control": "max-age=31536000, immutable"}
    )


@router.get("/image/{filename}")
async def get_image(filename: str):
    filename = Path(filename).name
    if not filename.replace("-", "").replace(".", "").replace("_", "").isalnum():
        raise HTTPException(status_code=400, detail="Invalid filename")

    for base in (paths.dot_space() / "images" / "uploads", paths.dot_space() / "images"):
        filepath = base / filename
        if filepath.exists() and filepath.is_relative_to(base):
            return FileResponse(filepath, media_type="image/*")

    raise HTTPException(status_code=404, detail="Image not found")
