import asyncio
import contextlib
import logging
import re
from dataclasses import dataclass, field
from typing import Any

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from space.core.errors import NotFoundError
from space.core.types import SpawnId
from space.os import spawns

router = APIRouter()
logger = logging.getLogger(__name__)

PING_INTERVAL = 15.0
PONG_TIMEOUT = 5.0
MAX_OUTBOUND_QUEUE = 500
HEARTBEAT_INTERVAL = 5.0


@dataclass
class Subscription:
    topic: str
    task: asyncio.Task[None]
    cancel_event: asyncio.Event


@dataclass
class Connection:
    websocket: WebSocket
    subscriptions: dict[str, Subscription] = field(default_factory=dict)
    outbound: asyncio.Queue[dict[str, Any]] = field(
        default_factory=lambda: asyncio.Queue[dict[str, Any]](maxsize=MAX_OUTBOUND_QUEUE)
    )
    last_pong: float = 0.0
    closed: bool = False


TOPIC_PATTERNS = {
    "spawn_trace": re.compile(r"^spawns\.([a-zA-Z0-9_-]+)\.trace$"),
    "spawns_tail": re.compile(r"^spawns\.active\.tail$"),
}


def parse_topic(topic: str) -> tuple[str, str | None] | None:
    for topic_type, pattern in TOPIC_PATTERNS.items():
        match = pattern.match(topic)
        if match:
            groups = match.groups()
            return topic_type, groups[0] if groups else None
    return None


async def send_safe(conn: Connection, msg: dict[str, Any]) -> bool:
    if conn.closed:
        return False
    try:
        conn.outbound.put_nowait(msg)
        return True
    except asyncio.QueueFull:
        try:
            conn.outbound.get_nowait()
            conn.outbound.put_nowait(msg)
            logger.warning("Outbound queue overflow, dropped oldest message")
            return True
        except Exception:
            return False


async def writer_loop(conn: Connection):
    try:
        while not conn.closed:
            try:
                msg = await asyncio.wait_for(conn.outbound.get(), timeout=0.1)
                await conn.websocket.send_json(msg)
            except TimeoutError:
                continue
            except WebSocketDisconnect:
                break
            except Exception as e:
                logger.error(f"Writer error: {e}")
                break
    finally:
        conn.closed = True


async def ping_loop(conn: Connection):
    loop = asyncio.get_event_loop()
    try:
        while not conn.closed:
            await asyncio.sleep(PING_INTERVAL)
            if conn.closed:
                break
            await send_safe(conn, {"type": "ping"})
            await asyncio.sleep(PONG_TIMEOUT)
            if loop.time() - conn.last_pong > PING_INTERVAL + PONG_TIMEOUT:
                logger.warning("Pong timeout, closing connection")
                conn.closed = True
                break
    except Exception as e:
        logger.error(f"Ping loop error: {e}")
        conn.closed = True


async def stream_spawn_trace(
    conn: Connection,
    topic: str,
    cancel_event: asyncio.Event,
    spawn_id: str,
    last_id: str | None,
):
    try:
        spawn = spawns.get(SpawnId(spawn_id))
    except NotFoundError:
        await send_safe(
            conn,
            {
                "type": "error",
                "topic": topic,
                "code": "not_found",
                "message": f"Spawn {spawn_id} not found",
            },
        )
        return

    last_seq = 0
    if last_id and last_id.startswith(f"spawn_{spawn_id[:8]}_"):
        with contextlib.suppress(ValueError):
            last_seq = int(last_id.split("_")[-1])

    seq = 0
    try:
        async for event in spawns.stream_live(spawn):
            if cancel_event.is_set() or conn.closed:
                break

            seq += 1
            if seq <= last_seq:
                continue

            if event.get("type") == "keepalive":
                continue

            event_id = f"spawn_{spawn_id[:8]}_{seq}"
            await send_safe(
                conn,
                {
                    "type": "event",
                    "topic": topic,
                    "id": event_id,
                    "data": event,
                },
            )

            if event.get("type") in ("summary", "error"):
                break
    except Exception as e:
        logger.error(f"Spawn stream error: {e}")
        await send_safe(
            conn, {"type": "error", "topic": topic, "code": "stream_error", "message": str(e)}
        )


async def stream_spawns_tail(
    conn: Connection,
    topic: str,
    cancel_event: asyncio.Event,
):
    seq = 0
    try:
        async for event in spawns.stream_all_active():
            if cancel_event.is_set() or conn.closed:
                break

            if event.get("type") == "keepalive":
                continue

            seq += 1
            event_id = f"tail_{seq}"
            await send_safe(
                conn,
                {
                    "type": "event",
                    "topic": topic,
                    "id": event_id,
                    "data": event,
                },
            )
    except Exception as e:
        logger.error(f"Tail stream error: {e}")
        await send_safe(
            conn, {"type": "error", "topic": topic, "code": "stream_error", "message": str(e)}
        )


async def handle_subscribe(conn: Connection, topic: str, last_id: str | None):
    if topic in conn.subscriptions:
        await send_safe(conn, {"type": "subscribed", "topic": topic})
        return

    parsed = parse_topic(topic)
    if not parsed:
        await send_safe(
            conn,
            {
                "type": "error",
                "topic": topic,
                "code": "invalid_topic",
                "message": f"Invalid topic: {topic}",
            },
        )
        return

    topic_type, resource_id = parsed
    cancel_event = asyncio.Event()

    if topic_type == "spawn_trace" and resource_id:
        task = asyncio.create_task(
            stream_spawn_trace(conn, topic, cancel_event, resource_id, last_id)
        )
    elif topic_type == "spawns_tail":
        task = asyncio.create_task(stream_spawns_tail(conn, topic, cancel_event))
    else:
        await send_safe(
            conn,
            {
                "type": "error",
                "topic": topic,
                "code": "invalid_topic",
                "message": f"Unknown topic type: {topic_type}",
            },
        )
        return

    sub = Subscription(topic=topic, task=task, cancel_event=cancel_event)
    conn.subscriptions[topic] = sub
    await send_safe(conn, {"type": "subscribed", "topic": topic})


async def handle_unsubscribe(conn: Connection, topic: str):
    sub = conn.subscriptions.pop(topic, None)
    if sub:
        sub.cancel_event.set()
        sub.task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await sub.task
    await send_safe(conn, {"type": "unsubscribed", "topic": topic})


async def cleanup_connection(conn: Connection):
    conn.closed = True
    for sub in list(conn.subscriptions.values()):
        sub.cancel_event.set()
        sub.task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await sub.task
    conn.subscriptions.clear()


@router.websocket("/api/realtime")
async def realtime_endpoint(websocket: WebSocket):
    await websocket.accept()
    loop = asyncio.get_event_loop()
    conn = Connection(websocket=websocket, last_pong=loop.time())

    writer_task = asyncio.create_task(writer_loop(conn))
    ping_task = asyncio.create_task(ping_loop(conn))

    try:
        while not conn.closed:
            try:
                msg = await asyncio.wait_for(websocket.receive_json(), timeout=1.0)
            except TimeoutError:
                continue
            except WebSocketDisconnect:
                break

            msg_type = msg.get("type")

            if msg_type == "subscribe":
                topic = msg.get("topic")
                last_id = msg.get("last_id")
                if topic:
                    await handle_subscribe(conn, topic, last_id)
                else:
                    await send_safe(
                        conn,
                        {"type": "error", "code": "protocol_error", "message": "Missing topic"},
                    )

            elif msg_type == "unsubscribe":
                topic = msg.get("topic")
                if topic:
                    await handle_unsubscribe(conn, topic)
                else:
                    await send_safe(
                        conn,
                        {"type": "error", "code": "protocol_error", "message": "Missing topic"},
                    )

            elif msg_type == "pong":
                conn.last_pong = asyncio.get_event_loop().time()

            else:
                await send_safe(
                    conn,
                    {
                        "type": "error",
                        "code": "protocol_error",
                        "message": f"Unknown message type: {msg_type}",
                    },
                )

    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        await cleanup_connection(conn)
        ping_task.cancel()
        writer_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await ping_task
            await writer_task
