import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Query

from space.api.errors import error_boundary
from space.api.types import (
    SpawnContextView,
    SpawnCreateRequest,
    SpawnEventsPage,
    SpawnHistory,
    SpawnResumeRequest,
    SpawnView,
)
from space.core.types import AgentId, ProjectId, SpawnId
from space.lib import paths, providers
from space.os import agents, decisions, spawns, tasks

router = APIRouter(prefix="/api/spawns", tags=["spawns"])


def _view(s, include_stats: bool = False) -> dict[str, Any]:
    stats_data = None
    if include_stats:
        st = spawns.stats(s.id)
        stats_data = {
            "decisions": st.decisions,
            "insights": st.insights,
            "tasks_created": st.tasks_created,
            "tasks_completed": st.tasks_completed,
            "files_edited": st.files_edited,
            "duration_seconds": st.duration_seconds,
        }
    return {
        "id": s.id,
        "agent_id": s.agent_id,
        "project_id": s.project_id,
        "caller_spawn_id": s.caller_spawn_id,
        "status": s.status.value if hasattr(s.status, "value") else s.status,
        "error": s.error,
        "pid": s.pid,
        "session_id": s.session_id,
        "summary": s.summary,
        "stats": stats_data,
        "created_at": s.created_at,
        "last_active_at": s.last_active_at,
    }


@router.get("", response_model=list[SpawnView])
@error_boundary
def all(project_id: str | None = Query(None, description="Filter by project")):
    spawns_list = spawns.fetch(project_id=ProjectId(project_id) if project_id else None, limit=100)
    return [_view(sp, include_stats=True) for sp in spawns_list]


@router.post("", response_model=SpawnView)
@error_boundary
def create(body: SpawnCreateRequest):
    agent = agents.get(AgentId(body.agent_id))
    project_id = ProjectId(body.project_id) if body.project_id else None
    spawn = spawns.launch(
        agent,
        project_id=project_id,
        instruction=body.instruction,
    )
    return _view(spawn)


@router.get("/{spawn_id}/events", response_model=SpawnEventsPage)
@error_boundary
def events(
    spawn_id: str,
    offset: int = Query(0, ge=0, description="Start from this event index"),
    limit: int = Query(100, ge=1, le=500, description="Max events to return"),
):
    page = spawns.read_events(spawn_id, offset=offset, limit=limit)
    return {
        "events": page.events,
        "total": page.total,
        "has_more": page.has_more,
    }


@router.get("/{spawn_id}/history", response_model=SpawnHistory)
@error_boundary
def history(spawn_id: str):
    spawn = spawns.get(SpawnId(spawn_id))

    related = spawns.fetch(
        agent_id=spawn.agent_id,
        project_id=spawn.project_id,
        limit=50,
    )

    return {
        "spawn_id": spawn.id,
        "agent_id": spawn.agent_id,
        "project_id": spawn.project_id,
        "status": spawn.status.value if hasattr(spawn.status, "value") else spawn.status,
        "created_at": spawn.created_at,
        "last_active_at": spawn.last_active_at,
        "history": [_view(s) for s in related],
    }


@router.get("/{spawn_id}/usage")
@error_boundary
def usage(spawn_id: str):
    spawn = spawns.get(SpawnId(spawn_id))
    return spawns.usage(spawn)


@router.get("/{spawn_id}/context", response_model=SpawnContextView)
@error_boundary
def context(spawn_id: str):
    spawn = spawns.get(SpawnId(spawn_id))
    task_list = tasks.fetch(
        assignee_id=spawn.agent_id,
        status="active",
        project_id=spawn.project_id,
    )
    active_task = task_list[0] if task_list else None

    decision = None
    if active_task and active_task.decision_id:
        decision = decisions.get(active_task.decision_id)

    return {
        "task_id": active_task.id[:8] if active_task else None,
        "task_content": active_task.content if active_task else None,
        "decision_id": decision.id[:8] if decision else None,
        "decision_content": decision.content if decision else None,
    }


@router.post("/{spawn_id}/resume")
@error_boundary
def resume(spawn_id: str, body: SpawnResumeRequest):
    spawn = spawns.get(SpawnId(spawn_id))
    agent = agents.get(spawn.agent_id)

    provider = providers.map(agent.model) if agent.model else "unknown"
    events_file = paths.dot_space() / "spawns" / provider / f"{spawn_id}.jsonl"
    events_file.parent.mkdir(parents=True, exist_ok=True)
    event: dict[str, Any] = {
        "type": "human_input",
        "content": body.instruction,
        "timestamp": datetime.now(UTC).isoformat(),
    }
    if body.images:
        event["images"] = body.images
    with Path(events_file).open("a") as f:
        f.write(json.dumps(event) + "\n")

    spawns.runner._events.publish(spawn_id, event)

    spawns.launch(
        agent,
        project_id=spawn.project_id,
        spawn=spawn,
        instruction=body.instruction,
        images=body.images,
    )
    return {"status": "ok", "spawn_id": spawn_id}


@router.post("/{spawn_id}/stop", response_model=SpawnView)
@error_boundary
def stop(spawn_id: str):
    spawns.terminate(SpawnId(spawn_id))
    spawn = spawns.get(SpawnId(spawn_id))
    return _view(spawn)
