from typing import Any

from fastapi import APIRouter, Request

from space.api.deps import resolve_identity
from space.api.errors import error_boundary
from space.api.types import TaskCreate, TaskView
from space.core.errors import ValidationError
from space.core.types import AgentId, DecisionId, TaskId
from space.os import agents, projects, tasks

router = APIRouter(prefix="/api/tasks", tags=["tasks"])


def _view(t, agent_map: dict[AgentId, str]) -> dict[str, Any]:
    return {
        "id": t.id,
        "creator_id": t.creator_id,
        "assignee_id": t.assignee_id,
        "assignee_identity": agent_map.get(t.assignee_id, None) if t.assignee_id else None,
        "content": t.content,
        "status": t.status.value if hasattr(t.status, "value") else t.status,
        "spawn_id": t.spawn_id,
        "decision_id": t.decision_id,
        "result": t.result,
        "created_at": t.created_at,
        "started_at": t.started_at,
        "completed_at": t.completed_at,
    }


@router.get("", response_model=list[TaskView])
@error_boundary
def all(
    agent_id: str | None = None,
    decision_id: str | None = None,
    status: str | None = None,
    include_done: bool = True,
):
    task_list = tasks.fetch(
        status=status,
        assignee_id=AgentId(agent_id) if agent_id else None,
        decision_id=DecisionId(decision_id) if decision_id else None,
        include_done=include_done,
    )
    assignee_ids = list({t.assignee_id for t in task_list if t.assignee_id})
    agent_batch = agents.batch_get(assignee_ids)
    agent_map = {aid: a.identity for aid, a in agent_batch.items()}
    return [_view(t, agent_map) for t in task_list]


@router.get("/{task_id}", response_model=TaskView)
@error_boundary
def get(task_id: str):
    t = tasks.get(TaskId(task_id))
    agent_map = {}
    if t.assignee_id:
        agent = agents.get(t.assignee_id)
        if agent:
            agent_map[t.assignee_id] = agent.identity
    return _view(t, agent_map)


@router.post("", response_model=dict)
@error_boundary
def create(request: Request, body: TaskCreate):
    ident = resolve_identity(request)
    if not ident:
        raise ValidationError("Identity required to create task")

    agent = agents.get(ident)
    project_id = projects.require_scope()
    task = tasks.create(
        project_id,
        agent.id,
        body.content,
        decision_id=DecisionId(body.decision_id) if body.decision_id else None,
    )
    return {"ok": True, "task_id": task.id}
