from pathlib import Path
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel

from space.api.errors import error_boundary
from space.api.types import (
    ProjectCreate,
    ProjectUpdate,
    ProjectView,
)
from space.core.models import Project
from space.core.types import ProjectId
from space.os import projects

router = APIRouter(prefix="/api/projects", tags=["projects"])


def _mask_path(value: str | None) -> str | None:
    if not value:
        return None
    leaf = Path(value).name
    return leaf or None


def _view(project: Project) -> dict[str, Any]:
    return {
        "id": project.id,
        "name": project.name,
        "type": project.type,
        "repo_path": _mask_path(project.repo_path),
        "color": project.color,
        "icon": project.icon,
        "tags": project.tags,
        "created_at": project.created_at,
        "archived_at": project.archived_at,
    }


@router.get("", response_model=list[ProjectView])
@error_boundary
def get_projects():
    project_list = projects.fetch()
    return [_view(p) for p in project_list]


@router.post("")
@error_boundary
def create_project(body: ProjectCreate):
    project = projects.create(body.name, body.repo_path)
    return {"ok": True, "project_id": project.id}


@router.patch("/{project_id}")
@error_boundary
def update_project(project_id: str, body: ProjectUpdate):
    project = projects.get(ProjectId(project_id))
    updated = projects.update(
        project.id,
        body.name,
        body.repo_path,
    )
    return {"ok": True, "project": _view(updated)}


class ArchiveRequest(BaseModel):
    tags: list[str] | None = None


class TagsRequest(BaseModel):
    tags: list[str]
    remove: bool = False


@router.post("/{project_id}/archive")
@error_boundary
def archive_project(project_id: str, body: ArchiveRequest | None = None):
    project = projects.get(ProjectId(project_id))
    tags = body.tags if body else None
    projects.archive(project.id, tags=tags)
    return {"ok": True}


@router.post("/{project_id}/restore")
@error_boundary
def restore_project(project_id: str):
    project = projects.get(ProjectId(project_id))
    projects.restore(project.id)
    return {"ok": True}


@router.post("/{project_id}/tags")
@error_boundary
def update_tags(project_id: str, body: TagsRequest):
    project = projects.get(ProjectId(project_id))
    if body.remove:
        updated = projects.remove_tags(project.id, body.tags)
    else:
        updated = projects.add_tags(project.id, body.tags)
    return {"ok": True, "tags": updated.tags}


@router.delete("/{project_id}/tags")
@error_boundary
def clear_tags(project_id: str):
    project = projects.get(ProjectId(project_id))
    projects.set_tags(project.id, None)
    return {"ok": True}
