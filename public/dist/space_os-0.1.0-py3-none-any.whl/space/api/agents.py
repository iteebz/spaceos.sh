from typing import Any

from fastapi import APIRouter, HTTPException

from space.api.errors import error_boundary
from space.api.spawns import _view as spawn_view
from space.api.types import (
    AgentCreate,
    AgentStats,
    AgentUpdate,
    AgentView,
    ConstitutionUpdate,
    ConstitutionView,
    SpawnView,
)
from space.core.models import Agent
from space.core.types import UNSET, AgentId, AgentType
from space.lib import providers
from space.os import agents, spawns

router = APIRouter(prefix="/api/agents", tags=["agents"])


def _view(agent_list: list[Agent]) -> list[dict[str, Any]]:
    if not agent_list:
        return []

    agent_ids = [a.id for a in agent_list]
    active_map = agents.batch_last_active(agent_ids)

    return [
        {
            "id": a.id,
            "identity": a.identity,
            "type": a.type,
            "model": a.model,
            "constitution": a.constitution,
            "avatar_path": a.avatar_path,
            "color": a.color,
            "created_at": a.created_at,
            "archived_at": a.archived_at,
            "last_active_at": active_map.get(a.id),
        }
        for a in agent_list
    ]


def _view_one(agent: Agent) -> dict[str, Any]:
    return _view([agent])[0]


@router.get("", response_model=list[AgentView])
@error_boundary
def all(agent_type: AgentType | None = None, include_archived: bool = False):
    if agent_type:
        agent_list = agents.fetch(type=agent_type)
    else:
        agent_list = agents.fetch(include_archived=include_archived)
    agent_list = [a for a in agent_list if a.id != "system"]
    return _view(agent_list)


@router.get("/{agent_id}", response_model=AgentView)
@error_boundary
def get(agent_id: str):
    agent = agents.get(AgentId(agent_id))
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_id}' not found")
    return _view_one(agent)


@router.get("/{agent_id}/stats", response_model=AgentStats)
@error_boundary
def stats(agent_id: str):
    agent = agents.get(AgentId(agent_id))
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_id}' not found")

    stats = agents.stats(agent)
    return AgentStats(
        message_count=stats.message_count,
        spawn_count=stats.spawn_count,
    )


@router.get("/{agent_id}/spawns", response_model=list[SpawnView])
@error_boundary
def spawns_api(agent_id: str, status: str | None = None, limit: int = 20):
    agent = agents.get(AgentId(agent_id))
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_id}' not found")

    spawn_list = spawns.fetch(agent_id=agent.id, limit=limit, status=status)
    return [spawn_view(s) for s in spawn_list]


@router.get("/models/available")
@error_boundary
def list_models():
    return providers.MODELS


@router.get("/{agent_id}/constitution", response_model=ConstitutionView)
@error_boundary
def constitution(agent_id: str):
    agent = agents.get(AgentId(agent_id))
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_id}' not found")

    if not agent.constitution:
        raise HTTPException(status_code=404, detail="Agent has no constitution configured")

    content = agents.constitutions.get(agent.constitution)
    return ConstitutionView(name=agent.constitution, content=content)


@router.post("", response_model=AgentView)
@error_boundary
def create(request: AgentCreate):
    try:
        agent = agents.create(
            identity=request.identity,
            type=request.type,
            model=request.model,
            constitution=request.constitution,
        )
        return _view_one(agent)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.patch("/{agent_id}")
@error_boundary
def update(agent_id: str, update: AgentUpdate):
    agent = agents.get(AgentId(agent_id))
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_id}' not found")

    try:
        fields = update.model_fields_set
        agents.update(
            agent.id,
            model=update.model if "model" in fields else UNSET,
            constitution=update.constitution if "constitution" in fields else UNSET,
            avatar_path=update.avatar_path if "avatar_path" in fields else UNSET,
            color=update.color if "color" in fields else UNSET,
        )
        return {"ok": True}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.put("/{agent_id}/constitution")
@error_boundary
def update_constitution(agent_id: str, update: ConstitutionUpdate):
    agent = agents.get(AgentId(agent_id))
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_id}' not found")

    if not agent.constitution:
        raise HTTPException(status_code=400, detail="Agent has no constitution configured")

    agents.constitutions.update(agent.constitution, update.content)
    return {"ok": True}
