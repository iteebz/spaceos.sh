from fastapi import APIRouter, Request
from pydantic import BaseModel

from space.api.deps import resolve_identity
from space.api.errors import error_boundary
from space.api.types import CamelModel
from space.core.errors import ValidationError
from space.core.types import ArtifactType
from space.lib import push
from space.os import agents, insights, projects, replies


class ReplyView(CamelModel):
    id: str
    parent_type: str
    parent_id: str
    author_id: str
    identity: str
    content: str
    mentions: list[str] | None
    images: list[str] | None
    created_at: str


class InboxItemView(CamelModel):
    id: str
    parent_type: str
    parent_id: str
    author_id: str
    identity: str
    content: str
    parent_content: str
    parent_identity: str
    created_at: str


class ReplyCreate(BaseModel):
    content: str
    images: list[str] | None = None


router = APIRouter(prefix="/api/replies", tags=["replies"])


@router.get("/{parent_type}/{parent_id}", response_model=list[ReplyView])
@error_boundary
def list_replies(parent_type: ArtifactType, parent_id: str):
    items = replies.fetch_for_parent(parent_type, parent_id)
    agent_ids = list({r.author_id for r in items})
    agent_batch = agents.batch_get(agent_ids)
    agent_map = {aid: a.identity for aid, a in agent_batch.items()}
    return [
        ReplyView(
            id=r.id,
            parent_type=r.parent_type,
            parent_id=r.parent_id,
            author_id=r.author_id,
            identity=agent_map.get(r.author_id, "unknown"),
            content=r.content,
            mentions=r.mentions,
            images=r.images,
            created_at=r.created_at,
        )
        for r in items
    ]


@router.get("/inbox", response_model=list[InboxItemView])
@error_boundary
def get_inbox(request: Request):
    agent_id = resolve_identity(request)
    if not agent_id:
        raise ValidationError("Identity required for inbox")

    agent = agents.get(agent_id)
    identity = agent.identity

    reply_items = replies.inbox_with_context(identity)
    reply_agent_ids = list({item.reply.author_id for item in reply_items})
    reply_agent_batch = agents.batch_get(reply_agent_ids)
    reply_agent_map = {aid: a.identity for aid, a in reply_agent_batch.items()}

    insight_items = insights.inbox(identity)
    insight_agent_ids = list({i.agent_id for i in insight_items})
    insight_agent_batch = agents.batch_get(insight_agent_ids)
    insight_agent_map = {aid: a.identity for aid, a in insight_agent_batch.items()}

    result = [
        InboxItemView(
            id=item.reply.id,
            parent_type=item.reply.parent_type,
            parent_id=item.reply.parent_id,
            author_id=item.reply.author_id,
            identity=reply_agent_map.get(item.reply.author_id, "unknown"),
            content=item.reply.content,
            parent_content=item.parent_content,
            parent_identity=item.parent_identity,
            created_at=item.reply.created_at,
        )
        for item in reply_items
    ] + [
        InboxItemView(
            id=i.id,
            parent_type="insight",
            parent_id=i.id,
            author_id=i.agent_id,
            identity=insight_agent_map.get(i.agent_id, "unknown"),
            content=i.content,
            parent_content=i.content,
            parent_identity=insight_agent_map.get(i.agent_id, "unknown"),
            created_at=i.created_at,
        )
        for i in insight_items
    ]

    result.sort(key=lambda x: x.created_at, reverse=True)
    return result


@router.post("/{parent_id}", response_model=ReplyView)
@error_boundary
def create_reply(parent_id: str, body: ReplyCreate, request: Request):
    ident = resolve_identity(request)
    if not ident:
        raise ValidationError("Identity required to create reply")

    agent = agents.get(ident)
    project_id = projects.require_scope()
    r = replies.create(
        parent_id=parent_id,
        author_id=agent.id,
        content=body.content,
        project_id=project_id,
        images=body.images,
    )

    if r.mentions:
        push.notify_mentions(
            mentions=r.mentions,
            author_identity=agent.identity,
            content=r.content,
            route=f"/thread/{r.parent_id[:8]}?type={r.parent_type}",
        )

    return ReplyView(
        id=r.id,
        parent_type=r.parent_type,
        parent_id=r.parent_id,
        author_id=r.author_id,
        identity=agent.identity,
        content=r.content,
        mentions=r.mentions,
        images=r.images,
        created_at=r.created_at,
    )
