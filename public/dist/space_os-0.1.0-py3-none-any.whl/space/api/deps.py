from fastapi import Request

from space.core.types import AgentId
from space.lib import devices, identity


def resolve_identity(request: Request) -> AgentId | None:
    if env_identity := identity.current():
        return env_identity

    client_ip = request.client.host if request.client else None
    if not client_ip:
        return None

    device = devices.get_by_ip(client_ip)
    if device:
        return device.owner_id

    return None
