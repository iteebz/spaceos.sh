import logging

from fastapi import APIRouter, Request
from pydantic import BaseModel, Field

from space.core.models import EmailDirection, EmailStatus
from space.lib import email

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/email", tags=["email"])


class ResendWebhookData(BaseModel):
    email_id: str
    created_at: str | None = None
    from_addr: str | None = Field(None, alias="from")
    to: list[str] | None = None
    subject: str | None = None


class ResendWebhook(BaseModel):
    type: str
    created_at: str | None = None
    data: ResendWebhookData


@router.post("/webhook")
async def resend_webhook(request: Request):
    body = await request.json()
    logger.info(f"Resend webhook received: {body.get('type')}")

    if body.get("type") != "email.received":
        return {"ok": True, "skipped": True}

    data = body.get("data", {})
    resend_id = data.get("email_id")
    if not resend_id:
        return {"ok": False, "error": "missing email_id"}

    email_details = email.fetch_body(resend_id)
    if not email_details:
        return {"ok": False, "error": "failed to fetch email body"}

    to_list = data.get("to", [])
    to_addr = to_list[0] if to_list else ""

    saved = email.save_inbound(
        resend_id=resend_id,
        from_addr=data.get("from", ""),
        to_addr=to_addr,
        subject=data.get("subject"),
        body_text=email_details.get("text"),
        body_html=email_details.get("html"),
    )

    logger.info(f"Saved inbound email {saved.id} from {saved.from_addr}")
    return {"ok": True, "id": saved.id}


@router.get("/inbox")
async def list_inbox(limit: int = 50):
    emails = email.list_emails(direction=EmailDirection.INBOUND, limit=limit)
    return [
        {
            "id": e.id,
            "from": e.from_addr,
            "to": e.to_addr,
            "subject": e.subject,
            "created_at": e.created_at,
        }
        for e in emails
    ]


@router.get("/drafts")
async def list_drafts(limit: int = 50):
    emails = email.list_emails(status=EmailStatus.DRAFT, limit=limit)
    return [
        {
            "id": e.id,
            "from": e.from_addr,
            "to": e.to_addr,
            "subject": e.subject,
            "status": e.status.value,
            "created_at": e.created_at,
        }
        for e in emails
    ]


@router.get("/{email_id}")
async def get_email(email_id: str):
    e = email.get(email_id)
    if not e:
        return {"error": "not found"}
    return {
        "id": e.id,
        "direction": e.direction.value,
        "status": e.status.value,
        "from": e.from_addr,
        "to": e.to_addr,
        "subject": e.subject,
        "body_text": e.body_text,
        "body_html": e.body_html,
        "approved_by": e.approved_by,
        "approved_at": e.approved_at,
        "created_at": e.created_at,
    }
