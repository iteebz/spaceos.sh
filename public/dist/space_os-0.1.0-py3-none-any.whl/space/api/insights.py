from typing import Any

from fastapi import APIRouter, Request

from space.api.deps import resolve_identity
from space.api.errors import error_boundary
from space.api.types import InsightCreate, InsightView
from space.core.errors import ValidationError
from space.core.types import INSIGHT_DOMAINS, AgentId, DecisionId, InsightId
from space.os import agents, insights, projects

router = APIRouter(prefix="/api/insights", tags=["insights"])


@router.get("/domains", response_model=list[str])
@error_boundary
def list_domains():
    return sorted(INSIGHT_DOMAINS)


def _view(i, agent_map: dict[AgentId, str]) -> dict[str, Any]:
    return {
        "id": i.id,
        "agent_id": i.agent_id,
        "identity": agent_map.get(i.agent_id, "unknown"),
        "domain": i.domain,
        "content": i.content,
        "images": i.images,
        "decision_id": i.decision_id,
        "created_at": i.created_at,
    }


@router.get("", response_model=list[InsightView])
@error_boundary
def list_insights(domain: str | None = None, agent_id: str | None = None):
    items = insights.fetch(
        domain=domain,
        agent_id=AgentId(agent_id) if agent_id else None,
    )
    agent_ids = list({i.agent_id for i in items})
    agent_batch = agents.batch_get(agent_ids)
    agent_map = {aid: a.identity for aid, a in agent_batch.items()}
    return [_view(i, agent_map) for i in items]


@router.get("/{insight_id}", response_model=InsightView)
@error_boundary
def get_insight(insight_id: str):
    i = insights.get(InsightId(insight_id))
    agent = agents.get(i.agent_id)
    return _view(i, {i.agent_id: agent.identity if agent else "unknown"})


@router.post("")
@error_boundary
def create_insight(request: Request, body: InsightCreate):
    ident = resolve_identity(request)
    if not ident:
        raise ValidationError("Identity required to create insight")

    agent = agents.get(ident)
    project_id = projects.require_scope()
    insight = insights.create(
        project_id,
        agent.id,
        body.content,
        body.domain,
        decision_id=DecisionId(body.decision_id) if body.decision_id else None,
        images=body.images,
    )
    return _view(insight, {agent.id: agent.identity})


@router.post("/{insight_id}/archive")
@error_boundary
def archive_insight(insight_id: str):
    i = insights.archive(InsightId(insight_id))
    agent = agents.get(i.agent_id)
    return _view(i, {i.agent_id: agent.identity if agent else "unknown"})


@router.delete("/{insight_id}")
@error_boundary
def delete_insight(insight_id: str):
    insights.delete(InsightId(insight_id))
    return {"ok": True}
