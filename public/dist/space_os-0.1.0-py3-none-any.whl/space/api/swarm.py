from fastapi import APIRouter
from pydantic import BaseModel

from space.lib import config
from space.os import daemon

router = APIRouter(prefix="/api/swarm", tags=["swarm"])


class SwarmStatus(BaseModel):
    enabled: bool
    limit: int | None
    concurrency: int
    agents: list[str] | None
    projects: list[str] | None
    enabled_at: str | None


class SwarmOnRequest(BaseModel):
    limit: int | None = None
    concurrency: int | None = None
    agents: list[str] | None = None
    projects: list[str] | None = None


@router.get("/status", response_model=SwarmStatus)
def status():
    cfg = config.load().swarm
    return SwarmStatus(
        enabled=cfg.enabled,
        limit=cfg.limit,
        concurrency=cfg.concurrency,
        agents=cfg.agents,
        projects=cfg.projects,
        enabled_at=cfg.enabled_at,
    )


@router.post("/on", response_model=SwarmStatus)
def on(req: SwarmOnRequest):
    daemon.on(
        limit=req.limit,
        concurrency=req.concurrency,
        agents_list=req.agents,
        projects_list=req.projects,
        reset_filters=req.agents is None and req.projects is None,
    )
    return status()


@router.post("/off", response_model=SwarmStatus)
def off():
    daemon.off()
    return status()
