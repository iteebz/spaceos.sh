"""API types. Single source of truth for OpenAPI schema generation."""

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict

from space.core.types import AgentType

SpawnEventType = Literal[
    "text",
    "tool_call",
    "tool_result",
    "message",
    "context",
    "context_init",
    "human_input",
    "summary",
    "status",
    "heartbeat",
    "error",
    "state_change",
]


class SpawnEvent(BaseModel):
    type: SpawnEventType
    timestamp: str | None = None
    content: Any = None


def to_camel(s: str) -> str:
    parts = s.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


class CamelModel(BaseModel):
    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)


class AgentView(CamelModel):
    id: str
    identity: str
    type: AgentType
    model: str | None
    constitution: str | None
    avatar_path: str | None
    color: str | None
    created_at: str | None
    archived_at: str | None
    last_active_at: str | None


class AgentStats(CamelModel):
    message_count: int
    spawn_count: int


class AgentCreate(CamelModel):
    identity: str
    type: AgentType = "ai"
    model: str | None = None
    constitution: str | None = None


class AgentUpdate(CamelModel):
    model: str | None = None
    constitution: str | None = None
    avatar_path: str | None = None
    color: str | None = None


class ConstitutionView(CamelModel):
    name: str
    content: str


class ConstitutionUpdate(CamelModel):
    content: str


class SpawnStatsView(CamelModel):
    decisions: int
    insights: int
    tasks_created: int
    tasks_completed: int
    files_edited: int
    duration_seconds: float | None


class SpawnView(CamelModel):
    id: str
    agent_id: str
    project_id: str | None
    caller_spawn_id: str | None
    status: str
    error: str | None
    pid: int | None
    session_id: str | None
    summary: str | None
    stats: SpawnStatsView | None
    created_at: str | None
    last_active_at: str | None


class SpawnHistory(CamelModel):
    spawn_id: str
    agent_id: str
    project_id: str | None
    status: str
    created_at: str | None
    last_active_at: str | None
    history: list[SpawnView]


class SpawnEventsPage(CamelModel):
    events: list[SpawnEvent]
    total: int
    has_more: bool


class SpawnResumeRequest(CamelModel):
    instruction: str
    images: list[str] | None = None


class SpawnCreateRequest(CamelModel):
    agent_id: str
    project_id: str | None = None
    instruction: str | None = None


class TaskView(CamelModel):
    id: str
    creator_id: str
    assignee_id: str | None
    assignee_identity: str | None
    spawn_id: str | None
    decision_id: str | None
    content: str
    status: str
    result: str | None
    created_at: str | None
    started_at: str | None
    completed_at: str | None


class TaskCreate(CamelModel):
    content: str
    decision_id: str | None = None


class InsightView(CamelModel):
    id: str
    agent_id: str
    identity: str
    domain: str
    content: str
    images: list[str] | None = None
    decision_id: str | None
    created_at: str


class InsightCreate(CamelModel):
    content: str
    domain: str
    decision_id: str | None = None
    images: list[str] | None = None


class DecisionView(CamelModel):
    id: str
    agent_id: str
    identity: str
    content: str
    rationale: str
    images: list[str] | None = None
    created_at: str


class DecisionCreate(CamelModel):
    content: str
    rationale: str
    images: list[str] | None = None


class ProjectView(CamelModel):
    id: str
    name: str
    type: str
    repo_path: str | None
    color: str | None
    icon: str | None
    tags: list[str] | None
    created_at: str | None
    archived_at: str | None


class ProjectCreate(CamelModel):
    name: str
    repo_path: str | None = None


class ProjectUpdate(CamelModel):
    name: str | None = None
    repo_path: str | None = None


class ProjectAssign(CamelModel):
    project_name: str | None


class ActivityEvent(CamelModel):
    type: str
    id: str
    agent_id: str | None
    summary: str | None
    created_at: str


class ReorderRequest(CamelModel):
    ids: list[str]
    user_id: str


class LedgerItemView(CamelModel):
    type: str
    id: str
    content: str
    agent_id: str
    identity: str
    created_at: str
    rationale: str | None = None
    status: str | None = None
    decision_id: str | None = None
    decision_content: str | None = None


class ThreadView(CamelModel):
    item: LedgerItemView
    items: list[LedgerItemView]


class SpawnContextView(CamelModel):
    task_id: str | None
    task_content: str | None
    decision_id: str | None
    decision_content: str | None
