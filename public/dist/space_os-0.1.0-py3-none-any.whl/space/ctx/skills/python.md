---
description: Python boundaries, contracts, mutations, imports
---

# Python Style

## Boundaries

| Layer | Location | Receives | Does |
|-------|----------|----------|------|
| CLI | `cli/*` | ambiguous refs (uuid[:8], names) | resolve → call domain → format output |
| API | `api/*` | full UUIDs as strings (from JSON) | wrap in `TypedId(string)`, call domain |
| Domain | `os/*`, `ops/*` | typed IDs | business logic, transformations |
| Repo | `*/repo.py` | typed IDs only | SQL operations |

CLI and API are thin shells. No business logic, no data transformation. If you're writing `if/else` on domain data in CLI, move it to domain.

```python
# CLI: resolve ambiguous ref → object
agent = store.resolve(ref, "agents", Agent)
spawns.create(agent.id, project_id=project.id)

# API: JSON gives strings → wrap in typed ID
spawn = spawns.create(AgentId(payload.agent_id), project_id=...)

# Domain: typed ID in, object out
creator = agents.get(task.creator_id)  # task.creator_id is AgentId
```

## Contracts

| Verb | Signature | Behavior |
|------|-----------|----------|
| `get` | `(id: TypedId) -> T` | raises `NotFoundError` |
| `fetch` | `(...) -> list[T]` | empty if none |
| `create` | `(...) -> T` | new entity |
| `update` | `(id: TypedId, ...) -> T` | mutates, returns fresh |
| `delete` | `(id: TypedId) -> None` | hard delete (rare) |
| semantic | `(id: TypedId, ...) -> T` | state transition, returns fresh |

These functions accept typed IDs (`AgentId`, `SpawnId`, etc.), never strings, never objects. Objects go stale; IDs are stable references to current state.

```python
# Right
updated = spawns.update(spawn.id, status=SpawnStatus.ACTIVE)
agents.get(agent.id)

# Wrong
spawns.update(spawn, status=SpawnStatus.ACTIVE)  # object, not ID
agents.get("zealot")  # string, not typed ID
```

Semantic verbs (`archive`, `terminate`, `block`) follow the same pattern.

## Mutations

Models are snapshots. Mutation lives in the database. Always re-fetch after UPDATE.

```python
def archive(insight_id: InsightId) -> Insight:
    with store.write() as conn:
        conn.execute("UPDATE insights SET archived_at = ? WHERE id = ?", ...)
    return get(insight_id)  # truth
```

Never mutate instances. Never construct from parameters. Re-fetch.

### `update()` vs named functions

| Use | When |
|-----|------|
| `update()` | Field changes, no rules |
| Named (`archive`, `delete`) | State machine, side effects, or invariants |

If it doesn't enforce a rule, use `update()`.

## Tests

Tests are NOT boundaries. They call domain functions directly with typed IDs from created objects.

Tests may import internals (submodules, private helpers) when precision matters.
Production code must not: CLI/API/domain callers import modules via `space.os`/`space.ops` and use the exported contract.

## Models

Flat references—IDs only, no nested objects.

```python
@dataclass
class Spawn:
    id: SpawnId
    agent_id: AgentId      # typed ID, not Agent object
    status: SpawnStatus    # enum is fine
```

## Modules

Split files for readability. `__init__.py` hoists public functions into a flat namespace. Callers import the module, never submodules.

```python
from space.os import spawns, replies   # YES
spawns.terminate()                      # YES
spawns.lifecycle.terminate()            # NO
from space.os.spawns import repo        # NO
```

Why: callers couple to file structure when they import submodules. Now you can't move, merge, split, or rename files without updating call sites. The `__init__.py` is a stable contract. The file structure behind it is free to change.

## Naming

Name things what they are. Don't alias—rename the source.

## Imports

| Context | Pattern | Example |
|---------|---------|---------|
| Types | direct | `from space.core.models import Spawn` |
| Cross-module | module.func() | `from space.os import spawns` → `spawns.fetch()` |
| Intra-module | relative | `from .repo import fetch` |

## Types

| Location | Contents |
|----------|----------|
| `core/types.py` | ID aliases (`AgentId`, `ReplyId`, etc.) |
| `core/models.py` | Shared dataclasses |

If a type crosses module boundaries, centralize it.

## Deletion

No hard deletes on continuity primitives. Provenance is sacred.

| Column | Use when |
|--------|----------|
| `archived_at` | Content went stale |
| `decision_id` on insight | Learning linked to decision |
| terminal status | Work finished |
