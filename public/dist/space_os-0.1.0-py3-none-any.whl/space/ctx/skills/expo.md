---
description: Expo app structure, domains, features, routes
---

# Expo App Architecture

Space mobile app. Backend-first—the app surfaces backend primitives, not the reverse.

## Type System

**Backend owns types.** All types are defined in `space/api/types.py` as Pydantic models, exposed via OpenAPI, and generated into TypeScript.

```bash
pnpm generate-types   # Generates lib/api.types.ts from OpenAPI spec
```

```
space/api/types.py      → OpenAPI spec → app/src/lib/api.types.ts
                                                    ↓
                                          app/src/lib/types.ts (aliases)
```

**Rules:**
- Never hand-write types that exist in the API
- Add new types to backend first, regenerate
- `lib/types.ts` exports aliases for ergonomics only
- Domain services can re-export from generated types

## Structure

```
app/src/
├── app/              # Routes (expo-router). Thin orchestrators.
├── components/
│   ├── ui/           # Shared primitives (Button, Avatar, Input)
│   └── shell/        # App infrastructure (gates, banners, boundaries)
├── domains/          # Backend primitives + their UI
├── features/         # UX assemblies that compose domains
├── hooks/            # Cross-cutting hooks only
└── lib/              # Utilities, API, services
```

## Domains vs Features

**Domains** = backend nouns. Durable. Agent-relevant. Would matter if UI vanished.
- `spawns/`, `ledger/`, `decisions/`, `insights/`, `agents/`, `tasks/`, `replies/`

**Features** = UX assemblies. Human-facing. No backend equivalent.
- `auth/`, `settings/`

**Test**: Which backend primitive anchors this UI?
- One clear answer → domain UI (e.g., `ThreadSession` anchors on `ledger`)
- Multiple equals → feature (rare—most UI has a primary domain)
- None → feature (pure human orchestration)

## Domains

Named after backend nouns. Each domain owns its data and domain-specific UI:

```
domains/spawns/
├── index.ts          # Single barrel—exports everything
├── service.ts        # API calls
├── queries.ts        # React Query reads
├── mutations.ts      # React Query writes
└── ui/
    ├── SpawnList.tsx
    └── SpawnTrace.tsx
```

**One barrel per domain.** No `ui/index.ts`. Domain barrel exports UI directly:

```ts
// domains/spawns/index.ts
export * from './service'
export * from './queries'
export { SpawnList } from './ui/SpawnList'
```

Import via domain: `import { useSpawns, SpawnList } from '@/domains/spawns'`

## Features

UX assemblies with no backend anchor. No direct API calls—use domain hooks.

```
features/auth/
├── DeviceRegistration.tsx
└── index.ts

features/settings/
├── SettingsScreen.tsx
└── index.ts
```

Import via barrel: `import { SettingsScreen } from '@/features/settings'`

**Note:** Domain UI can use other domains (e.g., `ledger/ThreadSession` uses `replies`). That doesn't make it a feature—`ledger` is still the anchor.

## Routes

Expo Router screens in `app/` are orchestrators only:
- Extract params via `useLocalSearchParams`
- Import from domains or features
- Render one top-level component
- **<20 lines. No StyleSheet. No hooks beyond navigation.**

```tsx
// app/spawns/[id]/index.tsx
import { Stack, useLocalSearchParams } from 'expo-router'
import { SpawnSession } from '@/domains/spawns'

export default function SpawnRoute() {
  const { id } = useLocalSearchParams<{ id: string }>()
  if (!id) return null
  return (
    <>
      <Stack.Screen options={{ title: `Spawn ${id.slice(0, 8)}` }} />
      <SpawnSession spawnId={id} />
    </>
  )
}
```

If a route exceeds 20 lines, the UI belongs in a domain or feature.

## Dependency Graph

```
app/ → features/ → domains/ → lib/
         ↓
     components/
```

One direction. No cycles. Enforced via ESLint `import/no-restricted-paths`.

## Hooks

Cross-cutting only. Domain-specific hooks live in their domain.

```
hooks/
├── useRealtime.ts       # WebSocket subscription
└── useNotifications.ts  # Push notifications
```

## Lib

Pure utilities. No React imports. No domain imports. Importable from anywhere.

```
lib/
├── api.ts            # HTTP client
├── api.types.ts      # Generated from OpenAPI (do not edit)
├── types.ts          # Type aliases from api.types.ts
├── colors.ts         # Theme
├── constants.ts      # App-wide constants
└── native/           # Platform abstractions
```

## Patterns

**Data flow**: service → query → component (via props)

```tsx
// domains/tasks/service.ts
export const tasksService = {
  list: () => fetchApi<Task[]>('/tasks'),
}

// domains/tasks/queries.ts
export function useTasks() {
  return useQuery({ queryKey: ['tasks'], queryFn: tasksService.list })
}

// domains/tasks/ui/TaskList.tsx
export function TaskList() {
  const { data: tasks } = useTasks()
  return <FlatList data={tasks} ... />
}
```

**Mutations**: Invalidate queries on success.

```tsx
export function useCreateReply(parentId: string) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (data) => repliesService.create(parentId, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['replies', parentId] }),
  })
}
```
