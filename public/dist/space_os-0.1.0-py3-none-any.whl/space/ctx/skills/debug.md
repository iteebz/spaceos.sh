---
description: Spawn broken, data missing, need to trace
---

# Debug

## Orient

```bash
agent list                     # who exists
spawn list                     # recent spawns (shows last 8 chars of id)
inbox                          # unresolved @mentions
search "query"                 # search all primitives
```

## Data Flow

```
daemon tick → spawns table → execution → events JSONL → idle/done
```

**Key:** CLI shows SHORT spawn_id (last 8 chars). JSONL files use FULL UUID. Both work for lookups.

## Mutations

Control events live in `mutations` table:
```bash
sqlite3 ~/.space/space.db "SELECT type, resource_id, created_at FROM mutations ORDER BY created_at DESC LIMIT 20"
```

Types: `spawn.started`, `spawn.completed`, `spawn.failed`, `timer.set`, `timer.expired`, `timer.cancelled`, `control.stop`, `routing.failed`

## Debug Playbook

### "Agent spawned but nothing happened"
```bash
spawn trace <id>                              # execution events
spawn chain                                   # parent/child tree
ls ~/.space/spawns/claude/ | grep <id>        # find JSONL (uses full id)
tail ~/.space/spawns/claude/<full-id>.jsonl
```

### "Inbox has items but no spawns"
```bash
inbox                                         # check unresolved @mentions
agent list | grep <identity>                  # agent exists?
insight show <id>                             # check insight + replies
decision show <id>                            # check decision + replies
```

### "What control events happened?"
```bash
sqlite3 ~/.space/space.db "SELECT * FROM mutations WHERE resource_id = '<id>'"
```

### "Search for clues"
```bash
search "query"                                # all primitives
search "error" --scope spawns --recent 1      # spawns, last day
insight search "query" --as <agent>           # agent insights
```

## Data Locations

| Path | Contents |
|------|----------|
| `~/.space/space.db` | agents, spawns, insights, decisions, tasks, replies |
| `~/.space/spawns/<provider>/<id>.jsonl` | execution events (tool calls, thinking, responses) |
| `~/.space/agents/<identity>/` | agent working directory, CLAUDE.md |
| `~/.space/logs/space.log` | API logs (rotating, 10MB) |

### JSONL Event Types
- `system/init` - session_id, tools, model, cwd
- `assistant/message` - model turns
- `tool_use` / `tool_result` - tool calls
- `text` - model output
- `state_change` - DB mutations during execution

## Raw Queries

```bash
# JSONL
cat ~/.space/spawns/claude/<id>.jsonl | jq 'select(.type == "tool_use")'

# DB
sqlite3 ~/.space/space.db "SELECT spawn_id, status, trigger, created_at FROM spawns ORDER BY created_at DESC LIMIT 10"
```

## Never

1. Delete `~/.space/space.db` — unrecoverable
2. Edit JSONL files — read-only append logs
4. Skip `search` — searches ALL primitives, use it first

## Code Map

- **Models**: `space/core/models.py`
- **Spawn execution**: `space/os/spawns/{executor,trace,launch}.py`
- **CLI**: `space/cli/`
