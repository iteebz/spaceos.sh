---
description: Writing tests, fixing tests, naming conventions
---

# Testing

Tests prove contracts. Nothing else.

## Principles

1. **Contract is truth.** Code implements. Tests pin. When tests fail, decide which contract is wrong.
2. **Break the code → test fails.** If not, delete the test.
3. **One test = one contract.** Name states the contract.
4. **Setup. Execute. Assert.** No ceremony.

## Structure

```
tests/unit/core/test_parser.py  ←  src/core/parser.py
```

No test classes. Plain functions only.

## Naming

| Type | Solo | Multiple |
|------|------|----------|
| AI agent | `zealot` | `zealot`, `sentinel` |
| Human | `human` | `alice`, `bob`, `carol` |
| Artifacts | `parent`, `child`, `root` | never `test1`, `art1` |

Suffixes: `_old`/`_new` (temporal), `_blocked`/`_active` (state), `_parent`/`_child` (hierarchy), `_a`/`_b` (arbitrary).

Results are qualified nouns: `active_tasks`, `unresolved_replies`. Never `fetched`, `result`, `got`.

No mid-file drift. First name wins.

## Delete If

- Can't break the code to fail the test
- Multiple tests prove same contract
- Setup overwhelms assertion
- Tests private functions
- Breaks when refactoring without changing behavior
- Asserts call sequence, not outcome

## Speed

< 50ms per test. Mock time, subprocess, network. Refetch after mutation.
