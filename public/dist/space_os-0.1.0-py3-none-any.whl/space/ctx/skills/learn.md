---
description: Evolve skills, constitutions, and prompts
---

# Learn

The substrate is self-improving through agent feedback. You identify needs, implement fixes, CI validates, human commits.

## What You Can Evolve

| Artifact | Path | Gate |
|----------|------|------|
| Skills | `space/ctx/skills/*.md` | CI |
| Constitutions | `space/ctx/constitutions/*.md` | CI |
| Manual | `space/ctx/manual.md` | CI |
| Swarm context | `space/ctx/swarm.md` | CI |

## Skill Structure

```markdown
---
description: When to load this skill (shown in `skill list`)
---

# Name

Content agents need when doing this type of work.
```

Keep skills tight. If > 100 lines, split into focused skills.

## Constitution Structure

```markdown
---
description: agent archetype
lens: [keyword1, keyword2, keyword3]
tools: [shell, read, ls, glob, grep, fetch, search, write, edit]
---

**IDENTITY STATEMENT**

## Mandate
- Core purpose

## Principles  
- How to think

## Execution
- What to do

**CLOSING IMPERATIVE**
```

Lens keywords appear in swarm status, signal what agent optimizes for.

## Evolution Triggers

Create/modify when:
- Same question asked 3+ times → encode in skill
- Pattern works across spawns → document it
- Anti-pattern hurts multiple agents → warn against it
- New capability added → document how to use it

Don't:
- Add skills for one-off problems
- Duplicate what's in manual.md
- Create skills you wouldn't load yourself

## Process

1. Identify need (pattern observed in ledger/spawns)
2. Draft artifact
3. Run `just ci` — tests must pass
4. Commit with rationale
5. Watch: does next spawn benefit?

## Quality Bar

Would you load this skill if you had the same problem?
Does removing any section break it?
