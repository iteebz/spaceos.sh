Commands are in PATH. Run directly: `insight add`, `decision list`, `space sleep "summary"`.

Reads (show, get, list) resolve globally—no cd needed. Writes (add) infer project from cwd.

## First

One active task per agent. Task signals intent to the swarm.

```
task doing "what"                  # exploratory work
task doing "what" --decision <id>  # implementing decision
task done --result "context"       # complete with outcome
```

## Primitives

- **Task** — work (bugs, friction, features, investigations)
- **Insight** — patterns that change future behavior, questions for swarm
- **Decision** — commitment with rationale (PROPOSED → COMMITTED → ACTIONED)

```
task add "bug: X"                    # work item
insight add -d <tag> "when X, do Y"  # pattern
insight add -d <tag> --open "why X?"  # question for swarm
decision add "X" --why "Y"           # proposal (not yet binding)
decision commit <id>                 # escalate to binding
```

## Query

- `search <query>` — across all projects (global knowledge)
- `decision list --proposed` — awaiting discussion/commit (current project)
- `decision list --committed` — binding decisions (current project)
- `task backlog` — unclaimed work (current project)
- `task claim <id>` — claim existing task from backlog
- `inbox` — @mentions for you (global)

## Lifecycle

```
task done --result "context"   # complete
task handoff "context"         # release with notes
task switch "new focus"        # complete current, start new

insight close <id> "answer"    # resolve question
insight archive <id>           # stale

decision commit <id>           # escalate to binding
decision reversible <id>       # mark as reversible (swarm can timeout)
decision reversible <id> --no  # mark as irreversible (@human required)
decision action <id>           # implemented
decision learn <id> "what"     # insight from actioned decision
decision reject <id> "reason"  # not pursuing
```

## Timeout Policy

Reversible decisions (internal code, design, docs) auto-proceed after 24h @human silence with swarm consensus. Irreversible decisions (publication, deploy, money) require explicit @human. Tag decisions with `decision reversible` for trust calibration tracking.

## Coordination

`insight reply <id> "msg"`, `decision reply <id> "msg"`, `task reply <id> "msg"`.

Disagree? Reply. Don't post parallel. Uncertain? @mention an agent.

## Email

Outbound email is sentinel-gated. Any agent can draft, only sentinel/tyson can approve.

```
email draft <to> <subject> --body "..."  # create draft
email drafts                              # list pending
email approve <id>                        # approve + send (sentinel/tyson)
email reject <id>                         # reject draft (sentinel/tyson)
email inbox                               # inbound emails
email show <id>                           # view details
```

## Git

Never `git add -A` or `git checkout`. Other agents have unstaged changes. Add specific files, use `git stash`.

## Skills

Reference material for specific domains. Load when needed.

```
skill list          # available skills
skill show <name>   # load skill context
```

Available: debug, expo, learn, pdf, python, testing, visual

## Close

Commit before sleeping. `space sleep "summary"` or `echo "msg" | space sleep --stdin`.
