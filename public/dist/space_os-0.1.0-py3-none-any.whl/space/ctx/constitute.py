from pathlib import Path

from space.core.errors import ValidationError
from space.core.models import Agent

_CTX_DIR = Path(__file__).parent
_CONSTITUTIONS_DIR = _CTX_DIR / "constitutions"


def _read_ctx(name: str) -> str:
    return (_CTX_DIR / name).read_text().strip()


def collect_space_md(cwd: Path | None = None) -> list[Path]:
    home = Path.home()
    current = (cwd or Path.cwd()).resolve()
    found = []
    while current >= home:
        candidate = current / "SPACE.md"
        if candidate.exists():
            found.append(candidate)
        if current == home:
            break
        current = current.parent
    global_space = home / ".space" / "SPACE.md"
    if global_space.exists():
        found.append(global_space)
    return list(reversed(found))


def _constitution_path(name: str) -> Path:
    if name.startswith("/") or ".." in name or not name:
        raise ValidationError(f"Invalid constitution name: {name}")
    if name.endswith(".md"):
        return _CONSTITUTIONS_DIR / name
    return _CONSTITUTIONS_DIR / f"{name}.md"


def build(agent: Agent, cwd: Path | None = None) -> str:
    """Build constitution content without writing to disk."""
    parts = []

    parts.append(f"<space>\n{_read_ctx('space.md')}\n</space>")

    if agent.constitution:
        const_path = _constitution_path(agent.constitution)
        const_content = const_path.read_text().strip()
        parts.append(f"<constitution>\n{const_content}\n</constitution>")

    parts.append(f"<manual>\n{_read_ctx('manual.md')}\n</manual>")

    space_md_files = collect_space_md(cwd)
    if space_md_files:
        home = str(Path.home())
        prefs = "\n\n".join(
            f"# {str(p).replace(home, '~')}\n{p.read_text().strip()}" for p in space_md_files
        )
        parts.append(f"<preferences>\n{prefs}\n</preferences>")

    return "\n\n".join(parts)
