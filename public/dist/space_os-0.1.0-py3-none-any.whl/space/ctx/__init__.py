from pathlib import Path

from space.core.errors import NotFoundError, ValidationError
from space.core.models import Agent, Spawn, SpawnStatus
from space.core.types import AgentId, ProjectId, SpawnId
from space.ctx.constitute import build
from space.ctx.prompt import resume, run, swarm
from space.lib import paths, providers
from space.os import agents, projects

_CTX_DIR = Path(__file__).parent
CONSTITUTIONS_DIR = _CTX_DIR / "constitutions"

PROVIDER_MAP = {
    "claude": "CLAUDE.md",
    "gemini": "GEMINI.md",
    "codex": "AGENTS.md",
}

__all__ = [
    "CONSTITUTIONS_DIR",
    "build",
    "constitution_path",
    "inject",
    "preview",
    "resume",
    "run",
    "swarm",
]


def constitution_path(name: str) -> Path:
    if name.startswith("/") or ".." in name or not name:
        raise ValidationError(f"Invalid constitution name: {name}")
    if name.endswith(".md"):
        return CONSTITUTIONS_DIR / name
    return CONSTITUTIONS_DIR / f"{name}.md"


def inject(spawn: Spawn, agent: Agent) -> Path:
    """Write constitution to provider-specific file."""
    target_dir = paths.identity_dir(agent.identity)
    target_dir.mkdir(parents=True, exist_ok=True)

    gitconfig = target_dir / ".gitconfig"
    gitconfig.write_text(
        f"[user]\n\tname = {agent.identity}\n\temail = {agent.identity}@space.local\n"
    )

    provider = providers.map(agent.model) if agent.model else "claude"
    config_file = PROVIDER_MAP.get(provider, "CLAUDE.md")
    content = build(agent)

    (target_dir / config_file).write_text(content)

    return target_dir


def preview(identity: str, cwd: Path | None = None) -> str:
    """Preview what an agent with given identity would see in swarm mode."""
    try:
        agent = agents.get_by_identity(identity)
    except NotFoundError:
        agent = Agent(
            id=AgentId("preview"),
            identity=identity,
            model="claude-sonnet-4-20250514",
            constitution=f"{identity}.md"
            if (CONSTITUTIONS_DIR / f"{identity}.md").exists()
            else None,
        )

    constitution_content = build(agent, cwd)

    project = projects.infer_from_cwd() if not cwd else projects.find_by_path(cwd)
    project_id = project.id if project else ProjectId("preview-project")

    fake_spawn = Spawn(
        id=SpawnId("preview-spawn"),
        project_id=project_id,
        agent_id=agent.id,
        status=SpawnStatus.ACTIVE,
    )
    resolved_cwd = (
        str(cwd) if cwd else (project.repo_path if project else None) or str(Path.home() / "space")
    )
    prompt_content = swarm(fake_spawn, resolved_cwd)

    return f"\n=== CLAUDE.md ===\n\n{constitution_content}\n\n\n=== PROMPT ===\n\n{prompt_content}"
