"""Spawn prompt assembly.

Three prompt paths:
- swarm(spawn)          → autonomous daemon (full context + SPACE.md)
- run(agent, cwd, inst) → fire-and-forget (spawn identity + instruction)
- resume(inst)          → session continuation (just the instruction)
"""

import logging
import os
from datetime import UTC, datetime
from pathlib import Path

from space.core.models import Agent, Decision, Project, Spawn, SpawnStatus, Task
from space.core.types import ProjectId
from space.lib import cache, store
from space.lib.format import agent_name
from space.os import agents, decisions, insights, projects, replies, spawns, stats, tasks

logger = logging.getLogger(__name__)

_CTX_DIR = Path(__file__).parent
_CACHE_TTL = 300


def _swarm_age_days() -> int:
    """Days since first insight (swarm inception)."""
    with store.ensure() as conn:
        row = conn.execute(
            "SELECT MIN(created_at) FROM insights WHERE deleted_at IS NULL"
        ).fetchone()
        if not row or not row[0]:
            return 0
        val = row[0]
        if isinstance(val, (int, float)) or (isinstance(val, str) and val.isdigit()):
            start = datetime.fromtimestamp(int(val), tz=UTC)
        else:
            start = datetime.fromisoformat(val).replace(tzinfo=UTC)
        return (datetime.now(UTC) - start).days


def _cached(key: str, fn):
    if (v := cache.get(key)) is not None:
        return v
    cache.set(key, v := fn(), _CACHE_TTL)
    return v


def _read_ctx(name: str) -> str:
    lines = (_CTX_DIR / name).read_text().splitlines()
    content = "\n".join(line for line in lines if not line.startswith("#")).strip()
    if "{swarm_age}" in content:
        content = content.replace("{swarm_age}", str(_swarm_age_days()))
    return content


def swarm(spawn: Spawn, cwd: str | None = None) -> str:
    """Autonomous daemon prompt: full context + SPACE.md."""
    agent = agents.get(spawn.agent_id)

    if not spawn.project_id:
        return _unassigned_prompt(agent, spawn)

    project = projects.get(spawn.project_id)
    cwd = cwd or project.repo_path or str(Path.home() / "space")

    parts = [
        _spawn_block(agent, cwd, project),
        _read_ctx("swarm.md"),
        _history_block(agent, spawn),
        _swarm_block(agent, project),
        _space_block(cwd),
    ]
    return "\n\n".join(p for p in parts if p)


def _unassigned_prompt(agent: Agent, spawn: Spawn) -> str:
    """Prompt for unassigned spawn: agent chooses project."""
    lines = [
        f"identity: {agent.identity}",
        f"today: {datetime.now(UTC).strftime('%Y-%m-%d')}",
        "",
        "You are unassigned. Choose a project to work on.",
        "",
        "## Projects",
        "",
    ]

    all_projects = projects.fetch()
    for p in all_projects:
        open_q = insights.fetch_open(project_id=p.id, limit=10)
        unclaimed = tasks.fetch(project_id=p.id, unassigned=True, limit=10)
        proposed = decisions.fetch_by_status("proposed", project_id=p.id, limit=10)
        committed = decisions.fetch_by_status("committed", project_id=p.id, limit=10)
        parts = []
        if open_q:
            parts.append(f"{len(open_q)} questions")
        if unclaimed:
            parts.append(f"{len(unclaimed)} tasks")
        if proposed:
            parts.append(f"{len(proposed)} proposed")
        if committed:
            parts.append(f"{len(committed)} awaiting action")
        summary = ", ".join(parts) if parts else "clear"
        lines.append(f"**{p.name}**: {summary}")
        if p.repo_path:
            lines.append(f"  repo: {_collapse_home(p.repo_path)}")
        if open_q:
            lines.extend(f"    [i/{q.id[:8]}] {q.content}" for q in open_q[:3])
        if unclaimed:
            lines.extend(f"    [t/{t.id[:8]}] {t.content}" for t in unclaimed[:3])
        if proposed:
            lines.extend(f"    [d/{d.id[:8]}] PROPOSED: {d.content}" for d in proposed[:2])
        if committed:
            lines.extend(f"    [d/{d.id[:8]}] COMMITTED: {d.content}" for d in committed[:2])

    lines.extend(
        [
            "",
            "## Action",
            "",
            "1. `project select <name>` — your artifacts will be scoped here",
            "2. `cd <repo path>` — to work in the codebase",
            '3. `task doing "intent"` — begin work',
        ]
    )

    return "\n".join(lines)


def run(agent: Agent, cwd: str, instruction: str) -> str:
    """Fire-and-forget prompt: spawn identity + instruction."""
    return f"{_spawn_block(agent, cwd)}\n\n{instruction}"


def resume(
    instruction: str = "continue",
    images: list[str] | None = None,
    spawn: Spawn | None = None,
    cwd: str | None = None,
) -> str:
    """Session continuation with fresh swarm state.

    Long-lived sessions accumulate stale context. Inject current
    decisions/insights so resumed agents don't act on outdated data.
    """
    if not spawn or not spawn.project_id:
        return instruction

    agent = agents.get(spawn.agent_id)
    project = projects.get(spawn.project_id)

    fresh_state = _swarm_block(agent, project)
    if not fresh_state:
        return instruction

    return f"<system-reminder>\nContext refresh (session resumed):\n{fresh_state}\n</system-reminder>\n\n{instruction}"


def _collapse_home(path: str) -> str:
    home = str(Path.home())
    return path.replace(home, "~") if path.startswith(home) else path


def _agent_lens(agent: Agent | None) -> str | None:
    if not agent or not agent.constitution:
        return None
    try:
        c = agents.constitutions.load(agent.constitution)
        return c.lens[0] if c.lens else None
    except Exception:
        return None


def _agent_lens_by_identity(identity: str) -> str | None:
    agent = agents.get_by_identity(identity)
    return _agent_lens(agent)


def _spawn_block(agent: Agent, cwd: str, project: Project | None = None) -> str:
    """Agent identity and situation."""
    lines = [
        f"identity: {agent.identity}",
        f"project: {project.name}" if project else "project: (none)",
        f"cwd: {_collapse_home(cwd)}",
        f"today: {datetime.now(UTC).strftime('%Y-%m-%d')}",
    ]

    concurrency = os.environ.get("SPACE_SWARM_CONCURRENCY")
    remaining = os.environ.get("SPACE_SWARM_REMAINING")
    if concurrency and remaining:
        lines.append(f"budget: {remaining} spawns remaining, {concurrency} concurrent")
    elif concurrency:
        lines.append(f"concurrency: {concurrency}")

    return f"<spawn>\n{chr(10).join(lines)}\n</spawn>"


def _history_block(agent: Agent, current_spawn: Spawn) -> str:
    """Prior spawn summaries for continuity."""
    prior = spawns.fetch(
        agent_id=agent.id,
        project_id=current_spawn.project_id,
        status=SpawnStatus.DONE,
        limit=3,
    )
    prior = [s for s in prior if s.summary and s.id != current_spawn.id]

    if not prior:
        return ""

    lines = []
    for s in prior:
        if s.last_active_at:
            last = datetime.fromisoformat(s.last_active_at)
            delta = datetime.now(UTC) - last
            hours = int(delta.total_seconds() // 3600)
            if hours < 1:
                ago = "<1h ago"
            elif hours < 24:
                ago = f"{hours}h ago"
            else:
                ago = f"{hours // 24}d ago"
        else:
            ago = "?"

        ps_insights = insights.fetch(spawn_id=s.id, limit=10)
        ps_decisions = decisions.fetch(spawn_id=s.id, limit=10)
        artifact_ids = [f"i/{i.id[:8]}" for i in ps_insights[:3]] + [
            f"d/{d.id[:8]}" for d in ps_decisions[:3]
        ]
        if artifact_ids:
            lines.append(f"{ago}: {s.summary} [{', '.join(artifact_ids)}]")
        else:
            lines.append(f"{ago}: {s.summary}")

    return f"<history>\n{chr(10).join(lines)}\n</history>"


def _rate_limit_section(agent: Agent) -> list[str]:
    status_summaries = insights.recent_status_summaries(agent.id, hours=4)
    if not status_summaries:
        return []
    most_recent = status_summaries[0]
    delta = datetime.now(UTC) - datetime.fromisoformat(most_recent.created_at)
    mins = int(delta.total_seconds() // 60)
    return [
        f"RATE LIMIT: status summary posted {mins}m ago [i/{most_recent.id[:8]}]. work elsewhere or sleep.",
        "",
    ]


def _inbox_section(agent: Agent) -> list[str]:
    pending = replies.inbox(agent.identity)
    if not pending:
        return []
    lines = [f"inbox: {len(pending)} mentions"]
    author_ids = list({r.author_id for r in pending[:3]})
    author_map = agents.batch_get(author_ids)
    for r in pending[:3]:
        author = author_map.get(r.author_id)
        name = agent_name(author, r.author_id[:8])
        lines.append(f"  [@{name} {r.parent_type[0]}/{r.parent_id[:8]}] {r.content}")
    lines.append("")
    return lines


def _unclaimed_tasks_section(unclaimed: list[Task]) -> list[str]:
    if not unclaimed:
        return []
    lines = ["unclaimed tasks:"]
    lines.extend(f"  [t/{t.id[:8]}] {t.content}" for t in unclaimed[:5])
    lines.append("")
    return lines


def _domain_questions_section(agent: Agent, project: Project | None) -> list[str]:
    recent = insights.fetch(agent_id=agent.id, limit=10)
    domains = list({i.domain.split("/")[0] for i in recent if i.domain})
    questions = insights.fetch_domain_questions(
        exclude_agent_id=agent.id,
        domains=domains,
        project_id=project.id if project else None,
        limit=3,
    )
    if not questions:
        return []
    lines = ["questions you could answer:"]
    agent_ids = list({q.agent_id for q in questions})
    agent_map = agents.batch_get(agent_ids)
    for q in questions:
        a = agent_map.get(q.agent_id)
        name = a.identity if a else q.agent_id[:8]
        lines.append(f"  [{name}] [i/{q.id[:8]}] #{q.domain}: {q.content}")
    lines.append("")
    return lines


def _new_replies_section(agent: Agent, project: Project | None) -> list[str]:
    prior = spawns.fetch(agent_id=agent.id, status=SpawnStatus.DONE, limit=1)
    if not prior or not prior[0].last_active_at:
        return []
    threads = insights.threads_with_new_replies(
        agent_id=agent.id,
        since=prior[0].last_active_at,
        project_id=project.id if project else None,
        limit=3,
    )
    if not threads:
        return []
    lines = ["your threads with new replies:"]
    for i, count, last_reply in threads:
        lines.append(f"  [i/{i.id[:8]}] +{count}: {last_reply}")
    lines.append("")
    return lines


def _active_agents_section(agent: Agent) -> list[str]:
    active = _cached("prompt:active_spawns", lambda: spawns.fetch(status=SpawnStatus.ACTIVE))
    other_active = [s for s in active if s.agent_id != agent.id]
    if not other_active:
        return []
    agent_ids = list({s.agent_id for s in other_active})
    agent_map = agents.batch_get(agent_ids)
    active_tasks = _cached("prompt:active_tasks", lambda: tasks.fetch(status="active"))
    tasks_by_agent = {t.assignee_id: t for t in active_tasks if t.assignee_id}
    parts = []
    for s in other_active:
        a = agent_map.get(s.agent_id)
        name = a.identity if a else s.agent_id[:8]
        lens_tag = _agent_lens(a)
        display = f"{name}[{lens_tag}]" if lens_tag else name
        claimed = tasks_by_agent.get(s.agent_id)
        parts.append(f"{display} ({claimed.content})" if claimed else display)
    return [f"active: {', '.join(parts)}"]


def _stats_section(
    project: Project | None, unclaimed: list[Task]
) -> tuple[list[str], list[Decision]]:
    project_id = project.id if project else None
    insight_count = _cached(
        f"prompt:insight_count:{project_id}",
        lambda: insights.count(project_id=project_id) if project_id else insights.count(),
    )
    decision_count = _cached(
        f"prompt:decision_count:{project_id}", lambda: decisions.count(project_id=project_id)
    )
    committed = _cached(
        "prompt:committed:global",
        lambda: decisions.fetch_by_status("committed", project_id=None, limit=20),
    )
    parts = []
    if insight_count:
        ref_rate = _cached("prompt:ref_rate", lambda: stats.insight_reference_rate(168))
        parts.append(f"insights: {insight_count} ({ref_rate}% refs)")
    if decision_count:
        parts.append(f"decisions: {decision_count} ({len(committed)} committed)")
    if unclaimed:
        parts.append(f"tasks: {len(unclaimed)} unclaimed")
    return ([" | ".join(parts)] if parts else [], committed)


def _open_questions_section(agent: Agent, project: Project | None) -> list[str]:
    project_id = project.id if project else None
    open_insights = _cached(
        f"prompt:open_insights:{project_id}",
        lambda: insights.fetch_open(project_id=project_id, limit=5),
    )
    if not open_insights:
        return []
    agent_ids = list({i.agent_id for i in open_insights})
    agent_map = agents.batch_get(agent_ids)
    lines = ["", "open questions (unresolved):"]
    for i in open_insights:
        a = agent_map.get(i.agent_id)
        name = a.identity if a else i.agent_id[:8]
        state = replies.thread_state("insight", i.id)
        if state.unique_authors >= 3:
            suffix = f" [{state.reply_count} replies, {state.unique_authors} agents]"
        elif state.awaiting_human:
            suffix = f" [{state.reply_count} replies, awaiting @human]"
        elif state.stale:
            suffix = f" [{state.reply_count} replies, stale]"
        elif state.reply_count:
            suffix = f" [{state.reply_count} replies]"
        else:
            suffix = ""
        lines.append(f"  [{name}] [i/{i.id[:8]}] {i.content}{suffix}")
    return lines


def _decisions_section(committed: list[Decision], project: Project | None) -> list[str]:
    lines: list[str] = []

    if committed:
        validated = insights.validated_decision_ids([d.id for d in committed])

        def is_blocked(d: Decision) -> bool:
            return "@human" in f"{d.content} {d.rationale or ''}".lower()

        actionable = [d for d in committed if not is_blocked(d)]
        blocked = [d for d in committed if is_blocked(d)]

        if actionable:
            lines.extend(["", "actionable now:"])
            for d in actionable[:5]:
                mark = "✓" if d.id in validated else "○"
                lines.append(f"  [{mark}] {d.content}")

        if blocked:
            lines.extend(["", f"blocked ({len(blocked)} waiting on @human):"])
            lines.extend(f"  [○] {d.content[:60]}..." for d in blocked[:3])

    project_id = project.id if project else None
    rejected = _cached(
        f"prompt:rejected:{project_id}",
        lambda: decisions.fetch_rejected_with_reasons(project_id=project_id, limit=3),
    )
    if rejected:
        lines.extend(["", "rejected (don't retry):"])
        for d, reason in rejected:
            lines.append(f"  [✗] {d.content}")
            if reason:
                lines.append(f"      → {reason}")
    return lines


def _recent_insights_section(agent: Agent, project: Project | None) -> list[str]:
    project_id = project.id if project else None
    recent = _cached(
        f"prompt:recent_insights:{project_id}",
        lambda: insights.fetch(project_id=project_id, limit=7),
    )
    if not recent:
        return []
    agent_ids = list({i.agent_id for i in recent})
    agent_map = agents.batch_get(agent_ids)
    lines = ["", "recent insights:"]
    for i in recent:
        a = agent_map.get(i.agent_id)
        name = a.identity if a else i.agent_id[:8]
        if i.agent_id == agent.id:
            suffix = " (you)"
        elif a and a.type == "human":
            suffix = " (human)"
        else:
            suffix = ""
        lines.append(f"  [{name}{suffix}] [i/{i.id[:8]}] #{i.domain}: {i.content}")
    return lines


def _foundational_section(project: Project | None) -> list[str]:
    project_id = project.id if project else None
    foundational = _cached(
        f"prompt:foundational:{project_id}",
        lambda: insights.fetch_foundational(project_id=project_id, min_refs=3, limit=5),
    )
    if not foundational:
        return []
    agent_ids = list({i.agent_id for i, _ in foundational})
    agent_map = agents.batch_get(agent_ids)
    lines = ["", "foundational (3+ references):"]
    for i, ref_count in foundational:
        a = agent_map.get(i.agent_id)
        name = a.identity if a else i.agent_id[:8]
        lines.append(f"  [{name}] [i/{i.id[:8]}] {ref_count} refs: {i.content}")
    return lines


def _silent_agents_section(agent: Agent) -> list[str]:
    silent = _cached("prompt:silent_agents", lambda: agents.silent_agents(hours=24))
    if not silent:
        return []
    parts = []
    for s in silent:
        if s.identity == agent.identity:
            continue
        lens = _agent_lens_by_identity(s.identity)
        parts.append(f"{s.identity}[{lens}]" if lens else s.identity)
    return ["", f"silent (24h): {', '.join(parts)}"] if parts else []


def _is_cold_project(project_id: ProjectId | None) -> bool:
    """Project has no artifacts: first contact."""
    if not project_id:
        return False
    insight_count = _cached(
        f"prompt:insight_count:{project_id}",
        lambda: insights.count(project_id=project_id),
    )
    decision_count = _cached(
        f"prompt:decision_count:{project_id}",
        lambda: decisions.count(project_id=project_id),
    )
    task_count = _cached(
        f"prompt:task_count:{project_id}",
        lambda: len(tasks.fetch(project_id=project_id, limit=1)),
    )
    return insight_count == 0 and decision_count == 0 and task_count == 0


def _cold_project_section(project: Project) -> list[str]:
    """First contact: explore and seed."""
    return [
        "FIRST CONTACT: fresh project, no artifacts exist.",
        "",
        "1. explore: understand structure, stack, purpose",
        "2. seed: create 1-3 insights capturing what you learned",
        "3. surface: propose tasks or questions if obvious work exists",
        "",
        "trust your curiosity. brr.",
        "",
    ]


def _swarm_block(agent: Agent, project: Project | None) -> str:
    """Collective state: active agents, inbox, insights, decisions, tasks."""
    project_id = project.id if project else None
    task_list = _cached(
        f"prompt:pending_tasks:{project_id}",
        lambda: tasks.fetch(status="pending", project_id=project_id, limit=50),
    )
    unclaimed = [t for t in task_list if not t.assignee_id]

    lines: list[str] = []

    if project and _is_cold_project(project_id):
        lines.extend(_cold_project_section(project))

    lines.extend(_rate_limit_section(agent))
    lines.extend(_inbox_section(agent))
    lines.extend(_unclaimed_tasks_section(unclaimed))
    lines.extend(_domain_questions_section(agent, project))
    lines.extend(_new_replies_section(agent, project))
    lines.extend(_active_agents_section(agent))

    stats_lines, committed = _stats_section(project, unclaimed)
    lines.extend(stats_lines)

    lines.extend(_open_questions_section(agent, project))
    lines.extend(_decisions_section(committed, project))

    lines.extend(_recent_insights_section(agent, project))
    lines.extend(_foundational_section(project))

    lines.extend(_silent_agents_section(agent))

    if not lines:
        return ""

    return f"<swarm>\n{chr(10).join(lines)}\n</swarm>"


def _space_block(cwd: str) -> str:
    """SPACE.md content if present."""
    space_md = Path(cwd) / "SPACE.md"
    if not space_md.exists():
        return ""
    content = space_md.read_text().strip()
    return f"<space>\n{content}\n</space>"
