from datetime import UTC, datetime
from uuid import uuid4

from space.core.errors import NotFoundError, StateError, ValidationError
from space.core.models import Task, TaskStatus
from space.core.types import AgentId, DecisionId, ProjectId, SpawnId, TaskId
from space.lib import store
from space.lib.store.sqlite import placeholders
from space.os import agents


def create(
    project_id: ProjectId,
    creator_id: AgentId,
    content: str,
    decision_id: DecisionId | None = None,
    assignee_id: AgentId | None = None,
    spawn_id: SpawnId | None = None,
    done: bool = False,
    result: str | None = None,
) -> Task:
    task_id = TaskId(str(uuid4()))
    now = datetime.now(UTC).isoformat()
    status = TaskStatus.DONE if done else TaskStatus.PENDING
    assignee = creator_id if done else assignee_id
    with store.write() as conn:
        if decision_id:
            store.unarchive("decisions", decision_id, conn)
        conn.execute(
            "INSERT INTO tasks (id, project_id, creator_id, content, assignee_id, created_at, status, spawn_id, decision_id, completed_at, result) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                task_id,
                project_id,
                creator_id,
                content,
                assignee,
                now,
                status.value,
                spawn_id,
                decision_id,
                now if done else None,
                result,
            ),
        )
    return Task(
        id=task_id,
        project_id=project_id,
        creator_id=creator_id,
        content=content,
        status=status,
        assignee_id=assignee,
        spawn_id=spawn_id,
        decision_id=decision_id,
        created_at=now,
        completed_at=now if done else None,
        result=result,
    )


def fetch(
    status: str | None = None,
    assignee_id: AgentId | None = None,
    creator_id: AgentId | None = None,
    spawn_ids: list[SpawnId] | None = None,
    decision_id: DecisionId | None = None,
    include_done: bool = False,
    limit: int | None = None,
    project_id: ProjectId | None = None,
    unassigned: bool = False,
) -> list[Task]:
    with store.ensure() as conn:
        conditions = []
        params: list[str | int] = []

        if spawn_ids:
            ph = placeholders(spawn_ids)
            conditions.append(f"spawn_id IN ({ph})")
            params.extend(spawn_ids)
            include_done = True

        if decision_id:
            conditions.append("decision_id = ?")
            params.append(decision_id)
            include_done = True

        if status:
            conditions.append("status = ?")
            params.append(status)
        elif not include_done:
            conditions.append("status NOT IN (?, ?)")
            params.extend([TaskStatus.DONE.value, TaskStatus.CANCELLED.value])

        if assignee_id:
            conditions.append("assignee_id = ?")
            params.append(assignee_id)

        if creator_id:
            conditions.append("creator_id = ?")
            params.append(creator_id)

        if unassigned:
            conditions.append("assignee_id IS NULL")

        if project_id:
            conditions.append("project_id = ?")
            params.append(project_id)

        query = "SELECT * FROM tasks"
        if conditions:
            query += f" WHERE {' AND '.join(conditions)}"
        query += " ORDER BY created_at DESC"

        if limit:
            query += " LIMIT ?"
            params.append(limit)

        return [store.from_row(row, Task) for row in conn.execute(query, params).fetchall()]


def get(task_id: TaskId) -> Task:
    with store.ensure() as conn:
        row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        if not row:
            raise NotFoundError(task_id)
        return store.from_row(row, Task)


def get_active(agent_id: AgentId) -> Task | None:
    with store.ensure() as conn:
        row = conn.execute(
            "SELECT * FROM tasks WHERE assignee_id = ? AND status = ?",
            (agent_id, TaskStatus.ACTIVE.value),
        ).fetchone()
        if not row:
            return None
        return store.from_row(row, Task)


VALID_TRANSITIONS: dict[TaskStatus, set[TaskStatus]] = {
    TaskStatus.PENDING: {TaskStatus.ACTIVE, TaskStatus.CANCELLED},
    TaskStatus.ACTIVE: {TaskStatus.PENDING, TaskStatus.DONE, TaskStatus.CANCELLED},
    TaskStatus.DONE: set(),
    TaskStatus.CANCELLED: set(),
}


def set_status(
    task_id: TaskId,
    status: TaskStatus,
    agent_id: AgentId | None = None,
    result: str | None = None,
) -> Task:
    task = get(task_id)
    current = task.status
    if status not in VALID_TRANSITIONS.get(current, set()):
        raise StateError(f"Cannot transition from {current.value} to {status.value}")

    now = datetime.now(UTC).isoformat()
    with store.write() as conn:
        if status == TaskStatus.ACTIVE:
            if not agent_id:
                raise ValidationError("agent_id required to claim task")
            conn.execute(
                "UPDATE tasks SET assignee_id = ?, status = ?, started_at = ? WHERE id = ?",
                (agent_id, status.value, now, task_id),
            )
        elif status == TaskStatus.PENDING and current == TaskStatus.ACTIVE:
            if not agent_id:
                raise ValidationError("agent_id required to release task")
            if task.assignee_id and task.assignee_id != agent_id:
                raise ValidationError(f"Task not claimed by agent '{agent_id}'")
            conn.execute(
                "UPDATE tasks SET assignee_id = NULL, status = ?, started_at = NULL WHERE id = ?",
                (status.value, task_id),
            )
        elif status in (TaskStatus.DONE, TaskStatus.CANCELLED):
            if current == TaskStatus.ACTIVE:
                if not agent_id:
                    raise ValidationError("agent_id required to complete active task")
                if task.assignee_id and task.assignee_id != agent_id:
                    raise ValidationError(f"Task not claimed by agent '{agent_id}'")
            conn.execute(
                "UPDATE tasks SET status = ?, completed_at = ?, result = ? WHERE id = ?",
                (status.value, now, result, task_id),
            )
        else:
            conn.execute(
                "UPDATE tasks SET status = ? WHERE id = ?",
                (status.value, task_id),
            )
    return get(task_id)


def update_content(task_id: TaskId, content: str) -> Task:
    get(task_id)
    with store.write() as conn:
        conn.execute(
            "UPDATE tasks SET content = ? WHERE id = ?",
            (content, task_id),
        )
    return get(task_id)


def switch(
    agent_id: AgentId,
    project_id: ProjectId,
    new_content: str,
    spawn_id: SpawnId | None = None,
    decision_id: DecisionId | None = None,
) -> tuple[Task | None, Task]:
    old_task = get_active(agent_id)
    if old_task:
        set_status(old_task.id, TaskStatus.DONE, agent_id=agent_id)
    new_task = create(
        project_id,
        agent_id,
        new_content,
        spawn_id=spawn_id,
        decision_id=decision_id,
        assignee_id=agent_id,
    )
    set_status(new_task.id, TaskStatus.ACTIVE, agent_id=agent_id)
    return old_task, new_task


MAX_CONTENT_LENGTH = 70

STATUS_INDICATORS = {
    TaskStatus.PENDING: " ",
    TaskStatus.ACTIVE: "*",
    TaskStatus.DONE: "x",
    TaskStatus.CANCELLED: "-",
}


def _format_task_line(task: Task, agent_map: dict[AgentId, str] | None = None) -> str:
    short_id = task.id[:8]
    status_char = STATUS_INDICATORS.get(task.status, " ")
    assignee = ""
    if task.assignee_id and agent_map:
        identity = agent_map.get(task.assignee_id, task.assignee_id[:8])
        assignee = f"@{identity} "
    content = task.content[:MAX_CONTENT_LENGTH]
    if len(task.content) > MAX_CONTENT_LENGTH:
        content += "..."
    return f"[{status_char}] [{short_id}] {assignee}{content}"


def format_task_list(task_list: list[Task], agent_id: AgentId | None = None) -> str:
    if not task_list:
        return "No tasks"

    assignee_ids = [t.assignee_id for t in task_list if t.assignee_id]
    agent_map = {}
    if assignee_ids:
        agent_objs = agents.batch_get(assignee_ids)
        agent_map = {aid: agent_objs[aid].identity for aid in agent_objs}

    if not agent_id:
        return "\n".join(_format_task_line(t, agent_map) for t in task_list)

    mine = [t for t in task_list if t.assignee_id and t.assignee_id == agent_id]
    others = [t for t in task_list if not t.assignee_id or t.assignee_id != agent_id]

    lines = []
    if mine:
        lines.append("MY TASKS:")
        lines.extend(f"  {_format_task_line(t, agent_map)}" for t in mine)
    if others:
        if mine:
            lines.append("")
        lines.append("OTHER TASKS:")
        lines.extend(f"  {_format_task_line(t, agent_map)}" for t in others)

    return "\n".join(lines)
