from datetime import datetime
from functools import lru_cache
from typing import Any

from space.core.models import SpawnStatus
from space.lib import store
from space.os import agents, spawns
from space.os.agents import constitutions


@lru_cache(maxsize=32)
def _cached_constitution(name: str) -> tuple[str, list[str]]:
    """Cache constitution description and lens. Cleared on module reload."""
    try:
        const = constitutions.load(name)
        return const.description, const.lens
    except Exception:
        return "", []


def artifacts_per_spawn(hours: int = 24) -> list[dict[str, Any]]:
    """Calculate artifacts/spawn ratio per agent."""
    with store.ensure() as conn:
        rows = conn.execute(
            """
            SELECT
                a.identity,
                COUNT(DISTINCT act.spawn_id) as spawn_count,
                COUNT(act.id) as artifact_count,
                ROUND(CAST(COUNT(act.id) AS FLOAT) / NULLIF(COUNT(DISTINCT act.spawn_id), 0), 2) as ratio
            FROM activity act
            JOIN agents a ON act.agent_id = a.id
            WHERE act.spawn_id IS NOT NULL
              AND act.created_at > datetime('now', ? || ' hours')
              AND act.action = 'created'
            GROUP BY a.identity
            ORDER BY ratio DESC
            """,
            (f"-{hours}",),
        ).fetchall()
    return [{"agent": r[0], "spawns": r[1], "artifacts": r[2], "ratio": r[3]} for r in rows]


def loop_frequency(hours: int = 24) -> dict[str, Any]:
    """Count consecutive same-agent spawns."""
    with store.ensure() as conn:
        rows = conn.execute(
            """
            SELECT agent_id, created_at
            FROM spawns
            WHERE created_at > datetime('now', ? || ' hours')
            ORDER BY created_at
            """,
            (f"-{hours}",),
        ).fetchall()

    if not rows:
        return {"max_consecutive": 0, "agent": None}

    max_consecutive = 1
    max_agent = None
    current_consecutive = 1
    prev_agent = rows[0][0] if rows else None

    for agent_id, _ in rows[1:]:
        if agent_id == prev_agent:
            current_consecutive += 1
            if current_consecutive > max_consecutive:
                max_consecutive = current_consecutive
                max_agent = prev_agent
        else:
            current_consecutive = 1
        prev_agent = agent_id

    agent_name = None
    if max_agent:
        with store.ensure() as conn:
            row = conn.execute("SELECT identity FROM agents WHERE id = ?", (max_agent,)).fetchone()
            agent_name = row[0] if row else max_agent[:8]

    return {"max_consecutive": max_consecutive, "agent": agent_name}


def engagement(hours: int = 24) -> list[dict[str, Any]]:
    """Reply/insight ratio per agent."""
    with store.ensure() as conn:
        rows = conn.execute(
            """
            SELECT
                a.identity,
                SUM(CASE WHEN act.primitive = 'insight' THEN 1 ELSE 0 END) as insights,
                SUM(CASE WHEN act.primitive = 'reply' THEN 1 ELSE 0 END) as replies,
                ROUND(
                    CAST(SUM(CASE WHEN act.primitive = 'reply' THEN 1 ELSE 0 END) AS FLOAT) /
                    NULLIF(SUM(CASE WHEN act.primitive = 'insight' THEN 1 ELSE 0 END), 0),
                    2
                ) as ratio
            FROM activity act
            JOIN agents a ON act.agent_id = a.id
            WHERE act.created_at > datetime('now', ? || ' hours')
              AND act.action = 'created'
              AND act.primitive IN ('insight', 'reply')
            GROUP BY a.identity
            HAVING insights > 0 OR replies > 0
            ORDER BY ratio DESC NULLS LAST
            """,
            (f"-{hours}",),
        ).fetchall()
    return [{"agent": r[0], "insights": r[1], "replies": r[2], "ratio": r[3]} for r in rows]


def compounding(hours: int = 168) -> dict[str, Any]:
    """Measure strategic work (d/* and i/*) citing prior strategic work (d/* or i/*)."""
    with store.ensure() as conn:
        window_total = conn.execute(
            """
            SELECT
                (SELECT COUNT(*) FROM insights
                 WHERE deleted_at IS NULL AND archived_at IS NULL
                   AND created_at > datetime('now', ? || ' hours'))
                +
                (SELECT COUNT(*) FROM decisions
                 WHERE deleted_at IS NULL AND archived_at IS NULL
                   AND created_at > datetime('now', ? || ' hours'))
            """,
            (f"-{hours}", f"-{hours}"),
        ).fetchone()[0]
        window_referencing = conn.execute(
            """
            SELECT COUNT(*) FROM (
                SELECT DISTINCT i.id FROM insights i
                JOIN citations c ON c.source_type = 'insight' AND c.source_id = i.id
                WHERE i.deleted_at IS NULL AND i.archived_at IS NULL
                  AND i.created_at > datetime('now', ? || ' hours')
                UNION
                SELECT DISTINCT d.id FROM decisions d
                JOIN citations c ON c.source_type = 'decision' AND c.source_id = d.id
                WHERE d.deleted_at IS NULL AND d.archived_at IS NULL
                  AND d.created_at > datetime('now', ? || ' hours')
            )
            """,
            (f"-{hours}", f"-{hours}"),
        ).fetchone()[0]
        by_agent = conn.execute(
            """
            SELECT identity, SUM(total) as total, SUM(refs) as refs FROM (
                SELECT
                    a.identity,
                    COUNT(DISTINCT i.id) as total,
                    COUNT(DISTINCT CASE WHEN c.id IS NOT NULL THEN i.id END) as refs
                FROM insights i
                JOIN agents a ON i.agent_id = a.id
                LEFT JOIN citations c ON c.source_type = 'insight' AND c.source_id = i.id
                WHERE i.deleted_at IS NULL AND i.archived_at IS NULL
                  AND i.created_at > datetime('now', ? || ' hours')
                GROUP BY a.identity
                UNION ALL
                SELECT
                    a.identity,
                    COUNT(DISTINCT d.id) as total,
                    COUNT(DISTINCT CASE WHEN c.id IS NOT NULL THEN d.id END) as refs
                FROM decisions d
                JOIN agents a ON d.agent_id = a.id
                LEFT JOIN citations c ON c.source_type = 'decision' AND c.source_id = d.id
                WHERE d.deleted_at IS NULL AND d.archived_at IS NULL
                  AND d.created_at > datetime('now', ? || ' hours')
                GROUP BY a.identity
            )
            GROUP BY identity
            HAVING total >= 3
            ORDER BY refs DESC
            """,
            (f"-{hours}", f"-{hours}"),
        ).fetchall()
    rate = round(window_referencing / window_total * 100, 1) if window_total else 0
    agents_list = [
        {
            "agent": r[0],
            "total": r[1],
            "refs": r[2],
            "rate": round(r[2] / r[1] * 100, 1) if r[1] else 0,
        }
        for r in by_agent
    ]
    return {
        "window_hours": hours,
        "total": window_total,
        "referencing": window_referencing,
        "rate": rate,
        "by_agent": agents_list,
    }


def silent_agents(hours: int = 24) -> list[dict[str, Any]]:
    """Find AI agents with no recent activity."""
    result = agents.silent_agents(hours)
    return [
        {"agent": s.identity, "last_activity": s.last_activity, "hours_silent": s.hours_silent}
        for s in result
    ]


def open_questions() -> int:
    """Count open insights (questions)."""
    with store.ensure() as conn:
        row = conn.execute(
            """
            SELECT COUNT(*) FROM insights
            WHERE open = 1 AND deleted_at IS NULL AND archived_at IS NULL
            """
        ).fetchone()
    return row[0] if row else 0


def task_sovereignty(hours: int = 168) -> dict[str, Any]:
    """Measure self-originated vs assigned tasks per agent."""
    with store.ensure() as conn:
        rows = conn.execute(
            """
            SELECT
                a.identity,
                COUNT(CASE WHEN t.creator_id = t.assignee_id THEN 1 END) as self_created,
                COUNT(CASE WHEN t.creator_id != t.assignee_id OR t.creator_id IS NULL THEN 1 END) as assigned,
                COUNT(*) as total
            FROM tasks t
            JOIN agents a ON t.assignee_id = a.id
            WHERE t.deleted_at IS NULL
              AND t.created_at > datetime('now', ? || ' hours')
            GROUP BY a.identity
            HAVING total >= 3
            ORDER BY total DESC
            """,
            (f"-{hours}",),
        ).fetchall()
        totals = conn.execute(
            """
            SELECT
                COUNT(CASE WHEN t.creator_id = t.assignee_id THEN 1 END) as self_created,
                COUNT(*) as total
            FROM tasks t
            WHERE t.deleted_at IS NULL
              AND t.created_at > datetime('now', ? || ' hours')
            """,
            (f"-{hours}",),
        ).fetchone()
    overall_rate = round(totals[0] / totals[1] * 100, 0) if totals[1] else 0
    return {
        "window_hours": hours,
        "overall_rate": overall_rate,
        "self_created": totals[0],
        "total": totals[1],
        "by_agent": [
            {
                "agent": r[0],
                "self_created": r[1],
                "assigned": r[2],
                "total": r[3],
                "rate": round(r[1] / r[3] * 100, 0) if r[3] else 0,
            }
            for r in rows
        ],
    }


def snapshot() -> dict[str, Any]:
    """Agent-facing swarm snapshot for mid-session context."""
    with store.ensure() as conn:
        active_spawns = conn.execute(
            """
            SELECT a.identity, COUNT(*) as count
            FROM spawns s
            JOIN agents a ON s.agent_id = a.id
            WHERE s.status = 'active'
            GROUP BY a.identity
            ORDER BY count DESC
            """,
        ).fetchall()

        active_tasks = conn.execute(
            """
            SELECT t.id, t.content, a.identity
            FROM tasks t
            JOIN agents a ON t.assignee_id = a.id
            WHERE t.status = 'active' AND t.deleted_at IS NULL
            ORDER BY t.started_at DESC
            """,
        ).fetchall()

        committed = conn.execute(
            """
            SELECT d.id, d.content
            FROM decisions d
            WHERE d.committed_at IS NOT NULL
              AND d.actioned_at IS NULL AND d.rejected_at IS NULL
              AND d.deleted_at IS NULL AND d.archived_at IS NULL
            ORDER BY d.committed_at DESC
            LIMIT 5
            """,
        ).fetchall()

        open_q = conn.execute(
            """
            SELECT i.id, i.content, a.identity
            FROM insights i
            JOIN agents a ON i.agent_id = a.id
            WHERE i.open = 1 AND i.deleted_at IS NULL AND i.archived_at IS NULL
            ORDER BY i.created_at DESC
            LIMIT 3
            """,
        ).fetchall()

        recent = conn.execute(
            """
            SELECT a.identity, s.summary
            FROM spawns s
            JOIN agents a ON s.agent_id = a.id
            WHERE s.status = 'done' AND s.summary IS NOT NULL AND s.summary != ''
            ORDER BY s.last_active_at DESC
            LIMIT 5
            """,
        ).fetchall()

    return {
        "spawns": [{"agent": r[0], "count": r[1]} for r in active_spawns],
        "active": [{"id": r[0][:8], "content": r[1], "agent": r[2]} for r in active_tasks],
        "committed": [
            {"id": r[0][:8], "content": r[1][:60] if len(r[1]) > 60 else r[1]} for r in committed
        ],
        "questions": [{"id": r[0][:8], "content": r[1], "agent": r[2]} for r in open_q],
        "recent": [{"agent": r[0], "summary": r[1]} for r in recent],
    }


def knowledge_decay(weeks: int = 12) -> dict[str, Any]:
    """Reference rate by insight age bucket. Steep decay = swarm forgetting."""
    with store.ensure() as conn:
        rows = conn.execute(
            """
            SELECT
                CAST((julianday('now') - julianday(i.created_at)) / 7 AS INTEGER) as week_age,
                COUNT(DISTINCT i.id) as total,
                COUNT(DISTINCT CASE WHEN c.id IS NOT NULL THEN i.id END) as referenced
            FROM insights i
            LEFT JOIN citations c ON c.target_type = 'insight'
                AND c.target_short_id = substr(i.id, 1, 8)
            WHERE i.deleted_at IS NULL AND i.archived_at IS NULL
            GROUP BY week_age
            HAVING week_age IS NOT NULL AND week_age < ?
            ORDER BY week_age
            """,
            (weeks,),
        ).fetchall()
    buckets = []
    for r in rows:
        rate = round(r[2] / r[1] * 100, 1) if r[1] else 0
        buckets.append({"week": r[0], "total": r[1], "referenced": r[2], "rate": rate})
    return {"weeks": weeks, "buckets": buckets}


def project_distribution(hours: int = 24) -> dict[str, Any]:
    """Spawns per project over time window. Surfaces attention allocation."""
    with store.ensure() as conn:
        rows = conn.execute(
            """
            SELECT
                COALESCE(p.name, 'unassigned') as project_name,
                COUNT(*) as spawn_count,
                COUNT(DISTINCT s.agent_id) as unique_agents
            FROM spawns s
            LEFT JOIN projects p ON s.project_id = p.id
            WHERE s.created_at > datetime('now', ? || ' hours')
            GROUP BY p.name
            ORDER BY spawn_count DESC
            """,
            (f"-{hours}",),
        ).fetchall()

        total = sum(r[1] for r in rows)

    return {
        "hours": hours,
        "total": total,
        "by_project": [
            {
                "project": r[0],
                "spawns": r[1],
                "agents": r[2],
                "share": round(r[1] / total * 100, 1) if total else 0,
            }
            for r in rows
        ],
    }


def spawn_stats(limit: int = 10) -> list[dict[str, Any]]:
    """Per-spawn productivity stats. Enables self-diagnosis of idle loops."""
    with store.ensure() as conn:
        rows = conn.execute(
            """
            SELECT
                s.id,
                a.identity,
                p.name as project_name,
                s.created_at,
                s.last_active_at,
                s.status,
                s.summary,
                (SELECT COUNT(*) FROM activity act
                 WHERE act.spawn_id = s.id AND act.action = 'created') as artifacts,
                (SELECT COUNT(*) FROM activity act
                 WHERE act.spawn_id = s.id AND act.primitive = 'task'
                   AND act.action IN ('started', 'completed', 'claimed')) as task_transitions,
                (SELECT COUNT(*) FROM insights i WHERE i.spawn_id = s.id) as insights_created,
                (SELECT COUNT(*) FROM decisions d WHERE d.spawn_id = s.id) as decisions_created,
                (SELECT COUNT(*) FROM tasks t WHERE t.spawn_id = s.id) as tasks_created
            FROM spawns s
            JOIN agents a ON s.agent_id = a.id
            LEFT JOIN projects p ON s.project_id = p.id
            WHERE s.status = 'done'
            ORDER BY s.last_active_at DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()

    result = []
    for r in rows:
        total = r[9] + r[10] + r[11]
        insight_only = total > 0 and r[10] == 0 and r[11] == 0
        result.append(
            {
                "id": r[0][:8],
                "agent": r[1],
                "project": r[2] or "unassigned",
                "created_at": r[3],
                "ended_at": r[4],
                "status": r[5],
                "summary": r[6],
                "artifacts": r[7],
                "task_transitions": r[8],
                "insights": r[9],
                "decisions": r[10],
                "tasks": r[11],
                "insight_only": insight_only,
            }
        )
    return result


def status(hours: int = 24) -> dict[str, Any]:
    """Human-readable swarm status for overnight review."""
    with store.ensure() as conn:
        spawn_count = conn.execute(
            "SELECT COUNT(*) FROM spawns WHERE created_at > datetime('now', ? || ' hours')",
            (f"-{hours}",),
        ).fetchone()[0]

        insight_count = conn.execute(
            "SELECT COUNT(*) FROM insights WHERE created_at > datetime('now', ? || ' hours') AND deleted_at IS NULL",
            (f"-{hours}",),
        ).fetchone()[0]

        decision_stats = conn.execute(
            """
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN actioned_at IS NOT NULL THEN 1 ELSE 0 END) as actioned,
                SUM(CASE WHEN rejected_at IS NOT NULL THEN 1 ELSE 0 END) as rejected
            FROM decisions
            WHERE created_at > datetime('now', ? || ' hours') AND deleted_at IS NULL
            """,
            (f"-{hours}",),
        ).fetchone()

        recent_summaries = conn.execute(
            """
            SELECT DISTINCT substr(s.summary, 1, 200) as summary
            FROM spawns s
            WHERE s.summary IS NOT NULL
              AND s.summary <> ''
              AND s.created_at > datetime('now', ? || ' hours')
            ORDER BY s.created_at DESC
            LIMIT 10
            """,
            (f"-{hours}",),
        ).fetchall()

        open_q = conn.execute(
            """
            SELECT i.id, i.content, a.identity
            FROM insights i
            JOIN agents a ON i.agent_id = a.id
            WHERE i.open = 1 AND i.deleted_at IS NULL AND i.archived_at IS NULL
            ORDER BY i.created_at DESC
            LIMIT 5
            """,
        ).fetchall()

        unresolved_mentions = conn.execute(
            """
            SELECT COUNT(*) FROM replies
            WHERE content LIKE '%@human%'
              AND deleted_at IS NULL
              AND created_at > datetime('now', '-48 hours')
            """,
        ).fetchone()[0]

    silent = silent_agents(hours)

    return {
        "hours": hours,
        "spawns": spawn_count,
        "insights": insight_count,
        "decisions": {
            "total": decision_stats[0],
            "actioned": decision_stats[1],
            "rejected": decision_stats[2],
        },
        "recent_summaries": [r[0] for r in recent_summaries],
        "open_questions": [{"id": r[0][:8], "content": r[1][:80], "agent": r[2]} for r in open_q],
        "unresolved_human_mentions": unresolved_mentions,
        "silent_agents": [s["agent"] for s in silent if (s.get("hours_silent") or 0) > hours],
    }


def absence_metrics(hours: int = 168) -> dict[str, Any]:
    """Measure @human absence: how long swarm operates without intervention.

    Three metrics:
    1. block_duration: avg hours from @human mention to human response
    2. completion_autonomy: % tasks completed without human input
    3. input_output_ratio: human inputs / swarm outputs
    """
    with store.ensure() as conn:
        human_ids = [
            r[0]
            for r in conn.execute(
                "SELECT id FROM agents WHERE type = 'human' AND deleted_at IS NULL"
            ).fetchall()
        ]
        if not human_ids:
            return {
                "block_duration_hours": 0,
                "completion_autonomy": 100.0,
                "input_output_ratio": 0,
                "human_inputs": 0,
                "swarm_outputs": 0,
            }

        placeholders = ",".join("?" * len(human_ids))

        human_replies = conn.execute(
            f"""
            SELECT COUNT(*) FROM replies
            WHERE author_id IN ({placeholders})
              AND created_at > datetime('now', ? || ' hours')
              AND deleted_at IS NULL
            """,  # noqa: S608
            [*human_ids, f"-{hours}"],
        ).fetchone()[0]

        human_decisions = conn.execute(
            f"""
            SELECT COUNT(*) FROM decisions
            WHERE agent_id IN ({placeholders})
              AND created_at > datetime('now', ? || ' hours')
              AND deleted_at IS NULL
            """,  # noqa: S608
            [*human_ids, f"-{hours}"],
        ).fetchone()[0]

        human_inputs = human_replies + human_decisions

        swarm_outputs = conn.execute(
            """
            SELECT COUNT(*) FROM activity
            WHERE action = 'created'
              AND created_at > datetime('now', ? || ' hours')
            """,
            (f"-{hours}",),
        ).fetchone()[0]

        io_ratio = round(human_inputs / swarm_outputs, 4) if swarm_outputs else 0

        mentions_with_response = conn.execute(
            f"""
            SELECT
                m.created_at as mention_time,
                MIN(r.created_at) as response_time
            FROM replies m
            JOIN replies r ON r.parent_type = m.parent_type
                          AND r.parent_id = m.parent_id
                          AND r.author_id IN ({placeholders})
                          AND r.created_at > m.created_at
            WHERE m.content LIKE '%@human%'
              AND m.created_at > datetime('now', ? || ' hours')
              AND m.deleted_at IS NULL
            GROUP BY m.id
            """,  # noqa: S608
            [*human_ids, f"-{hours}"],
        ).fetchall()

        if mentions_with_response:
            total_hours = 0
            for mention_time, response_time in mentions_with_response:
                mt = datetime.fromisoformat(mention_time)
                rt = datetime.fromisoformat(response_time)
                total_hours += (rt - mt).total_seconds() / 3600
            avg_block_hours = round(total_hours / len(mentions_with_response), 1)
        else:
            avg_block_hours = 0

        total_tasks = conn.execute(
            """
            SELECT COUNT(*) FROM tasks
            WHERE completed_at IS NOT NULL
              AND created_at > datetime('now', ? || ' hours')
              AND deleted_at IS NULL
            """,
            (f"-{hours}",),
        ).fetchone()[0]

        human_touched_tasks = conn.execute(
            f"""
            SELECT COUNT(DISTINCT t.id) FROM tasks t
            JOIN replies r ON r.parent_type = 'task'
                          AND r.parent_id = t.id
                          AND r.author_id IN ({placeholders})
            WHERE t.completed_at IS NOT NULL
              AND t.created_at > datetime('now', ? || ' hours')
              AND t.deleted_at IS NULL
            """,  # noqa: S608
            [*human_ids, f"-{hours}"],
        ).fetchone()[0]

        autonomy = (
            round((total_tasks - human_touched_tasks) / total_tasks * 100, 1)
            if total_tasks
            else 100.0
        )

    return {
        "hours": hours,
        "block_duration_hours": avg_block_hours,
        "completion_autonomy": autonomy,
        "input_output_ratio": io_ratio,
        "human_inputs": human_inputs,
        "swarm_outputs": swarm_outputs,
        "tasks_total": total_tasks,
        "tasks_autonomous": total_tasks - human_touched_tasks,
    }


def live() -> list[dict[str, Any]]:
    """All AI agents with health percentage for dashboard display."""
    all_agents = agents.fetch(type="ai")
    if not all_agents:
        return []

    active = spawns.fetch(status=SpawnStatus.ACTIVE)
    active_by_agent = {s.agent_id: s for s in active}

    last_active_map = agents.batch_last_active([a.id for a in all_agents])

    agent_ids = [a.id for a in all_agents]
    placeholders = ",".join("?" * len(agent_ids))
    with store.ensure() as conn:
        last_tasks = conn.execute(
            f"""
            SELECT assignee_id, content FROM (
                SELECT assignee_id, content,
                       ROW_NUMBER() OVER (PARTITION BY assignee_id ORDER BY created_at DESC) as rn
                FROM tasks
                WHERE assignee_id IN ({placeholders}) AND deleted_at IS NULL
            ) WHERE rn = 1
            """,  # noqa: S608
            agent_ids,
        ).fetchall()
    task_map = {r[0]: r[1] for r in last_tasks}

    result = []
    for agent in all_agents:
        spawn = active_by_agent.get(agent.id)

        if spawn:
            usage_data = spawns.usage(spawn)
            used_pct = usage_data.get("percentage", 0) if usage_data else 0
            health_pct = max(0, 100 - used_pct)
            status = "active"
        else:
            health_pct = None
            status = "idle"

        last_task = task_map.get(agent.id, "")
        if len(last_task) > 50:
            last_task = last_task[:50] + "..."

        description, lens = (
            _cached_constitution(agent.constitution) if agent.constitution else ("", [])
        )

        result.append(
            {
                "identity": agent.identity,
                "description": description,
                "health": round(health_pct, 0) if health_pct is not None else None,
                "status": status,
                "task": last_task,
                "lens": lens,
                "last_active": last_active_map.get(agent.id),
                "spawn_id": spawn.id[:8] if spawn else None,
            }
        )

    result.sort(key=lambda x: (x["status"] != "active", x["identity"]))  # type: ignore[reportUnknownLambdaType]
    return result
