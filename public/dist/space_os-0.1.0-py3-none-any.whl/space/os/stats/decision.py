from typing import Any

from space.lib import store


def flow() -> dict[str, int]:
    """Decision status breakdown."""
    with store.ensure() as conn:
        rows = conn.execute(
            """
            SELECT
                CASE
                    WHEN rejected_at IS NOT NULL THEN 'rejected'
                    WHEN actioned_at IS NOT NULL THEN 'actioned'
                    ELSE 'committed'
                END as status,
                COUNT(*) as count
            FROM decisions
            WHERE deleted_at IS NULL AND archived_at IS NULL
            GROUP BY status
            """
        ).fetchall()
    return {r[0]: r[1] for r in rows}


def reversal_rate() -> dict[str, Any]:
    """Committed decisions later rejected. Measures premature commitment."""
    with store.ensure() as conn:
        total_committed = conn.execute(
            """
            SELECT COUNT(*) FROM decisions
            WHERE committed_at IS NOT NULL AND deleted_at IS NULL
            """
        ).fetchone()[0]

        reversed_decisions = conn.execute(
            """
            SELECT COUNT(*) FROM decisions
            WHERE committed_at IS NOT NULL AND rejected_at IS NOT NULL
              AND deleted_at IS NULL
            """
        ).fetchone()[0]

    rate = round(reversed_decisions / total_committed * 100, 1) if total_committed else 0
    return {
        "total_committed": total_committed,
        "reversed": reversed_decisions,
        "reversal_rate": rate,
    }


def half_life() -> dict[str, Any]:
    """Median time from committed to actioned. Decision velocity."""
    with store.ensure() as conn:
        rows = conn.execute(
            """
            SELECT
                (julianday(actioned_at) - julianday(committed_at)) * 24 as hours
            FROM decisions
            WHERE committed_at IS NOT NULL AND actioned_at IS NOT NULL
              AND deleted_at IS NULL
            ORDER BY hours
            """
        ).fetchall()

    if not rows:
        return {"sample_size": 0, "median_hours": None, "p25_hours": None, "p75_hours": None}

    hours_list = [r[0] for r in rows]
    n = len(hours_list)
    median = hours_list[n // 2] if n % 2 else (hours_list[n // 2 - 1] + hours_list[n // 2]) / 2
    p25 = hours_list[n // 4]
    p75 = hours_list[3 * n // 4]

    return {
        "sample_size": n,
        "median_hours": round(median, 1),
        "p25_hours": round(p25, 1),
        "p75_hours": round(p75, 1),
    }


def influence() -> dict[str, Any]:
    """Measure which decisions get referenced (via citations table + FK links)."""
    with store.ensure() as conn:
        total_decisions = conn.execute(
            "SELECT COUNT(*) FROM decisions WHERE deleted_at IS NULL"
        ).fetchone()[0]

        citation_refs = conn.execute(
            """
            SELECT target_short_id, COUNT(*) as ref_count
            FROM citations
            WHERE target_type = 'decision'
            GROUP BY target_short_id
            """
        ).fetchall()

        fk_linked = conn.execute(
            """
            SELECT DISTINCT SUBSTR(decision_id, 1, 8) FROM tasks
            WHERE decision_id IS NOT NULL AND deleted_at IS NULL
            UNION
            SELECT DISTINCT SUBSTR(decision_id, 1, 8) FROM insights
            WHERE decision_id IS NOT NULL AND deleted_at IS NULL
            """
        ).fetchall()

    refs: dict[str, int] = {row[0]: row[1] for row in citation_refs}

    for (prefix,) in fk_linked:
        if prefix:
            refs[prefix] = refs.get(prefix, 0) + 1

    referenced_decisions = len(refs)
    total_refs = sum(refs.values())
    influence_rate = (
        round(referenced_decisions / total_decisions * 100, 1) if total_decisions else 0
    )
    top_decisions = sorted(refs.items(), key=lambda x: -x[1])[:5]

    return {
        "total_decisions": total_decisions,
        "referenced": referenced_decisions,
        "total_refs": total_refs,
        "influence_rate": influence_rate,
        "top": top_decisions,
    }


def precision() -> dict[str, Any]:
    """Measure decision acceptance rate by agent."""
    with store.ensure() as conn:
        rows = conn.execute(
            """
            SELECT
                a.identity,
                SUM(CASE WHEN d.actioned_at IS NOT NULL THEN 1 ELSE 0 END) as actioned,
                SUM(CASE WHEN d.rejected_at IS NOT NULL THEN 1 ELSE 0 END) as rejected,
                COUNT(*) as total
            FROM decisions d
            JOIN agents a ON d.agent_id = a.id
            WHERE d.deleted_at IS NULL
              AND LOWER(d.content) NOT LIKE '%test%'
              AND LOWER(d.rationale) NOT LIKE '%test%'
            GROUP BY a.identity
            HAVING total >= 5
            ORDER BY total DESC
            """
        ).fetchall()

    by_agent = []
    for identity, actioned, rejected, total in rows:
        closed = actioned + rejected
        precision_rate = round(actioned / closed * 100, 1) if closed else None
        by_agent.append(
            {
                "agent": identity,
                "actioned": actioned,
                "rejected": rejected,
                "total": total,
                "precision": precision_rate,
            }
        )

    total_actioned = sum(r["actioned"] for r in by_agent)
    total_rejected = sum(r["rejected"] for r in by_agent)
    total_closed = total_actioned + total_rejected
    overall_precision = round(total_actioned / total_closed * 100, 1) if total_closed else 0

    return {
        "by_agent": by_agent,
        "overall": {
            "actioned": total_actioned,
            "rejected": total_rejected,
            "precision": overall_precision,
        },
    }
