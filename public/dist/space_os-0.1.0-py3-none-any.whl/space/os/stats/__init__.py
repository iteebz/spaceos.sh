from typing import Any

from space.os.stats.comparison import rsi_comparison
from space.os.stats.decision import flow as decision_flow
from space.os.stats.decision import half_life as decision_half_life
from space.os.stats.decision import influence as decision_influence
from space.os.stats.decision import precision as decision_precision
from space.os.stats.decision import reversal_rate as decision_reversal_rate
from space.os.stats.git import code_extension, commit_stability, cross_agent_corrections
from space.os.stats.insight import (
    counterfactual_stats as insight_counterfactual,
)
from space.os.stats.insight import (
    provenance_stats as insight_provenance,
)
from space.os.stats.insight import (
    reference_rate as insight_reference_rate,
)
from space.os.stats.public import get as public_stats
from space.os.stats.public import write as write_public_stats
from space.os.stats.swarm import (
    absence_metrics,
    artifacts_per_spawn,
    compounding,
    engagement,
    knowledge_decay,
    live,
    loop_frequency,
    open_questions,
    project_distribution,
    silent_agents,
    spawn_stats,
    status,
    task_sovereignty,
)
from space.os.stats.swarm import (
    snapshot as swarm,
)

__all__ = [
    "absence_metrics",
    "artifacts_per_spawn",
    "code_extension",
    "commit_stability",
    "compounding",
    "cross_agent_corrections",
    "decision_flow",
    "decision_half_life",
    "decision_influence",
    "decision_precision",
    "decision_reversal_rate",
    "engagement",
    "get_summary",
    "insight_counterfactual",
    "insight_provenance",
    "insight_reference_rate",
    "knowledge_decay",
    "live",
    "loop_frequency",
    "open_questions",
    "project_distribution",
    "public_stats",
    "rsi_comparison",
    "silent_agents",
    "spawn_stats",
    "status",
    "swarm",
    "task_sovereignty",
    "write_public_stats",
]


def get_summary(hours: int = 24) -> dict[str, Any]:
    """Aggregate all stats."""
    return {
        "hours": hours,
        "artifacts_per_spawn": artifacts_per_spawn(hours),
        "loop_frequency": loop_frequency(hours),
        "decision_flow": decision_flow(),
        "open_questions": open_questions(),
        "engagement": engagement(hours),
        "compounding": compounding(),
        "decision_influence": decision_influence(),
        "decision_precision": decision_precision(),
        "task_sovereignty": task_sovereignty(),
        "silent_agents": silent_agents(hours),
        "absence": absence_metrics(hours * 7),
    }
