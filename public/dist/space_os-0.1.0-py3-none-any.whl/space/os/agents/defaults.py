"""Agent registration from constitutions directory."""

from space import ctx
from space.core.models import Agent
from space.lib import store
from space.os import agents

DEFAULT_MODEL = "claude-opus-4-5"


def available_identities() -> list[str]:
    return sorted(p.stem for p in ctx.CONSTITUTIONS_DIR.glob("*.md"))


def ensure_agent(identity: str) -> bool:
    constitution_path = ctx.CONSTITUTIONS_DIR / f"{identity}.md"
    if not constitution_path.exists():
        return False

    existing = _get_by_identity_any(identity)
    if existing:
        if existing.archived_at:
            agents.unarchive(existing.id)
            return True
        return False

    agents.create(
        identity=identity,
        model=DEFAULT_MODEL,
        constitution=f"{identity}.md",
    )
    return True


def _get_by_identity_any(identity: str) -> Agent | None:
    with store.ensure() as conn:
        row = conn.execute(
            "SELECT * FROM agents WHERE identity = ? AND merged_into IS NULL LIMIT 1",
            (identity,),
        ).fetchone()
        return store.from_row(row, Agent) if row else None


def ensure() -> tuple[list[str], list[str]]:
    registered = []
    skipped = []

    for identity in available_identities():
        if ensure_agent(identity):
            registered.append(identity)
        else:
            skipped.append(identity)

    return registered, skipped
