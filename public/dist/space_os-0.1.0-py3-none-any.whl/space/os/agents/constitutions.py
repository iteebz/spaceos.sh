"""Constitution loading with frontmatter parsing.

Constitutions are markdown files with optional YAML frontmatter:

---
lens: [frame-questioning, why-not-how]
tools: [read, ls, glob, grep]
---

# Constitution Content
...
"""

from dataclasses import dataclass
from typing import Any

import yaml

from space import ctx
from space.core.errors import NotFoundError, ValidationError
from space.lib.tools import Tool, parse_tools


@dataclass
class Constitution:
    name: str
    description: str
    lens: list[str]
    tools: set[Tool] | None
    content: str


def parse_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    """Extract YAML frontmatter and body from markdown."""
    if not text.startswith("---"):
        return {}, text

    lines = text.split("\n")
    end_idx = None
    for i, line in enumerate(lines[1:], start=1):
        if line.strip() == "---":
            end_idx = i
            break

    if end_idx is None:
        return {}, text

    frontmatter_text = "\n".join(lines[1:end_idx])
    body = "\n".join(lines[end_idx + 1 :]).lstrip()

    try:
        frontmatter = yaml.safe_load(frontmatter_text) or {}
    except yaml.YAMLError:
        frontmatter = {}

    return frontmatter, body


def load(name: str) -> Constitution:
    """Load constitution with parsed frontmatter."""
    path = ctx.constitution_path(name)
    if not path.exists():
        raise NotFoundError(f"Constitution '{name}' not found")

    try:
        text = path.read_text()
    except Exception as e:
        raise ValidationError(f"Failed to read constitution: {e}") from e

    frontmatter, body = parse_frontmatter(text)

    return Constitution(
        name=name.removesuffix(".md"),
        description=frontmatter.get("description", ""),
        lens=frontmatter.get("lens", []),
        tools=parse_tools(frontmatter.get("tools")),
        content=body,
    )


def get(name: str) -> str:
    """Get raw constitution content (legacy interface)."""
    path = ctx.constitution_path(name)
    if not path.exists():
        raise NotFoundError(f"Constitution '{name}' not found")
    try:
        return path.read_text()
    except Exception as e:
        raise ValidationError(f"Failed to read constitution: {e}") from e


def update(name: str, content: str) -> None:
    path = ctx.constitution_path(name)
    path.parent.mkdir(parents=True, exist_ok=True)

    try:
        temp_path = path.with_suffix(".tmp")
        temp_path.write_text(content)
        temp_path.replace(path)
    except OSError as e:
        raise ValidationError(f"Failed to write constitution: {e}") from e
