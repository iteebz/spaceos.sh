"""Actionable swarm status by project."""

from dataclasses import dataclass

from space.core.types import ProjectId
from space.os import decisions, insights, projects, replies, tasks


@dataclass
class ProjectStatus:
    name: str
    project_id: ProjectId
    open_questions: int
    unclaimed_tasks: int
    committed_decisions: int
    repo_path: str | None


@dataclass
class InboxItem:
    id: str
    content: str
    author: str
    parent_type: str
    parent_id: str


@dataclass
class Status:
    projects: list[ProjectStatus]
    inbox: list[InboxItem]


def get(agent_identity: str | None = None) -> Status:
    """Get actionable status across all projects."""
    all_projects = projects.fetch()

    project_statuses = []
    for p in all_projects:
        open_q = len(insights.fetch_open(project_id=p.id, limit=100))
        unclaimed = len(tasks.fetch(project_id=p.id, unassigned=True, limit=100))
        committed = len(decisions.fetch_by_status("committed", project_id=p.id, limit=100))

        project_statuses.append(
            ProjectStatus(
                name=p.name,
                project_id=p.id,
                open_questions=open_q,
                unclaimed_tasks=unclaimed,
                committed_decisions=committed,
                repo_path=p.repo_path,
            )
        )

    inbox_items = []
    if agent_identity:
        mentions = replies.inbox(agent_identity)
        inbox_items = [
            InboxItem(
                id=r.id[:8],
                content=r.content[:100],
                author=r.author_id[:8],
                parent_type=r.parent_type,
                parent_id=r.parent_id[:8],
            )
            for r in mentions[:10]
        ]

    return Status(projects=project_statuses, inbox=inbox_items)
