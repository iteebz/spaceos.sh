from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from space.core.errors import ConflictError, ValidationError
from space.core.models import Project
from space.lib import git, paths, store
from space.os import projects


@dataclass(frozen=True)
class GitHubRepo:
    owner: str
    name: str
    clone_url: str


_SSH_RE = re.compile(r"^git@github\.com:(?P<owner>[^/]+)/(?P<repo>[^/]+?)(?:\.git)?/?$")
_HTTPS_RE = re.compile(r"^https?://github\.com/(?P<owner>[^/]+)/(?P<repo>[^/]+?)(?:\.git)?/?$")
_SLUG_RE = re.compile(r"^(?P<owner>[^/]+)/(?P<repo>[^/]+?)$")


def parse_github_repo(ref: str) -> GitHubRepo:
    value = (ref or "").strip()
    if not value:
        raise ValidationError("GitHub link is required")

    m = _SSH_RE.match(value) or _HTTPS_RE.match(value)
    if not m:
        slug = _SLUG_RE.match(value)
        if slug:
            owner = slug.group("owner")
            repo = slug.group("repo")
            clone_url = f"https://github.com/{owner}/{repo}.git"
            return GitHubRepo(owner=owner.lower(), name=repo.lower(), clone_url=clone_url)

        raise ValidationError(
            "Unsupported GitHub link. Use https://github.com/owner/repo, git@github.com:owner/repo, or owner/repo"
        )

    owner = m.group("owner").strip()
    repo = m.group("repo").strip()
    if not owner or not repo:
        raise ValidationError("Invalid GitHub link")

    clone_url = f"https://github.com/{owner}/{repo}.git"
    return GitHubRepo(owner=owner.lower(), name=repo.lower(), clone_url=clone_url)


def infer_project_name(github_repo: GitHubRepo, *, explicit_name: str | None = None) -> str:
    name = (explicit_name or github_repo.name or "").strip()
    if not name:
        raise ValidationError("Project name is required")
    if " " in name:
        raise ValidationError("Project name cannot contain spaces")
    return name.lower()


def _bare_repo_path(project_name: str) -> Path:
    return paths.space_root() / "repos" / f"{project_name}.git"


def _existing_or_create_project(name: str, repo_path: Path) -> Project:
    try:
        return projects.create(name, repo_path=str(repo_path))
    except ConflictError:
        existing = store.resolve(name, "projects", Project)
        if existing.repo_path:
            return existing
        return projects.update(existing.id, repo_path=str(repo_path))


def _ensure_default_worktree(bare_repo: Path, branch: str, actions: list[str]) -> Path:
    expected = git.compute_worktree_path(bare_repo, branch)
    if expected.exists():
        actions.append("worktree:exists")
        return expected

    if git.worktree_exists(bare_repo, branch):
        existing = next(
            (wt.path for wt in git.list_worktrees(bare_repo) if wt.branch == branch),
            None,
        )
        if existing:
            actions.append("worktree:located")
            return existing

    wt = git.ensure_worktree(bare_repo, branch)
    actions.append("worktree:restored")
    return wt


def import_github(
    github_link: str,
    *,
    name: str | None = None,
    tags: list[str] | None = None,
) -> tuple[Project, Path, Path, list[str]]:
    """One-click import: sync mirror -> ensure default worktree -> register project -> tag."""
    paths.ensure_dirs()
    gh = parse_github_repo(github_link)
    project_name = infer_project_name(gh, explicit_name=name)

    actions: list[str] = []
    bare_repo = _bare_repo_path(project_name)
    existed = bare_repo.exists()

    git.clone_bare(gh.clone_url, bare_repo)
    actions.append("mirror:cloned" if not existed else "mirror:exists")

    try:
        git.sync(bare_repo)
        actions.append("mirror:fetch")
    except Exception:
        actions.append("mirror:fetch_failed")

    default_branch = git.get_default_branch(bare_repo)
    worktree = _ensure_default_worktree(bare_repo, default_branch, actions)

    project = _existing_or_create_project(project_name, worktree)
    actions.append("project:registered")
    if tags:
        project = projects.add_tags(project.id, tags)
        actions.append("project:tagged")

    return project, bare_repo, worktree, actions
