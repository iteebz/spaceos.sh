"""Daemon: autonomous agent spawning loop."""

import os as _os
import random
import signal
import subprocess
import sys
import time
from dataclasses import replace
from datetime import UTC, datetime, timedelta
from pathlib import Path

from space.core.errors import StateError
from space.core.models import Agent, Project, Spawn, SpawnSource, SpawnStatus
from space.lib import config, logs, state, store
from space.os import agents, insights, projects, spawns
from space.os.stats import public as public_stats

PID_KEY = "daemon_pid"
LAST_GIT_CHECK_KEY = "daemon_last_git_check"
LAST_EMAIL_CHECK_KEY = "daemon_last_email_check"
LAST_SKIP_KEY = "daemon_last_skip"
GIT_CHECK_INTERVAL = 300
EMAIL_CHECK_INTERVAL = 60
CRASH_ERRORS = ["orphaned process", "terminated", "timeout"]
MAX_RESUME_COUNT = 3


def pid() -> int | None:
    daemon_pid = state.get(PID_KEY)
    if not daemon_pid:
        return None
    try:
        _os.kill(daemon_pid, 0)
        return daemon_pid
    except (ProcessLookupError, PermissionError):
        state.delete(PID_KEY)
        return None


def write_pid() -> None:
    state.set(PID_KEY, _os.getpid())


def stop() -> bool:
    daemon_pid = pid()
    if not daemon_pid:
        return False
    try:
        _os.kill(daemon_pid, signal.SIGTERM)
        for _ in range(50):
            time.sleep(0.1)
            if not pid():
                return True
        _os.kill(daemon_pid, signal.SIGKILL)
        return True
    except ProcessLookupError:
        state.delete(PID_KEY)
        return False


def start() -> int | None:
    """Start daemon as background process. Returns pid if started."""
    if pid():
        return pid()

    subprocess.Popen(
        [sys.executable, "-m", "space.os.daemon"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    for _ in range(20):
        time.sleep(0.1)
        if daemon_pid := pid():
            return daemon_pid
    return None


def is_on() -> bool:
    return config.load().swarm.enabled


def on(
    limit: int | None = None,
    concurrency: int | None = None,
    agents_list: list[str] | None = None,
    projects_list: list[str] | None = None,
    *,
    force: bool | None = None,
    reset_filters: bool = False,
) -> bool:
    cfg = config.load()
    was_off = not cfg.swarm.enabled
    cfg.swarm.enabled = True
    if limit is not None:
        cfg.swarm.limit = limit
        cfg.swarm.enabled_at = datetime.now(UTC).isoformat()
    if concurrency is not None:
        cfg.swarm.concurrency = concurrency
    if force is not None:
        cfg.swarm.force = force
    elif reset_filters:
        cfg.swarm.force = False
    if agents_list is not None:
        cfg.swarm.agents = agents_list
    elif reset_filters:
        cfg.swarm.agents = None
    if projects_list is not None:
        cfg.swarm.projects = projects_list
    elif reset_filters:
        cfg.swarm.projects = None
    config.save(cfg)
    return was_off


def off() -> bool:
    if not is_on():
        return False
    cfg = config.load()
    cfg.swarm.enabled = False
    cfg.swarm.limit = None
    config.save(cfg)
    return True


def limit_reached(completed_count: int) -> bool:
    cfg = config.load()
    if cfg.swarm.limit is None:
        return False
    return completed_count >= cfg.swarm.limit


def enabled_at() -> str | None:
    return config.load().swarm.enabled_at


def last_skip() -> str | None:
    return state.get(LAST_SKIP_KEY)


def status() -> dict[str, object]:
    daemon_pid = pid()
    return {
        "running": daemon_pid is not None,
        "pid": daemon_pid,
        "enabled": is_on(),
        "enabled_at": enabled_at(),
        "last_skip": last_skip(),
    }


def tick() -> None:
    try:
        spawns.reconcile()
        _memory_hygiene()
        _update_public_stats()
        if not is_on():
            return
        since = enabled_at()
        if since:
            launched = spawns.fetch(since=since)
            if limit_reached(len(launched)):
                off()
                return
        _check_git_sync()
        _check_email_sync()
        _spawn_tick()
    except Exception as e:
        logs.write("swarm", e, "tick")


def _check_git_sync() -> None:
    from space.lib import git  # noqa: PLC0415

    last_check = state.get(LAST_GIT_CHECK_KEY, 0)
    now = int(time.time())
    if now - last_check < GIT_CHECK_INTERVAL:
        return
    state.set(LAST_GIT_CHECK_KEY, now)

    for project in _get_target_projects():
        if not project.repo_path:
            continue
        repo = Path(project.repo_path)
        if not repo.exists():
            continue
        try:
            git.diverged(repo, fetch=True)
        except Exception as e:
            logs.write("swarm", e, f"git_check:{project.name}")


def _check_email_sync() -> None:
    from space.lib import email  # noqa: PLC0415

    last_check = state.get(LAST_EMAIL_CHECK_KEY, 0)
    now = int(time.time())
    if now - last_check < EMAIL_CHECK_INTERVAL:
        return
    state.set(LAST_EMAIL_CHECK_KEY, now)

    try:
        email.sync_inbound()
    except Exception as e:
        logs.write("swarm", e, "email_check")


def _memory_hygiene() -> None:
    try:
        insights.prune_stale_status()
        spawns.clear_inertia_summaries()
    except Exception as e:
        logs.write("swarm", e, "memory_hygiene")


def _update_public_stats() -> None:
    try:
        public_stats.write()
    except Exception as e:
        logs.write("swarm", e, "public_stats")


def _spawn_tick() -> None:
    target_projects = _get_target_projects()
    if not target_projects:
        raise StateError("Daemon requires configured projects or git repo with registered project")

    active = spawns.fetch(status=SpawnStatus.ACTIVE)
    slots = _available_slots(active)

    if slots > 0:
        resumed = _resume_crashed(slots, active)
        slots -= resumed

    cfg = config.load()
    if not cfg.swarm.force:
        changed_projects = [p for p in target_projects if projects.has_state_change(p.id)]
        if not changed_projects:
            state.set(LAST_SKIP_KEY, datetime.now(UTC).isoformat())
            return

    if slots <= 0:
        return

    for agent in _pick_idle_agents(slots, active):
        _spawn(agent)


def _resume_crashed(slots: int, active: list[Spawn]) -> int:
    """Resume crashed spawns with sessions. Returns count resumed."""
    active_agent_ids = {s.agent_id for s in active}

    crashed = spawns.fetch(
        status=SpawnStatus.DONE,
        has_session=True,
        errors=CRASH_ERRORS,
        limit=slots * 2,
    )

    crashed = [s for s in crashed if s.agent_id not in active_agent_ids]
    crashed = [s for s in crashed if s.resume_count < MAX_RESUME_COUNT]

    cfg = config.load()
    if cfg.swarm.agents:
        agent_map = agents.batch_get([s.agent_id for s in crashed])
        crashed = [
            s
            for s in crashed
            if (a := agent_map.get(s.agent_id)) and a.identity in cfg.swarm.agents
        ]

    resumed = 0
    for spawn in crashed[:slots]:
        agent = agents.get(spawn.agent_id)
        if not agent or not agent.model or agent.archived_at:
            continue
        try:
            count = spawns.increment_resume_count(spawn.id)
            spawns.launch(agent=agent, project_id=spawn.project_id, spawn=spawn)
            logs.info(
                "swarm",
                "crash_resume",
                spawn_id=spawn.id[:8],
                agent=agent.identity,
                error=spawn.error,
                resume_count=count,
            )
            resumed += 1
        except Exception as e:
            logs.write("swarm", e, f"crash_resume:{spawn.id[:8]}")
    return resumed


def _get_target_projects() -> list[Project]:
    cfg = config.load()
    if cfg.swarm.projects:
        resolved = []
        for ref in cfg.swarm.projects:
            try:
                resolved.append(store.resolve(ref, "projects", Project))
            except Exception as e:
                logs.write("swarm", e, f"resolve_project:{ref}")
        return resolved
    if project := projects.infer_from_cwd():
        return [project]
    return []


SPAWN_COOLDOWN_MINUTES = 10


INBOX_WEIGHT = 3


def _pick_idle_agents(count: int, active: list[Spawn]) -> list[Agent]:
    if count <= 0:
        return []
    eligible = _eligible_agents()
    if not eligible:
        return []

    active_ids = {s.agent_id for s in active}
    idle = [a for a in eligible if a.id not in active_ids]

    recent = _recently_spawned_agents()
    cooled = [a for a in idle if a.id not in recent]
    warming = [a for a in idle if a.id in recent]
    with_inbox = insights.agents_with_inbox()

    def agent_weight(a: Agent) -> int:
        return INBOX_WEIGHT if a.identity in with_inbox else 1

    selected: list[Agent] = []
    remaining = [(a, agent_weight(a)) for a in cooled]

    while len(selected) < count and remaining:
        weights = [w for _, w in remaining]
        if sum(weights) == 0:
            break
        [(pick, _)] = random.choices(remaining, weights=weights, k=1)  # noqa: S311
        remaining = [(a, w) for a, w in remaining if a.id != pick.id]
        selected.append(pick)

    if len(selected) < count and warming:
        random.shuffle(warming)
        selected.extend(warming[: count - len(selected)])

    result = selected[:count]

    if result:
        logs.info(
            "swarm",
            "scheduler_pick",
            picked=[a.identity for a in result],
            eligible=[a.identity for a in eligible],
            active=[a.identity for a in agents.batch_get(list(active_ids)).values()],
            cooled=[a.identity for a in cooled],
            warming=[a.identity for a in warming],
            with_inbox=list(with_inbox),
            slots=count,
        )

    return result


def _recently_spawned_agents() -> set[str]:
    cutoff = datetime.now(UTC) - timedelta(minutes=SPAWN_COOLDOWN_MINUTES)
    recent = spawns.fetch(since=cutoff.isoformat())
    return {s.agent_id for s in recent}


def _available_slots(active: list[Spawn]) -> int:
    cfg = config.load()
    limit = cfg.swarm.concurrency
    return max(0, limit - len(active))


def _eligible_agents() -> list[Agent]:
    cfg = config.load()
    all_agents = agents.fetch(type="ai")
    eligible = [a for a in all_agents if a.model and not a.archived_at]
    if cfg.swarm.agents:
        eligible = [a for a in eligible if a.identity in cfg.swarm.agents]
    return eligible


def _spawn(agent: Agent) -> None:
    effective_agent = _apply_model_injection(agent)
    spawns.launch(agent=effective_agent, source=SpawnSource.SWARM)


def _apply_model_injection(agent: Agent) -> Agent:
    cfg = config.load().swarm
    if not cfg.non_opus_ratio or not cfg.non_opus_model:
        return agent

    since = cfg.enabled_at
    if not since:
        return agent

    recent = spawns.fetch(since=since)
    spawn_count = len(recent)

    interval = int(1 / cfg.non_opus_ratio) if cfg.non_opus_ratio > 0 else 0
    if interval > 0 and spawn_count > 0 and (spawn_count + 1) % interval == 0:
        return replace(agent, model=cfg.non_opus_model)

    return agent


TICK_INTERVAL = 2
_running = True


def run(interval: int = TICK_INTERVAL) -> None:
    """Run daemon as standalone process. Handles SIGTERM gracefully."""
    global _running

    def handle_term(_signum, _frame):
        global _running
        _running = False

    signal.signal(signal.SIGTERM, handle_term)
    signal.signal(signal.SIGINT, handle_term)

    logs.reset("swarm")
    write_pid()

    with store.ensure() as conn:
        repaired = store.repair_fts_if_needed(conn)
        if repaired:
            logs.info("swarm", "fts_repair", tables=repaired)

    while _running:
        tick()
        for _ in range(interval):
            if not _running:
                break
            time.sleep(1)

    state.delete(PID_KEY)


if __name__ == "__main__":
    run()
