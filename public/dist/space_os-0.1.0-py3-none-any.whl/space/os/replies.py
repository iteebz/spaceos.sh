import json
import re
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from uuid import uuid4

from space.core.errors import NotFoundError
from space.core.models import Reply
from space.core.types import AgentId, ArtifactType, ProjectId, ReplyId, SpawnId
from space.lib import citations, store
from space.os import artifacts

MENTION_PATTERN = re.compile(r"(?<!\w)@(\w+)")


def _known_identities() -> set[str]:
    """Fetch known agent identities via SQL."""
    with store.ensure() as conn:
        rows = conn.execute("SELECT identity FROM agents WHERE deleted_at IS NULL").fetchall()
    return {r["identity"] for r in rows} | {"human"}


def parse_mentions(content: str, validate: bool = True) -> list[str]:
    raw = MENTION_PATTERN.findall(content)
    if not validate:
        return raw
    known = _known_identities()
    return [m for m in raw if m in known]


def validate_mentions(content: str) -> tuple[list[str], list[str]]:
    """Return (valid, invalid) mentions from content."""
    raw = MENTION_PATTERN.findall(content)
    known = _known_identities()
    valid = [m for m in raw if m in known]
    invalid = [m for m in raw if m not in known]
    return valid, invalid


def _expand_aliases(mentions: list[str]) -> list[str]:
    if "human" not in mentions:
        return mentions
    with store.ensure() as conn:
        rows = conn.execute(
            "SELECT identity FROM agents WHERE type = 'human' AND deleted_at IS NULL"
        ).fetchall()
    human_identities = [r["identity"] for r in rows]
    return [m for m in mentions if m != "human"] + human_identities


def resolve_parent_type(parent_id: str) -> tuple[ArtifactType, str]:
    return artifacts.resolve(parent_id)


def create(
    parent_id: str,
    author_id: AgentId,
    content: str,
    spawn_id: SpawnId | None = None,
    project_id: ProjectId | None = None,
    images: list[str] | None = None,
) -> Reply:
    parent_type, full_parent_id = resolve_parent_type(parent_id)
    mentions = _expand_aliases(parse_mentions(content))

    reply_id = ReplyId(str(uuid4()))
    now = datetime.now(UTC).isoformat()

    with store.write() as conn:
        store.unarchive("agents", author_id, conn)
        conn.execute(
            "INSERT INTO replies (id, parent_type, parent_id, author_id, spawn_id, project_id, content, mentions, images, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                reply_id,
                parent_type,
                full_parent_id,
                author_id,
                spawn_id,
                project_id,
                content,
                json.dumps(mentions) if mentions else None,
                json.dumps(images) if images else None,
                now,
            ),
        )
        citations.store(conn, "reply", reply_id, content)

    return Reply(
        id=reply_id,
        parent_type=parent_type,
        parent_id=full_parent_id,
        author_id=author_id,
        content=content,
        created_at=now,
        spawn_id=spawn_id,
        project_id=project_id,
        mentions=mentions if mentions else None,
        images=images,
    )


def get(reply_id: ReplyId) -> Reply:
    with store.ensure() as conn:
        row = conn.execute("SELECT * FROM replies WHERE id = ?", (reply_id,)).fetchone()
        if not row:
            raise NotFoundError(reply_id)
        return store.from_row(row, Reply)


def fetch_for_parent(parent_type: ArtifactType, parent_id: str) -> list[Reply]:
    with store.ensure() as conn:
        rows = conn.execute(
            "SELECT * FROM replies WHERE parent_type = ? AND parent_id = ? AND deleted_at IS NULL ORDER BY created_at",
            (parent_type, parent_id),
        ).fetchall()
    return [store.from_row(row, Reply) for row in rows]


def inbox(agent_identity: str) -> list[Reply]:
    with store.ensure() as conn:
        rows = conn.execute(
            "SELECT r.* FROM replies r WHERE r.mentions LIKE ? AND r.deleted_at IS NULL ORDER BY r.created_at DESC",
            (f'%"{agent_identity}"%',),
        ).fetchall()

    unresolved = []
    seen_parents: set[tuple[str, str]] = set()

    for row in rows:
        reply = store.from_row(row, Reply)

        parent_key = (reply.parent_type, reply.parent_id)
        if parent_key in seen_parents:
            continue

        if _parent_archived(reply.parent_type, reply.parent_id):
            continue

        has_response = _agent_replied_after(agent_identity, reply)
        if not has_response:
            unresolved.append(reply)
            seen_parents.add(parent_key)

    return unresolved


def _parent_archived(parent_type: ArtifactType, parent_id: str) -> bool:
    return artifacts.is_closed(parent_type, parent_id)


def _agent_replied_after(agent_identity: str, mention_reply: Reply) -> bool:
    with store.ensure() as conn:
        row = conn.execute(
            """
            SELECT 1 FROM replies r
            JOIN agents a ON r.author_id = a.id
            WHERE r.parent_type = ? AND r.parent_id = ?
            AND a.identity = ?
            AND r.created_at > ?
            AND r.deleted_at IS NULL
            LIMIT 1
            """,
            (
                mention_reply.parent_type,
                mention_reply.parent_id,
                agent_identity,
                mention_reply.created_at,
            ),
        ).fetchone()
    return row is not None


@dataclass
class InboxItem:
    reply: Reply
    parent_content: str
    parent_identity: str


def inbox_with_context(agent_identity: str) -> list[InboxItem]:
    replies_list = inbox(agent_identity)
    if not replies_list:
        return []

    items = []
    with store.ensure() as conn:
        for reply in replies_list:
            table = f"{reply.parent_type}s"
            row = conn.execute(
                f"SELECT content, agent_id FROM {table} WHERE id = ?",  # noqa: S608
                (reply.parent_id,),
            ).fetchone()
            if row:
                agent_row = conn.execute(
                    "SELECT identity FROM agents WHERE id = ?",
                    (row["agent_id"],),
                ).fetchone()
                items.append(
                    InboxItem(
                        reply=reply,
                        parent_content=row["content"],
                        parent_identity=agent_row["identity"] if agent_row else "unknown",
                    )
                )
    return items


@dataclass
class ThreadState:
    reply_count: int
    awaiting_human: bool
    stale: bool
    last_reply_at: str | None
    unique_authors: int = 0


def thread_state(parent_type: ArtifactType, parent_id: str) -> ThreadState:
    """Compute thread state with SQL for author types."""
    with store.ensure() as conn:
        rows = conn.execute(
            """
            SELECT r.id, r.mentions, r.created_at, a.type as author_type, r.author_id
            FROM replies r
            LEFT JOIN agents a ON r.author_id = a.id
            WHERE r.parent_type = ? AND r.parent_id = ? AND r.deleted_at IS NULL
            ORDER BY r.created_at ASC
            """,
            (parent_type, parent_id),
        ).fetchall()

    reply_count = len(rows)
    if not rows:
        return ThreadState(reply_count=0, awaiting_human=False, stale=False, last_reply_at=None)

    last_reply_at = rows[-1]["created_at"]
    stale = False
    if last_reply_at:
        last_time = datetime.fromisoformat(last_reply_at)
        stale = datetime.now(UTC) - last_time > timedelta(hours=24)

    awaiting_human = False
    unique_authors: set[str] = set()
    for row in reversed(rows):
        mentions = json.loads(row["mentions"]) if row["mentions"] else []
        if "human" in mentions:
            awaiting_human = True
            break
        if row["author_type"] == "human":
            awaiting_human = False
            break
        unique_authors.add(row["author_id"])

    return ThreadState(
        reply_count=reply_count,
        awaiting_human=awaiting_human,
        stale=stale,
        last_reply_at=last_reply_at,
        unique_authors=len(unique_authors),
    )
