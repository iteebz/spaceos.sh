"""Unified search across all primitives via FTS5."""

from dataclasses import dataclass
from typing import Any

from space.core.errors import ValidationError
from space.core.types import ProjectId
from space.lib import store


@dataclass
class SearchResult:
    source: str
    content: str
    reference: str
    timestamp: str | None = None
    weight: int = 0
    metadata: dict[str, Any] | None = None


@dataclass
class SourceConfig:
    table: str
    fts_table: str
    fts_key: str
    content_field: str
    weight: int
    metadata_fields: list[str]
    soft_delete: str | None = None
    extra_filter: str | None = None


_SOURCES: dict[str, SourceConfig] = {
    "tasks": SourceConfig(
        table="tasks",
        fts_table="tasks_fts",
        fts_key="id",
        content_field="content",
        weight=40,
        metadata_fields=["status"],
        soft_delete="deleted_at",
        extra_filter="status NOT IN ('done', 'cancelled')",
    ),
    "spawns": SourceConfig(
        table="spawns",
        fts_table="spawns_fts",
        fts_key="id",
        content_field="summary",
        weight=35,
        metadata_fields=["status"],
    ),
    "insights": SourceConfig(
        table="insights",
        fts_table="insights_fts",
        fts_key="id",
        content_field="content",
        weight=50,
        soft_delete="deleted_at",
        metadata_fields=["domain"],
    ),
    "decisions": SourceConfig(
        table="decisions",
        fts_table="decisions_fts",
        fts_key="id",
        content_field="content",
        weight=45,
        soft_delete="deleted_at",
        metadata_fields=["rationale"],
    ),
    "replies": SourceConfig(
        table="replies",
        fts_table="replies_fts",
        fts_key="id",
        content_field="content",
        weight=25,
        soft_delete="deleted_at",
        metadata_fields=["parent_type"],
    ),
}

SOURCES = tuple(_SOURCES.keys())


def _fts_escape(term: str) -> str:
    return '"' + term.replace('"', '""') + '"'


def _validate_term(term: str, max_len: int = 256) -> None:
    if len(term) > max_len:
        raise ValidationError(f"Search term too long (max {max_len} chars)")


def _search_source(
    source_name: str,
    cfg: SourceConfig,
    term: str,
    limit: int,
    project_id: ProjectId | None,
    after: str | None = None,
    before: str | None = None,
) -> list[SearchResult]:
    conditions = [
        f"t.{cfg.fts_key} IN (SELECT {cfg.fts_key} FROM {cfg.fts_table} WHERE {cfg.fts_table} MATCH ?)"  # noqa: S608
    ]
    params: list[str | int] = [_fts_escape(term)]

    if cfg.soft_delete:
        conditions.append(f"t.{cfg.soft_delete} IS NULL")
    if cfg.extra_filter:
        conditions.append(f"t.{cfg.extra_filter}")
    if project_id:
        conditions.append("t.project_id = ?")
        params.append(project_id)
    if after:
        conditions.append("t.created_at > ?")
        params.append(after)
    if before:
        conditions.append("t.created_at < ?")
        params.append(before)

    where = " AND ".join(conditions)
    sql = f"SELECT t.* FROM {cfg.table} t WHERE {where} ORDER BY t.created_at DESC LIMIT ?"  # noqa: S608
    params.append(limit)

    with store.ensure() as conn:
        rows = conn.execute(sql, params).fetchall()

    return [
        SearchResult(
            source=source_name,
            content=r[cfg.content_field] or "",
            reference=f"{source_name[0]}/{r['id'][:8]}",
            timestamp=r["created_at"],
            weight=cfg.weight,
            metadata={f: r[f] for f in cfg.metadata_fields},
        )
        for r in rows
    ]


def query(
    term: str,
    scope: str | list[str] = "all",
    after: str | None = None,
    before: str | None = None,
    limit: int = 20,
    project_id: ProjectId | None = None,
) -> list[SearchResult]:
    _validate_term(term)

    scopes = list(SOURCES) if scope == "all" else ([scope] if isinstance(scope, str) else scope)
    results: list[SearchResult] = []
    per_source_limit = limit * 2 if len(scopes) > 1 else limit

    for s in scopes:
        if s in _SOURCES:
            results.extend(
                _search_source(s, _SOURCES[s], term, per_source_limit, project_id, after, before)
            )
    results.sort(key=lambda r: (r.weight, r.timestamp or ""), reverse=True)
    return results[:limit]
