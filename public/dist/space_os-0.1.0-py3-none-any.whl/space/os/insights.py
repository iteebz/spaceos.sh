import json
import logging
from datetime import UTC, datetime, timedelta
from uuid import uuid4

from space.core.errors import NotFoundError, ValidationError
from space.core.models import Insight
from space.core.types import INSIGHT_DOMAINS, AgentId, DecisionId, InsightId, ProjectId, SpawnId
from space.lib import citations, store
from space.os import replies

logger = logging.getLogger(__name__)

MAX_CONTENT_LENGTH = 280


def _compute_provenance(content: str, author_id: AgentId) -> str:
    """Compute insight provenance based on cross-agent citations."""
    cited = citations.extract(content)
    if not cited:
        return "solo"

    with store.ensure() as conn:
        cross_agent_count = 0
        for target_type, short_id in cited:
            table = "insights" if target_type == "insight" else "decisions"
            row = conn.execute(
                f"SELECT agent_id FROM {table} WHERE id LIKE ? AND deleted_at IS NULL",  # noqa: S608
                (f"{short_id}%",),
            ).fetchone()
            if row and row["agent_id"] != author_id:
                cross_agent_count += 1

    if cross_agent_count >= 2:
        return "synthesis"
    if cross_agent_count == 1:
        return "collaborative"
    return "solo"


def validate_domain(domain: str) -> str:
    prefix = domain.split("/")[0]
    if prefix not in INSIGHT_DOMAINS:
        allowed = ", ".join(sorted(INSIGHT_DOMAINS))
        raise ValidationError(f"Unknown domain prefix '{prefix}'. Allowed: {allowed}")
    return domain


def _check_duplicate(content: str, project_id: ProjectId) -> InsightId | None:
    """Return existing insight ID if exact duplicate exists, else None."""
    with store.ensure() as conn:
        row = conn.execute(
            "SELECT id FROM insights WHERE content = ? AND project_id = ? AND deleted_at IS NULL",
            (content, project_id),
        ).fetchone()
        return InsightId(row["id"]) if row else None


def create(
    project_id: ProjectId,
    agent_id: AgentId,
    content: str,
    domain: str,
    spawn_id: SpawnId | None = None,
    decision_id: DecisionId | None = None,
    images: list[str] | None = None,
    open: bool = False,
) -> Insight:
    domain = validate_domain(domain)

    existing = _check_duplicate(content, project_id)
    if existing:
        raise ValidationError(f"Duplicate insight exists: {existing}")

    if len(content) > MAX_CONTENT_LENGTH:
        raise ValidationError(
            f"Insight content exceeds {MAX_CONTENT_LENGTH} characters ({len(content)}). "
            "Insights must be atomic - compress or log a decision with rationale instead."
        )

    if decision_id:
        with store.ensure() as conn:
            row = conn.execute(
                "SELECT id FROM decisions WHERE id = ? AND deleted_at IS NULL",
                (decision_id,),
            ).fetchone()
            if not row:
                raise ValidationError(
                    f"Decision '{decision_id}' not found — cannot link insight to nonexistent decision"
                )

    insight_id = InsightId(str(uuid4()))
    now = datetime.now(UTC).isoformat()
    mentions = replies.parse_mentions(content)
    provenance = _compute_provenance(content, agent_id)

    with store.write() as conn:
        store.unarchive("agents", agent_id, conn)
        if decision_id:
            store.unarchive("decisions", decision_id, conn)
        conn.execute(
            "INSERT INTO insights (id, project_id, agent_id, spawn_id, decision_id, domain, content, images, open, mentions, created_at, provenance) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                insight_id,
                project_id,
                agent_id,
                spawn_id,
                decision_id,
                domain,
                content,
                json.dumps(images) if images else None,
                1 if open else 0,
                json.dumps(mentions) if mentions else None,
                now,
                provenance,
            ),
        )
        citations.store(conn, "insight", insight_id, content)
    return Insight(
        id=insight_id,
        project_id=project_id,
        agent_id=agent_id,
        domain=domain,
        content=content,
        images=images,
        open=open,
        mentions=mentions if mentions else None,
        created_at=now,
        spawn_id=spawn_id,
        decision_id=decision_id,
        provenance=provenance,
    )


def get(insight_id: InsightId) -> Insight:
    with store.ensure() as conn:
        row = conn.execute("SELECT * FROM insights WHERE id = ?", (insight_id,)).fetchone()
        if not row:
            raise NotFoundError(insight_id)
        return store.from_row(row, Insight)


def fetch(
    agent_id: AgentId | None = None,
    domain: str | None = None,
    spawn_id: SpawnId | None = None,
    decision_id: DecisionId | None = None,
    include_archived: bool = False,
    limit: int | None = None,
    project_id: ProjectId | None = None,
) -> list[Insight]:
    with store.ensure() as conn:
        params: list[str | int] = []
        query = "SELECT * FROM insights WHERE deleted_at IS NULL"

        if project_id:
            query += " AND project_id = ?"
            params.append(project_id)

        if not include_archived:
            query += " AND archived_at IS NULL"

        if agent_id:
            query += " AND agent_id = ?"
            params.append(agent_id)

        if domain:
            if domain.endswith("/*"):
                domain_prefix = domain[:-2]
                query += " AND (domain = ? OR domain LIKE ?)"
                params.extend([domain_prefix, f"{domain_prefix}/%"])
            else:
                query += " AND domain = ?"
                params.append(domain)

        if spawn_id:
            query += " AND spawn_id = ?"
            params.append(spawn_id)

        if decision_id:
            query += " AND decision_id = ?"
            params.append(decision_id)

        query += " ORDER BY created_at DESC"

        if limit:
            query += " LIMIT ?"
            params.append(limit)

        rows = conn.execute(query, params).fetchall()
    return [store.from_row(row, Insight) for row in rows]


def archive(insight_id: InsightId, restore: bool = False) -> Insight:
    with store.write() as conn:
        if restore:
            cursor = conn.execute(
                "UPDATE insights SET archived_at = NULL WHERE id = ? AND deleted_at IS NULL",
                (insight_id,),
            )
        else:
            now = datetime.now(UTC).isoformat()
            cursor = conn.execute(
                "UPDATE insights SET archived_at = ? WHERE id = ? AND deleted_at IS NULL",
                (now, insight_id),
            )
        if cursor.rowcount == 0:
            raise NotFoundError(f"Insight '{insight_id}' not found")
    return get(insight_id)


def delete(insight_id: InsightId) -> None:
    now = datetime.now(UTC).isoformat()
    with store.write() as conn:
        cursor = conn.execute(
            "UPDATE insights SET deleted_at = ? WHERE id = ? AND deleted_at IS NULL",
            (now, insight_id),
        )
        if cursor.rowcount == 0:
            raise NotFoundError(f"Insight '{insight_id}' not found or already deleted")


def validated_decision_ids(decision_ids: list[DecisionId]) -> set[DecisionId]:
    """Return subset of decision_ids that have at least one linked insight."""
    if not decision_ids:
        return set()
    placeholders = ",".join("?" * len(decision_ids))
    with store.ensure() as conn:
        rows = conn.execute(
            f"SELECT DISTINCT decision_id FROM insights WHERE decision_id IN ({placeholders}) AND deleted_at IS NULL",  # noqa: S608
            decision_ids,
        ).fetchall()
    return {DecisionId(row["decision_id"]) for row in rows}


def fetch_by_decision_ids(decision_ids: list[DecisionId]) -> dict[DecisionId, list[Insight]]:
    """Batch fetch insights grouped by decision_id."""
    if not decision_ids:
        return {}
    placeholders = ",".join("?" * len(decision_ids))
    with store.ensure() as conn:
        rows = conn.execute(
            f"SELECT * FROM insights WHERE decision_id IN ({placeholders}) AND deleted_at IS NULL ORDER BY created_at",  # noqa: S608
            decision_ids,
        ).fetchall()
    result: dict[DecisionId, list[Insight]] = {did: [] for did in decision_ids}
    for row in rows:
        insight = store.from_row(row, Insight)
        if insight.decision_id:
            result[insight.decision_id].append(insight)
    return result


def count(include_archived: bool = False, project_id: ProjectId | None = None) -> int:
    with store.ensure() as conn:
        params: list[str] = []
        query = "SELECT COUNT(*) FROM insights WHERE deleted_at IS NULL"
        if not include_archived:
            query += " AND archived_at IS NULL"
        if project_id:
            query += " AND project_id = ?"
            params.append(project_id)
        return conn.execute(query, params).fetchone()[0]


def fetch_open(project_id: ProjectId | None = None, limit: int | None = None) -> list[Insight]:
    """Fetch open insights (unresolved questions)."""
    with store.ensure() as conn:
        params: list[str | int] = []
        query = (
            "SELECT * FROM insights WHERE open = 1 AND deleted_at IS NULL AND archived_at IS NULL"
        )

        if project_id:
            query += " AND project_id = ?"
            params.append(project_id)

        query += " ORDER BY created_at DESC"

        if limit:
            query += " LIMIT ?"
            params.append(limit)

        rows = conn.execute(query, params).fetchall()
    return [store.from_row(row, Insight) for row in rows]


def fetch_closed(project_id: ProjectId | None = None, limit: int | None = None) -> list[Insight]:
    """Fetch closed insights (resolved questions) via activity log."""
    with store.ensure() as conn:
        params: list[str | int] = []
        query = """
            SELECT i.* FROM insights i
            INNER JOIN activity a ON a.primitive = 'insight' AND a.primitive_id = i.id AND a.action = 'resolved'
            WHERE i.open = 0 AND i.deleted_at IS NULL AND i.archived_at IS NULL
        """

        if project_id:
            query += " AND i.project_id = ?"
            params.append(project_id)

        query += " ORDER BY a.created_at DESC"

        if limit:
            query += " LIMIT ?"
            params.append(limit)

        rows = conn.execute(query, params).fetchall()
    return [store.from_row(row, Insight) for row in rows]


def close(insight_id: InsightId, counterfactual: bool | None = None) -> Insight:
    """Close an open insight. Optionally record counterfactual (could single agent have found this?)."""
    with store.write() as conn:
        if counterfactual is not None:
            cursor = conn.execute(
                "UPDATE insights SET open = 0, counterfactual = ? WHERE id = ? AND deleted_at IS NULL",
                (1 if counterfactual else 0, insight_id),
            )
        else:
            cursor = conn.execute(
                "UPDATE insights SET open = 0 WHERE id = ? AND deleted_at IS NULL",
                (insight_id,),
            )
        if cursor.rowcount == 0:
            raise NotFoundError(f"Insight '{insight_id}' not found")
    return get(insight_id)


def inbox(agent_identity: str) -> list[Insight]:
    """Fetch insights that mention the given agent and haven't been replied to."""
    with store.ensure() as conn:
        rows = conn.execute(
            """
            SELECT i.* FROM insights i
            WHERE i.mentions LIKE ?
              AND i.deleted_at IS NULL
              AND i.archived_at IS NULL
              AND NOT EXISTS (
                SELECT 1 FROM replies r
                JOIN agents a ON r.author_id = a.id
                WHERE r.parent_type = 'insight'
                  AND r.parent_id = i.id
                  AND a.identity = ?
                  AND r.deleted_at IS NULL
              )
            ORDER BY i.created_at DESC
            """,
            (f'%"{agent_identity}"%', agent_identity),
        ).fetchall()
    return [store.from_row(row, Insight) for row in rows]


def agents_with_inbox() -> set[str]:
    """Return identities of agents with unresolved inbox items (single query)."""
    with store.ensure() as conn:
        rows = conn.execute(
            """
            SELECT DISTINCT json_each.value as identity
            FROM insights i, json_each(i.mentions)
            WHERE i.deleted_at IS NULL
              AND i.archived_at IS NULL
              AND i.mentions IS NOT NULL
              AND NOT EXISTS (
                SELECT 1 FROM replies r
                JOIN agents a ON r.author_id = a.id
                WHERE r.parent_type = 'insight'
                  AND r.parent_id = i.id
                  AND a.identity = json_each.value
                  AND r.deleted_at IS NULL
              )
            UNION
            SELECT DISTINCT json_each.value as identity
            FROM replies r, json_each(r.mentions)
            WHERE r.deleted_at IS NULL
              AND r.mentions IS NOT NULL
              AND NOT EXISTS (
                SELECT 1 FROM replies r2
                JOIN agents a ON r2.author_id = a.id
                WHERE r2.parent_type = r.parent_type
                  AND r2.parent_id = r.parent_id
                  AND a.identity = json_each.value
                  AND r2.created_at > r.created_at
                  AND r2.deleted_at IS NULL
              )
            """
        ).fetchall()
    return {row["identity"] for row in rows}


def fetch_domain_questions(
    exclude_agent_id: AgentId,
    domains: list[str],
    project_id: ProjectId | None = None,
    limit: int = 3,
) -> list[Insight]:
    """Fetch open questions by others in specified domains."""
    if not domains:
        return []

    with store.ensure() as conn:
        domain_conditions = " OR ".join(["domain LIKE ?" for _ in domains])
        params: list[str] = [f"{d}%" for d in domains]
        params.append(exclude_agent_id)

        query = f"""
            SELECT * FROM insights
            WHERE open = 1
            AND deleted_at IS NULL AND archived_at IS NULL
            AND ({domain_conditions})
            AND agent_id != ?
        """  # noqa: S608

        if project_id:
            query += " AND project_id = ?"
            params.append(project_id)

        query += f" ORDER BY created_at DESC LIMIT {limit}"
        rows = conn.execute(query, params).fetchall()

    return [store.from_row(row, Insight) for row in rows]


def fetch_foundational(
    project_id: ProjectId | None = None,
    min_refs: int = 3,
    min_age_days: int = 0,
    limit: int = 3,
) -> list[tuple[Insight, int]]:
    """Fetch highly referenced insights (foundational knowledge)."""
    with store.ensure() as conn:
        params: list[str | int] = [min_age_days, min_refs]
        base_query = """
            SELECT i.*,
                (
                    SELECT COUNT(*) FROM replies r
                    WHERE r.parent_id = i.id AND r.parent_type = 'insight'
                ) + (
                    SELECT COUNT(*) FROM citations c
                    WHERE c.target_type = 'insight' AND c.target_short_id = substr(i.id, 1, 8)
                ) as total_refs
            FROM insights i
            WHERE i.deleted_at IS NULL AND i.archived_at IS NULL
              AND julianday('now') - julianday(i.created_at) >= ?
        """

        if project_id:
            base_query += " AND i.project_id = ?"
            params.insert(1, project_id)

        query = f"""
            SELECT * FROM ({base_query}) sub
            WHERE total_refs >= ?
            ORDER BY total_refs DESC LIMIT {limit}
        """  # noqa: S608
        rows = conn.execute(query, params).fetchall()

    return [(store.from_row(row, Insight), row["total_refs"]) for row in rows]


def threads_with_new_replies(
    agent_id: AgentId,
    since: str,
    project_id: ProjectId | None = None,
    limit: int = 3,
) -> list[tuple[Insight, int, str]]:
    """Fetch agent's insights that have replies after a timestamp.

    Returns list of (insight, reply_count, last_reply_preview).
    """
    with store.ensure() as conn:
        params: list[str] = [agent_id]
        query = """
            SELECT * FROM insights
            WHERE agent_id = ?
            AND deleted_at IS NULL AND archived_at IS NULL
        """
        if project_id:
            query += " AND project_id = ?"
            params.append(project_id)
        query += " ORDER BY created_at DESC LIMIT 50"
        rows = conn.execute(query, params).fetchall()

    result: list[tuple[Insight, int, str]] = []
    for row in rows:
        insight = store.from_row(row, Insight)
        thread_replies = replies.fetch_for_parent("insight", insight.id)
        new_replies = sorted(
            [r for r in thread_replies if r.created_at > since and r.author_id != agent_id],
            key=lambda r: r.created_at,
            reverse=True,
        )
        if new_replies:
            last_preview = new_replies[0].content[:40]
            result.append((insight, len(new_replies), last_preview))
            if len(result) >= limit:
                break

    return result


def prune_stale_status(days: int = 3) -> int:
    """Archive old status domain insights that haven't been cited."""
    cutoff = (datetime.now(UTC) - timedelta(days=days)).isoformat()
    now = datetime.now(UTC).isoformat()

    with store.write() as conn:
        cursor = conn.execute(
            """
            UPDATE insights SET archived_at = ?
            WHERE id IN (
                SELECT i.id FROM insights i
                WHERE i.deleted_at IS NULL
                  AND i.archived_at IS NULL
                  AND i.created_at < ?
                  AND (i.domain = 'status' OR i.domain LIKE 'status/%')
                  AND NOT EXISTS (
                    SELECT 1 FROM citations c
                    WHERE c.target_type = 'insight'
                      AND c.target_short_id = substr(i.id, 1, 8)
                  )
            )
            """,
            (now, cutoff),
        )
        return cursor.rowcount


def recent_status_summaries(agent_id: AgentId, hours: int = 4) -> list[Insight]:
    """Fetch status domain insights from agent within time window."""
    cutoff = (datetime.now(UTC) - timedelta(hours=hours)).isoformat()
    with store.ensure() as conn:
        rows = conn.execute(
            """
            SELECT * FROM insights
            WHERE agent_id = ?
              AND deleted_at IS NULL
              AND archived_at IS NULL
              AND created_at > ?
              AND (domain = 'status' OR domain LIKE 'status/%')
            ORDER BY created_at DESC
            """,
            (agent_id, cutoff),
        ).fetchall()
    return [store.from_row(row, Insight) for row in rows]
