"""Spawn runner: subprocess execution with trace capture.

Responsibilities:
- Run subprocess with timeout
- Write stdout to trace file (jsonl)
- Capture session_id from provider output
- Publish events to live subscribers
- Handle process results and errors

Core abstraction: EventProcessor handles the shared event loop logic for both
synchronous runner() and async process_output() paths.
"""

import contextlib
import json
import logging
import subprocess
import tempfile
import threading
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

from space.core.models import Agent, Spawn
from space.core.types import SpawnId
from space.lib import paths, providers
from space.lib.pubsub import Registry
from space.os import spawns

from . import integrity

logger = logging.getLogger(__name__)

MAX_PARSE_ERROR_LINE_CHARS = 500
SESSION_CAPTURE_EVENTS = {
    ("system", "init"): "session_id",
    ("thread.started", None): "thread_id",
}
TOUCH_EVENTS = frozenset({"tool_use", "assistant"})
TERMINATE_EVENTS = frozenset({"turn.completed"})


class SessionExpiredError(RuntimeError):
    pass


@dataclass(slots=True)
class ProcessResult:
    returncode: int
    stdout_lines: list[str]
    stderr: str


class ProcessRunner(Protocol):
    def __call__(
        self,
        cmd: list[str],
        *,
        cwd: Path,
        env: dict[str, str],
        stdin_file: Path | None = None,
        on_line: Callable[[str, object], None] | None = None,
        timeout_seconds: int = 600,
    ) -> ProcessResult: ...


MAX_STDOUT_LINES = 50000

_events: Registry[dict[str, Any]] = Registry()
subscribe = _events.subscribe
unsubscribe = _events.unsubscribe


@dataclass(slots=True)
class EventProcessor:
    """Shared event processing logic for spawn output."""

    spawn_id: SpawnId
    provider: str
    events_file: Path
    output_lines: deque[str]
    pending_session_id: str | None = None
    proc_ref: Any = None
    track_pid: bool = True

    def process_line(self, line: str, proc: Any) -> None:
        if self.proc_ref is None:
            if self.track_pid:
                spawns.set_pid(self.spawn_id, proc.pid, proc)
            self.proc_ref = proc

        self.output_lines.append(line)

        with self.events_file.open("a") as f:
            f.write(line)
            f.flush()

        try:
            event = json.loads(line)
            self._handle_event(event, proc)
        except json.JSONDecodeError as e:
            self._publish_parse_error(line, e)

    def _handle_event(self, event: dict[str, Any], proc: Any) -> None:
        event_type = event.get("type")
        subtype = event.get("subtype")

        for (etype, sub), field in SESSION_CAPTURE_EVENTS.items():
            if event_type == etype and (sub is None or subtype == sub) and field in event:
                self._capture_session_id(event[field])
                break

        _events.publish(self.spawn_id, event)

        if event_type in TOUCH_EVENTS:
            spawns.touch(SpawnId(self.spawn_id))

        if event_type in TERMINATE_EVENTS:
            proc.terminate()

    def _capture_session_id(self, session_id: str) -> None:
        if not session_id:
            return
        self.pending_session_id = session_id
        current = spawns.get(self.spawn_id)
        if current and current.session_id != session_id:
            spawns.update(current.id, session_id=session_id)

    def _publish_parse_error(self, line: str, error: Exception) -> None:
        line_preview = line[:MAX_PARSE_ERROR_LINE_CHARS]
        logger.warning(
            "Spawn %s provider %s: invalid JSONL event line: %r (%s)",
            self.spawn_id[:8],
            self.provider,
            line_preview,
            error,
        )
        _events.publish(
            self.spawn_id,
            {
                "type": "system",
                "subtype": "parse_error",
                "provider": self.provider,
                "error": str(error),
                "line_preview": line_preview,
            },
        )

    def finalize(self) -> None:
        _events.clear(self.spawn_id)
        integrity.finalize(self.spawn_id, self.events_file)


def _make_processor(spawn_id: SpawnId, provider: str, *, track_pid: bool = True) -> EventProcessor:
    spawns_dir = paths.dot_space() / "spawns" / provider
    spawns_dir.mkdir(parents=True, exist_ok=True)
    events_file = spawns_dir / f"{spawn_id}.jsonl"
    return EventProcessor(
        spawn_id=spawn_id,
        provider=provider,
        events_file=events_file,
        output_lines=deque(maxlen=MAX_STDOUT_LINES),
        track_pid=track_pid,
    )


def run_process(
    cmd: list[str],
    *,
    cwd: Path,
    env: dict[str, str],
    stdin_file: Path | None = None,
    on_line: Callable[[str, object], None] | None = None,
    timeout_seconds: int = 600,
) -> ProcessResult:
    stdin = subprocess.DEVNULL
    stdin_handle = None

    if stdin_file:
        stdin_handle = stdin_file.open()
        stdin = stdin_handle

    timed_out = threading.Event()

    def kill_on_timeout() -> None:
        timed_out.set()
        proc.kill()

    try:
        proc = subprocess.Popen(
            cmd,
            stdin=stdin,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=str(cwd),
            env=env,
            bufsize=1,
        )

        timer = threading.Timer(timeout_seconds, kill_on_timeout)
        timer.start()

        stdout_lines = []
        try:
            for line in proc.stdout or []:
                stdout_lines.append(line)
                if on_line:
                    on_line(line, proc)
        finally:
            timer.cancel()

        if timed_out.is_set():
            raise TimeoutError(f"Process exceeded {timeout_seconds}s timeout")

        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()

        _, stderr = proc.communicate()
        return ProcessResult(proc.returncode, stdout_lines, stderr)

    finally:
        if stdin_handle:
            stdin_handle.close()


def runner(
    cmd: list[str],
    stdin_context: str | None,
    agent: Agent,
    spawn: Spawn,
    env: dict[str, str],
    cwd: str | None = None,
    timeout_seconds: int = 600,
    max_retries: int = 1,
    process_runner: ProcessRunner | None = None,
) -> str:
    spawn_dir = Path(cwd) if cwd else paths.identity_dir(agent.identity)
    _runner = process_runner or run_process

    for attempt in range(max_retries + 1):
        try:
            return _execute(
                cmd, stdin_context, agent, spawn, spawn_dir, env, timeout_seconds, _runner
            )
        except SessionExpiredError:
            raise
        except Exception as e:
            if attempt < max_retries:
                logger.warning(
                    f"Spawn {agent.identity} failed (attempt {attempt + 1}), retrying: {e}"
                )
                continue
            logger.error(f"Spawn {agent.identity} failed after {max_retries + 1} attempts: {e}")
            raise

    raise AssertionError("Unreachable: loop must return or raise")


def _execute(
    cmd: list[str],
    stdin_context: str | None,
    agent: Agent,
    spawn: Spawn,
    spawn_dir: Path,
    env: dict[str, str],
    timeout_seconds: int,
    runner: ProcessRunner,
) -> str:
    spawn_id = spawn.id
    provider = providers.map(agent.model) if agent.model else "unknown"
    processor = _make_processor(spawn_id, provider)

    stdin_file = None
    if stdin_context:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write(stdin_context)
            stdin_file = Path(f.name)

    try:
        result = runner(
            cmd,
            cwd=spawn_dir,
            env=env,
            stdin_file=stdin_file,
            on_line=processor.process_line,
            timeout_seconds=timeout_seconds,
        )

        _handle_result(result, spawn_id, provider, processor.pending_session_id)
        processor.finalize()
        return "".join(processor.output_lines)

    finally:
        if stdin_file:
            with contextlib.suppress(Exception):
                stdin_file.unlink()


def process_output(
    proc: subprocess.Popen[str],
    spawn: Spawn,
    agent: Agent,
    timeout_seconds: int = 3600,
) -> None:
    """Process output from already-running subprocess. Used by async launchers."""
    spawn_id = spawn.id
    provider = providers.map(agent.model) if agent.model else "unknown"
    processor = _make_processor(spawn_id, provider, track_pid=False)

    timed_out = threading.Event()

    def kill_on_timeout() -> None:
        timed_out.set()
        proc.kill()

    timer = threading.Timer(timeout_seconds, kill_on_timeout)
    timer.start()

    try:
        for line in proc.stdout or []:
            processor.process_line(line, proc)
    finally:
        timer.cancel()
        _events.clear(spawn_id)

    if timed_out.is_set():
        raise TimeoutError(f"Process exceeded {timeout_seconds}s timeout")

    try:
        proc.wait(timeout=2)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()

    _, stderr = proc.communicate()
    result = ProcessResult(proc.returncode, list(processor.output_lines), stderr or "")
    _handle_result(result, spawn_id, provider, processor.pending_session_id)
    processor.finalize()


def _handle_result(
    result: ProcessResult,
    spawn_id: str,
    provider: str,
    pending_session_id: str | None,
) -> None:
    if pending_session_id:
        spawn = spawns.get(SpawnId(spawn_id))
        if spawn and spawn.session_id != pending_session_id:
            spawns.update(spawn.id, session_id=pending_session_id)

    if result.returncode != 0:
        spawn = spawns.get(SpawnId(spawn_id))

        if (
            spawn
            and spawn.session_id
            and result.stderr
            and "No conversation found" in result.stderr
        ):
            logger.warning(
                f"Spawn {spawn_id[:8]} resume failed (session not found), clearing session_id"
            )
            spawns.update(spawn.id, session_id="")
            raise SessionExpiredError(f"{provider.title()} spawn resume failed: session not found")

        if spawn and spawn.session_id:
            logger.warning(
                f"Spawn {spawn_id[:8]} exited with code {result.returncode} but work was done (has session_id)"
            )
        else:
            raise RuntimeError(f"{provider.title()} spawn failed: {result.stderr}")
