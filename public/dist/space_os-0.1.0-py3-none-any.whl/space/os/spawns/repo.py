from collections.abc import Sequence
from datetime import UTC, datetime
from uuid import uuid4

from space.core.errors import NotFoundError, ValidationError
from space.core.models import Spawn, SpawnSource, SpawnStatus
from space.core.types import UNSET, AgentId, ProjectId, SpawnId, Unset
from space.lib import citations, store
from space.lib.store.sqlite import placeholders


def parse_status_filter(status: str | Sequence[str] | None) -> list[str] | None:
    if not status:
        return None
    if isinstance(status, str):
        return status.split("|") if "|" in status else [status]
    return list(status)


SPAWN_SELECT = "SELECT * FROM spawns"


def create(
    agent_id: AgentId,
    *,
    project_id: ProjectId | None = None,
    caller_spawn_id: SpawnId | None = None,
    source: SpawnSource | None = None,
) -> Spawn:
    spawn_id = SpawnId(str(uuid4()))
    now = datetime.now(UTC).isoformat()

    with store.write() as conn:
        store.unarchive("agents", agent_id, conn)
        conn.execute(
            """
            INSERT INTO spawns
            (id, project_id, agent_id, caller_spawn_id, source, status, created_at)
            VALUES (?, ?, ?, ?, ?, 'active', ?)
            """,
            (spawn_id, project_id, agent_id, caller_spawn_id, source, now),
        )

    return Spawn(
        id=spawn_id,
        agent_id=agent_id,
        project_id=project_id,
        caller_spawn_id=caller_spawn_id,
        source=source,
        status=SpawnStatus.ACTIVE,
        pid=None,
        session_id=None,
        created_at=now,
        last_active_at=None,
        summary=None,
    )


def get_or_create(
    agent_id: AgentId,
    *,
    project_id: ProjectId | None = None,
    caller_spawn_id: SpawnId | None = None,
    source: SpawnSource | None = None,
) -> tuple[Spawn, bool]:
    """Get existing active spawn or create new one. One active spawn per agent (per project if assigned)."""
    spawn_id = SpawnId(str(uuid4()))
    now = datetime.now(UTC).isoformat()

    with store.write() as conn:
        store.unarchive("agents", agent_id, conn)

        if project_id:
            cursor = conn.execute(
                """
                INSERT INTO spawns
                (id, project_id, agent_id, caller_spawn_id, source, status, created_at)
                VALUES (?, ?, ?, ?, ?, 'active', ?)
                ON CONFLICT(agent_id, project_id) WHERE status = 'active' AND project_id IS NOT NULL
                DO NOTHING
                """,
                (spawn_id, project_id, agent_id, caller_spawn_id, source, now),
            )
            if cursor.rowcount == 0:
                row = conn.execute(
                    SPAWN_SELECT + " WHERE agent_id = ? AND project_id = ? AND status = 'active'",
                    (agent_id, project_id),
                ).fetchone()
                if row:
                    return store.from_row(row, Spawn), False
                raise RuntimeError("TOCTOU race: spawn disappeared")
        else:
            cursor = conn.execute(
                """
                INSERT INTO spawns
                (id, project_id, agent_id, caller_spawn_id, source, status, created_at)
                VALUES (?, NULL, ?, ?, ?, 'active', ?)
                ON CONFLICT(agent_id) WHERE status = 'active' AND project_id IS NULL
                DO NOTHING
                """,
                (spawn_id, agent_id, caller_spawn_id, source, now),
            )
            if cursor.rowcount == 0:
                row = conn.execute(
                    SPAWN_SELECT
                    + " WHERE agent_id = ? AND project_id IS NULL AND status = 'active'",
                    (agent_id,),
                ).fetchone()
                if row:
                    return store.from_row(row, Spawn), False
                raise RuntimeError("TOCTOU race: spawn disappeared")

    return (
        Spawn(
            id=spawn_id,
            agent_id=agent_id,
            project_id=project_id,
            caller_spawn_id=caller_spawn_id,
            source=source,
            status=SpawnStatus.ACTIVE,
            pid=None,
            session_id=None,
            created_at=now,
            last_active_at=None,
            summary=None,
        ),
        True,
    )


def update(
    spawn_id: SpawnId,
    *,
    status: SpawnStatus | None = None,
    pid: int | None | Unset = UNSET,
    session_id: str | None = None,
    summary: str | None = None,
    error: str | None | Unset = UNSET,
) -> Spawn:
    if status == SpawnStatus.DONE and summary is None and error is UNSET:
        raise ValidationError("Spawn completion requires summary or error")

    updates: list[str] = []
    params: list[str | int] = []

    if status is not None:
        status_str = status.value
        updates.append("status = ?")
        params.append(status_str)

        now = datetime.now(UTC).isoformat()
        process_exited = status != SpawnStatus.ACTIVE
        if process_exited:
            updates.append("last_active_at = ?")
            params.append(now)
            updates.append("pid = NULL")
        else:
            updates.append("last_active_at = NULL")
            updates.append("error = NULL")

    if pid is not UNSET:
        if pid is None:
            updates.append("pid = NULL")
        else:
            updates.append("pid = ?")
            params.append(pid)

    if session_id is not None:
        updates.append("session_id = ?")
        params.append(session_id)

    summary_changed = False
    if summary is not None:
        updates.append("summary = ?")
        params.append(summary)
        summary_changed = True

    if error is not UNSET:
        if error is None:
            updates.append("error = NULL")
        else:
            updates.append("error = ?")
            params.append(error)

    if not updates:
        return get(spawn_id)

    with store.write() as conn:
        conn.execute(
            f"UPDATE spawns SET {', '.join(updates)} WHERE id = ?",  # noqa: S608 - hardcoded columns
            (*params, spawn_id),
        )
        if summary_changed and summary:
            conn.execute(
                "DELETE FROM citations WHERE source_type = 'spawn' AND source_id = ?", (spawn_id,)
            )
            citations.store(conn, "spawn", spawn_id, summary)
    return get(spawn_id)


def assign_project(spawn_id: SpawnId, project_id: ProjectId) -> Spawn:
    """Assign project to an unassigned spawn. Called when agent selects project."""
    spawn = get(spawn_id)
    if spawn.project_id:
        raise ValidationError(f"Spawn {spawn_id} already assigned to project {spawn.project_id}")

    with store.write() as conn:
        conn.execute(
            "UPDATE spawns SET project_id = ? WHERE id = ?",
            (project_id, spawn_id),
        )
    return get(spawn_id)


def touch(spawn_id: SpawnId) -> None:
    """Update last_active_at timestamp. Called on tool use events."""
    now = datetime.now(UTC).isoformat()
    with store.write() as conn:
        conn.execute(
            "UPDATE spawns SET last_active_at = ? WHERE id = ? AND status = 'active'",
            (now, spawn_id),
        )


def get(spawn_id: SpawnId) -> Spawn:
    with store.ensure() as conn:
        row = conn.execute("SELECT * FROM spawns WHERE id = ?", (spawn_id,)).fetchone()
        if not row:
            raise NotFoundError(spawn_id)
        return store.from_row(row, Spawn)


def fetch(
    agent_id: AgentId | None = None,
    caller_ids: list[SpawnId] | None = None,
    status: SpawnStatus | Sequence[SpawnStatus] | str | Sequence[str] | None = None,
    source: SpawnSource | Sequence[SpawnSource] | str | None = None,
    since: str | None = None,
    has_session: bool = False,
    limit: int | None = None,
    project_id: ProjectId | None = None,
    errors: list[str] | None = None,
    spawn_ids: list[SpawnId] | None = None,
) -> list[Spawn]:
    with store.ensure() as conn:
        query = SPAWN_SELECT + " WHERE 1=1"
        params: list[str | int] = []

        if agent_id:
            query += " AND agent_id = ?"
            params.append(agent_id)

        if caller_ids:
            query += f" AND caller_spawn_id IN ({placeholders(caller_ids)})"
            params.extend(caller_ids)

        if status is not None:
            if isinstance(status, SpawnStatus):
                query += " AND status = ?"
                params.append(status.value)
            elif isinstance(status, str):
                statuses = parse_status_filter(status)
                if statuses:
                    query += f" AND status IN ({placeholders(statuses)})"
                    params.extend(statuses)
            else:
                status_values = [s.value if isinstance(s, SpawnStatus) else s for s in status]
                query += f" AND status IN ({placeholders(status_values)})"
                params.extend(status_values)

        if source is not None:
            if isinstance(source, SpawnSource):
                query += " AND source = ?"
                params.append(source.value)
            elif isinstance(source, str):
                query += " AND source = ?"
                params.append(source)
            else:
                source_values = [s.value if hasattr(s, "value") else s for s in source]
                query += f" AND source IN ({placeholders(source_values)})"
                params.extend(source_values)

        if since:
            query += " AND created_at >= ?"
            params.append(since)

        if has_session:
            query += " AND session_id IS NOT NULL AND session_id != ''"

        if errors:
            query += f" AND error IN ({placeholders(errors)})"
            params.extend(errors)

        if spawn_ids:
            query += f" AND id IN ({placeholders(spawn_ids)})"
            params.extend(spawn_ids)

        if project_id:
            query += " AND project_id = ?"
            params.append(project_id)

        query += " ORDER BY created_at DESC"

        if limit:
            query += " LIMIT ?"
            params.append(limit)

        rows = conn.execute(query, params).fetchall()
        return [store.from_row(row, Spawn) for row in rows]


INERTIA_PATTERNS = (
    "%correctly idle%",
    "%correctly blocked%",
    "%swarm correctly%",
    "%no productive%",
    "%no actionable%",
    "%waiting state%",
)


def clear_inertia_summaries() -> int:
    """Clear spawn summaries that contain inertia patterns."""
    conditions = " OR ".join("summary LIKE ?" for _ in INERTIA_PATTERNS)
    with store.write() as conn:
        cursor = conn.execute(
            f"UPDATE spawns SET summary = NULL WHERE {conditions}",  # noqa: S608
            INERTIA_PATTERNS,
        )
        return cursor.rowcount


def increment_resume_count(spawn_id: SpawnId) -> int:
    """Increment and return resume_count. Called on crash recovery."""
    with store.write() as conn:
        conn.execute(
            "UPDATE spawns SET resume_count = COALESCE(resume_count, 0) + 1 WHERE id = ?",
            (spawn_id,),
        )
        row = conn.execute("SELECT resume_count FROM spawns WHERE id = ?", (spawn_id,)).fetchone()
        return row[0] if row else 0
