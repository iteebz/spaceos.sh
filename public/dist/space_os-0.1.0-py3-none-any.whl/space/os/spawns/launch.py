"""Spawn launch: unified entry point."""

import atexit
import contextlib
import json
import logging
import os
import signal
import subprocess
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from space import ctx
from space.core.errors import StateError
from space.core.models import Agent, Spawn, SpawnSource, SpawnStatus
from space.core.types import ProjectId, SpawnId
from space.lib import config, hooks, paths, providers
from space.lib.tools import Tool
from space.os import agents, projects, spawns

from . import runner
from .runner import ProcessRunner

logger = logging.getLogger(__name__)

MAX_ERR_LEN = 200


def _resolve_cwd(project_id: ProjectId | None) -> str:
    if not project_id:
        return str(Path.home() / "space")
    project = projects.get(project_id)
    return project.repo_path or str(Path.home() / "space")


def launch(
    agent: Agent,
    *,
    project_id: ProjectId | None = None,
    instruction: str | None = None,
    images: list[str] | None = None,
    spawn: Spawn | None = None,
    source: SpawnSource | None = None,
    cwd: str | None = None,
    timeout_seconds: int = 3600,
    caller_spawn_id: SpawnId | None = None,
    _sync: bool = False,
    _process_runner: ProcessRunner | None = None,
) -> Spawn:
    """Launch agent. Async by default, _sync=True for testing."""
    spawn, is_resume = _resolve_spawn(agent, project_id, spawn, caller_spawn_id, source)
    env = _build_env(spawn, agent, project_id)
    resolved_cwd = cwd or _resolve_cwd(project_id)

    if is_resume:
        context = ctx.resume(
            instruction or "continue", images=images, spawn=spawn, cwd=resolved_cwd
        )
    elif instruction:
        context = ctx.run(agent, resolved_cwd, instruction)
    else:
        context = ctx.swarm(spawn, resolved_cwd)

    if _sync:
        _launch_sync(
            agent=agent,
            spawn=spawn,
            is_resume=is_resume,
            context=context,
            images=images if is_resume else None,
            env=env,
            cwd=resolved_cwd,
            timeout_seconds=timeout_seconds,
            process_runner=_process_runner,
        )
    else:
        _launch_background(
            agent=agent,
            spawn=spawn,
            is_resume=is_resume,
            context=context,
            images=images if is_resume else None,
            env=env,
            cwd=resolved_cwd,
            timeout_seconds=timeout_seconds,
        )

    return spawns.get(spawn.id)


def _resolve_spawn(
    agent: Agent,
    project_id: ProjectId | None,
    spawn: Spawn | None,
    caller_spawn_id: SpawnId | None,
    source: SpawnSource | None,
) -> tuple[Spawn, bool]:
    """Resolve spawn: provided → existing active → new."""
    if spawn:
        if spawn.status == SpawnStatus.ACTIVE and spawn.pid:
            raise StateError(f"Spawn '{spawn.id}' is already running (pid {spawn.pid})")
        if spawn.status == SpawnStatus.DONE and not spawn.session_id:
            raise StateError(f"Spawn '{spawn.id}' is DONE with no session, cannot resume")
        is_resume = bool(spawn.session_id)
        ctx.inject(spawn, agent)
        return spawns.update(spawn.id, status=SpawnStatus.ACTIVE), is_resume

    caller_id = caller_spawn_id or (SpawnId(cid) if (cid := paths.spawn_id()) else None)
    spawn, created = spawns.get_or_create(
        agent.id,
        project_id=project_id,
        caller_spawn_id=caller_id,
        source=source,
    )
    ctx.inject(spawn, agent)
    is_resume = not created and bool(spawn.session_id)
    return spawns.update(spawn.id, status=SpawnStatus.ACTIVE), is_resume


def _launch_background(
    agent: Agent,
    spawn: Spawn,
    is_resume: bool,
    context: str,
    images: list[str] | None,
    env: dict[str, str],
    cwd: str,
    timeout_seconds: int,
) -> None:
    """Fire subprocess and return immediately. Spawn is fully sovereign."""
    if not agent.model:
        raise StateError(f"Agent {agent.identity} has no model")

    provider = providers.map(agent.model)
    _write_context_event(spawn.id, provider, "RESUME" if is_resume else "INIT", context)

    cmd, stdin_content = _build_command(agent, spawn.session_id, context, cwd, images=images)
    identity_dir = paths.identity_dir(agent.identity)
    identity_dir.mkdir(parents=True, exist_ok=True)

    merged_env = {**os.environ, **env}

    stdin_file = None
    if stdin_content:
        stdin_file = tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False)
        stdin_file.write(stdin_content)
        stdin_file.close()

    _spawn_sovereign(cmd, Path(cwd), merged_env, stdin_file, spawn, agent, timeout_seconds)


def _spawn_sovereign(
    cmd: list[str],
    cwd: Path,
    env: dict[str, str],
    stdin_file: tempfile._TemporaryFileWrapper[str] | None,
    spawn: Spawn,
    agent: Agent,
    timeout_seconds: int,
) -> None:
    """Double-fork to fully detach, then run Claude with output capture."""
    pid = os.fork()
    if pid > 0:
        os.waitpid(pid, 0)
        return

    os.setsid()

    pid2 = os.fork()
    if pid2 > 0:
        os._exit(0)

    spawns.set_pid(spawn.id, os.getpid())
    _register_cleanup_handlers(spawn.id)

    try:
        _run_sovereign(cmd, cwd, env, stdin_file, spawn, agent, timeout_seconds)
    except Exception as e:
        logger.exception("Sovereign spawn %s failed", spawn.id[:8])
        spawns.update(spawn.id, status=SpawnStatus.DONE, error=str(e)[:MAX_ERR_LEN])
    finally:
        os._exit(0)


def _register_cleanup_handlers(spawn_id: SpawnId) -> None:
    """Register signal and atexit handlers for graceful cleanup."""

    def _cleanup(_signum=None, _frame=None):
        with contextlib.suppress(Exception):
            current = spawns.get(spawn_id)
            if current.status == SpawnStatus.ACTIVE:
                spawns.update(spawn_id, status=SpawnStatus.DONE, error="terminated")
        if _signum is not None:
            os._exit(128 + _signum)

    signal.signal(signal.SIGTERM, _cleanup)
    signal.signal(signal.SIGINT, _cleanup)
    atexit.register(_cleanup)


def _run_sovereign(
    cmd: list[str],
    cwd: Path,
    env: dict[str, str],
    stdin_file: tempfile._TemporaryFileWrapper[str] | None,
    spawn: Spawn,
    agent: Agent,
    timeout_seconds: int,
) -> None:
    """Inner sovereign process: run Claude, capture output, handle lifecycle."""
    stdin_path = Path(stdin_file.name) if stdin_file else None
    try:
        stdin_handle = stdin_path.open() if stdin_path else None

        proc = subprocess.Popen(
            cmd,
            cwd=str(cwd),
            env=env,
            stdin=stdin_handle or subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )

        spawns.set_pid(spawn.id, proc.pid, proc)

        if stdin_handle:
            stdin_handle.close()
    finally:
        if stdin_path:
            stdin_path.unlink(missing_ok=True)

    try:
        runner.process_output(
            proc=proc,
            spawn=spawn,
            agent=agent,
            timeout_seconds=timeout_seconds,
        )
    except TimeoutError:
        spawns.update(spawn.id, status=SpawnStatus.DONE, error="timeout")
        return

    current = spawns.get(spawn.id)
    if current.status == SpawnStatus.ACTIVE:
        spawns.update(spawn.id, status=SpawnStatus.DONE, error="no summary")
    hooks.run_all(current)


def _launch_sync(
    agent: Agent,
    spawn: Spawn,
    is_resume: bool,
    context: str,
    images: list[str] | None,
    env: dict[str, str],
    cwd: str,
    timeout_seconds: int,
    process_runner: ProcessRunner | None = None,
) -> None:
    """Blocking launch for tests. Uses runner.runner() with optional fake."""
    if not agent.model:
        raise StateError(f"Agent {agent.identity} has no model")

    provider = providers.map(agent.model)
    _write_context_event(spawn.id, provider, "RESUME" if is_resume else "INIT", context)

    cmd, stdin = _build_command(agent, spawn.session_id, context, cwd, images=images)

    try:
        runner.runner(
            cmd=cmd,
            stdin_context=stdin,
            agent=agent,
            spawn=spawn,
            env=env,
            cwd=cwd,
            timeout_seconds=timeout_seconds,
            process_runner=process_runner,
        )
    except Exception as exc:
        spawns.update(spawn.id, status=SpawnStatus.DONE, error=str(exc)[:MAX_ERR_LEN])
        raise
    finally:
        current = spawns.get(spawn.id)
        if current.status == SpawnStatus.ACTIVE:
            spawns.update(spawn.id, status=SpawnStatus.DONE, error="no summary")
        hooks.run_all(current)


def _build_env(spawn: Spawn, agent: Agent, project_id: ProjectId | None) -> dict[str, str]:
    env = os.environ.copy()
    env["SPACE_SPAWN_ID"] = spawn.id
    env["SPACE_IDENTITY"] = agent.identity
    if project_id:
        env["SPACE_PROJECT_ID"] = project_id
    env["GIT_AUTHOR_NAME"] = agent.identity
    env["GIT_AUTHOR_EMAIL"] = f"{agent.identity}@space.local"
    env["GIT_COMMITTER_NAME"] = agent.identity
    env["GIT_COMMITTER_EMAIL"] = f"{agent.identity}@space.local"
    env["GIT_CONFIG_GLOBAL"] = str(paths.identity_dir(agent.identity) / ".gitconfig")

    cfg = config.load().swarm
    env["SPACE_SWARM_CONCURRENCY"] = str(cfg.concurrency)
    if cfg.limit is not None and cfg.enabled_at:
        launched = spawns.fetch(since=cfg.enabled_at)
        remaining = max(0, cfg.limit - len(launched))
        env["SPACE_SWARM_REMAINING"] = str(remaining)

    return env


def _build_command(
    agent: Agent,
    session_id: str | None,
    context: str,
    cwd: str | None = None,
    images: list[str] | None = None,
) -> tuple[list[str], str | None]:
    if not agent.model:
        raise StateError(f"Agent {agent.identity} has no model")
    provider = providers.map(agent.model)
    provider_cls = providers.get_provider(provider)

    allowed_tools: set[Tool] | None = None
    if agent.constitution:
        try:
            const = agents.constitutions.load(agent.constitution)
            allowed_tools = const.tools
        except Exception:
            logger.debug("Failed to load constitution %s, using default tools", agent.constitution)

    return provider_cls.build_command(
        model=agent.model,
        session_id=session_id,
        context=context,
        root_dir=str(paths.space_root()),
        cwd=cwd,
        allowed_tools=allowed_tools,
        images=images,
    )


def _write_context_event(spawn_id: SpawnId, provider: str, context_case: str, context: str) -> None:
    events_file = paths.dot_space() / "spawns" / provider / f"{spawn_id}.jsonl"
    events_file.parent.mkdir(parents=True, exist_ok=True)
    event = {
        "type": "context_init",
        "context_case": context_case,
        "context": context,
        "timestamp": datetime.now(UTC).isoformat(),
    }
    with Path(events_file).open("a") as f:
        f.write(json.dumps(event) + "\n")
