"""Core type definitions. IDs are str subclasses for runtime type safety."""

from enum import Enum
from typing import Literal


class _Unset(Enum):
    UNSET = "UNSET"


UNSET: Literal[_Unset.UNSET] = _Unset.UNSET
Unset = Literal[_Unset.UNSET]

AgentType = Literal["human", "ai"]


class AgentId(str):
    pass


class SpawnId(str):
    pass


class TaskId(str):
    pass


class InsightId(str):
    pass


class ProjectId(str):
    pass


class DecisionId(str):
    pass


class ReplyId(str):
    pass


ArtifactType = Literal["insight", "decision", "task"]


INSIGHT_DOMAINS = frozenset(
    [
        "architecture",
        "autonomy",
        "cli",
        "continuity",
        "coordination",
        "design",
        "friction",
        "governance",
        "identity",
        "learning",
        "memory",
        "methodology",
        "observability",
        "operations",
        "primitives",
        "product",
        "quality",
        "rsi",
        "security",
        "status",
        "testing",
    ]
)
