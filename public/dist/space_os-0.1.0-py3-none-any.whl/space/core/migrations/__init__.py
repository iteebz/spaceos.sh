import sqlite3


def migration_002_project_tags(conn: sqlite3.Connection) -> None:
    conn.execute("ALTER TABLE projects ADD COLUMN tags TEXT")


def migration_003_spawn_resume_count(conn: sqlite3.Connection) -> None:
    conn.execute("ALTER TABLE spawns ADD COLUMN resume_count INTEGER DEFAULT 0")


def migration_004_triggers_repair(conn: sqlite3.Connection) -> None:
    conn.executescript("""
        CREATE TRIGGER IF NOT EXISTS spawns_fts_ai AFTER INSERT ON spawns BEGIN
            INSERT INTO spawns_fts(id, summary) VALUES (new.id, new.summary);
        END;

        CREATE TRIGGER IF NOT EXISTS spawns_fts_ad AFTER DELETE ON spawns BEGIN
            DELETE FROM spawns_fts WHERE id = old.id;
        END;

        CREATE TRIGGER IF NOT EXISTS spawns_fts_au AFTER UPDATE ON spawns BEGIN
            DELETE FROM spawns_fts WHERE id = old.id;
            INSERT INTO spawns_fts(id, summary) VALUES (new.id, new.summary);
        END;

        CREATE TRIGGER IF NOT EXISTS spawn_started
        AFTER INSERT ON spawns
        BEGIN
            INSERT INTO activity (agent_id, spawn_id, primitive, primitive_id, action, created_at)
            VALUES (NEW.agent_id, NEW.id, 'spawn', NEW.id, 'started', NEW.created_at);
        END;

        CREATE TRIGGER IF NOT EXISTS insight_created
        AFTER INSERT ON insights
        BEGIN
            INSERT INTO activity (agent_id, spawn_id, primitive, primitive_id, action, created_at)
            VALUES (NEW.agent_id, NEW.spawn_id, 'insight', NEW.id, 'created', NEW.created_at);
        END;

        CREATE TRIGGER IF NOT EXISTS insight_archived
        AFTER UPDATE OF archived_at ON insights
        WHEN OLD.archived_at IS NULL AND NEW.archived_at IS NOT NULL
        BEGIN
            INSERT INTO activity (agent_id, spawn_id, primitive, primitive_id, action)
            VALUES (NEW.agent_id, NEW.spawn_id, 'insight', NEW.id, 'archived');
        END;

        CREATE TRIGGER IF NOT EXISTS insight_linked
        AFTER UPDATE OF decision_id ON insights
        WHEN OLD.decision_id IS NULL AND NEW.decision_id IS NOT NULL
        BEGIN
            INSERT INTO activity (agent_id, spawn_id, primitive, primitive_id, action, field, after)
            VALUES (NEW.agent_id, NEW.spawn_id, 'insight', NEW.id, 'linked', 'decision_id', NEW.decision_id);
        END;

        CREATE TRIGGER IF NOT EXISTS insight_resolved
        AFTER UPDATE OF open ON insights
        WHEN OLD.open = 1 AND NEW.open = 0
        BEGIN
            INSERT INTO activity (agent_id, spawn_id, primitive, primitive_id, action)
            VALUES (NEW.agent_id, NEW.spawn_id, 'insight', NEW.id, 'resolved');
        END;
    """)


def migration_005_fts_backfill(conn: sqlite3.Connection) -> None:
    conn.execute("""
        INSERT OR IGNORE INTO spawns_fts(id, summary)
        SELECT s.id, s.summary FROM spawns s
        LEFT JOIN spawns_fts f ON s.id = f.id
        WHERE f.id IS NULL
    """)
