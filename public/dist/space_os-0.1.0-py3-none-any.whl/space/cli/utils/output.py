import json as json_lib
from typing import Any

import typer


def init_context(
    cli_ctx: typer.Context,
    json_output: bool = False,
    identity: str | None = None,
) -> None:
    """Initialize CLI context with standard flags and identity."""
    if cli_ctx.obj is None or not isinstance(cli_ctx.obj, dict):
        cli_ctx.obj = {}
    cli_ctx.obj["json_output"] = json_output
    cli_ctx.obj["identity"] = identity


def out_json(data: dict[str, Any]) -> str:
    """Serialize data to formatted JSON string."""
    return json_lib.dumps(data, indent=2)


def is_json_mode(cli_ctx: typer.Context) -> bool:
    """Check if JSON output mode is enabled."""
    return cli_ctx.obj.get("json_output", False) if cli_ctx.obj else False


def echo_json(data: Any, cli_ctx: typer.Context) -> bool:
    """Output data as JSON if in JSON mode. Returns True if output, False otherwise."""
    if is_json_mode(cli_ctx):
        typer.echo(json_lib.dumps(data, indent=2))
        return True
    return False


def echo_text(msg: str, cli_ctx: typer.Context) -> None:
    """Echo text message."""
    typer.echo(msg)


def respond(
    cli_ctx: typer.Context, json_data: dict[str, Any] | list[Any] | None = None, text_msg: str = ""
) -> None:
    """Unified output: JSON if --json, otherwise text."""
    if is_json_mode(cli_ctx):
        typer.echo(json_lib.dumps(json_data, indent=2))
    elif text_msg:
        typer.echo(text_msg)
