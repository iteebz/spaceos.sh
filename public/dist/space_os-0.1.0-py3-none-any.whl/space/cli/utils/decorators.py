"""Unified CLI decorators to reduce command boilerplate."""

import inspect
from collections.abc import Callable
from functools import wraps
from typing import Any

import typer

from space.core.errors import NotFoundError, ReferenceError, SpaceError
from space.core.models import Agent, Decision, Project
from space.core.types import ProjectId
from space.lib import identity, store
from space.os import projects


def resolve_agent(ref: str | None, ctx_identity: str | None) -> tuple[Agent | None, str | None]:
    """Resolve agent from ref or context. Returns (agent, error_hint)."""
    resolved = identity.resolve(ref) or ctx_identity
    if not resolved:
        return None, "--as (or SPACE_IDENTITY)"
    return store.resolve(resolved, "agents", Agent), None


def resolve_decision(ref: str | None) -> tuple[Decision | None, str | None]:
    """Resolve decision from ref. Returns (decision, error_hint)."""
    if not ref:
        return None, "--decision"
    try:
        return store.resolve(ref, "decisions", Decision), None
    except NotFoundError:
        return None, f"--decision '{ref}' not found"


def resolve_project(
    ref: str | None,
    optional: bool,
    global_flag: bool,
) -> tuple[Project | None, str | None]:
    """Resolve project from ref or CWD. Returns (project, error_hint)."""
    if optional and global_flag:
        return None, None

    try:
        project_id = projects.get_scope(ref)
    except NotFoundError:
        return None, f"--project '{ref}' not found"
    if project_id:
        return projects.get(ProjectId(project_id)), None

    available = projects.fetch()
    names = ", ".join(p.name for p in available[:5]) if available else None

    if optional:
        if names:
            return None, f"--project or --global (available: {names})"
        return None, None
    if names:
        return None, f"--project (available: {names})"
    return None, "--project (no projects exist)"


def requires(*args: str):
    """Unified command decorator. Aggregates all missing required options into one error.

    Usage:
        @app.command()
        @requires("agent", "project", "decision")
        def emit(cli_ctx, agent, project, decision, content): ...

        @app.command()
        @requires("agent?", "project?")  # optional injection
        def list_items(cli_ctx, agent, project): ...

        @app.command()
        @requires("project?", "decision?")  # optional, bypassed by --global
        def list_items(cli_ctx, project, decision): ...

    Features:
        - Resolves agent from --as / SPACE_IDENTITY
        - Resolves project from --project / CWD
        - Resolves decision from --decision (epistemological spine)
        - "agent?" injects agent when available, without requiring it
        - "?" suffix makes resolution optional
        - Single error message with all missing options
    """
    require_agent = "agent" in args or "agent?" in args
    agent_optional = "agent?" in args
    require_project = "project" in args or "project?" in args
    project_optional = "project?" in args
    require_decision = "decision" in args or "decision?" in args
    decision_optional = "decision?" in args

    def decorator[F: Callable[..., Any]](f: F) -> F:
        sig = inspect.signature(f)

        required_opts: list[tuple[str, tuple[str, ...]]] = []
        new_params: list[inspect.Parameter] = []

        for name, param in sig.parameters.items():
            if name in ("agent", "project", "decision", "cli_ctx"):
                continue
            if isinstance(param.default, typer.models.OptionInfo):
                opt_info = param.default
                if opt_info.default is ...:
                    decls = tuple(opt_info.param_decls or ())
                    required_opts.append((name, decls))
                    new_help = f"{opt_info.help or ''} [required]".strip()
                    new_default = typer.Option(None, *decls, help=new_help)
                    new_params.append(param.replace(default=new_default))
                else:
                    new_params.append(param)
            else:
                new_params.append(param)

        if require_agent:
            new_params.append(
                inspect.Parameter(
                    "agent_ref",
                    inspect.Parameter.KEYWORD_ONLY,
                    default=typer.Option(None, "--as", "-a", help="Agent identity"),
                    annotation=str | None,
                )
            )
        if require_project:
            new_params.append(
                inspect.Parameter(
                    "project_ref",
                    inspect.Parameter.KEYWORD_ONLY,
                    default=typer.Option(
                        None, "--project", "-p", help="Project (only needed outside spawn)"
                    ),
                    annotation=str | None,
                )
            )
            if project_optional:
                new_params.append(
                    inspect.Parameter(
                        "all_projects",
                        inspect.Parameter.KEYWORD_ONLY,
                        default=typer.Option(
                            False, "--global", "-g", help="All projects (skip scope)"
                        ),
                        annotation=bool,
                    )
                )
        if require_decision:
            new_params.append(
                inspect.Parameter(
                    "decision_ref",
                    inspect.Parameter.KEYWORD_ONLY,
                    default=typer.Option(None, "--decision", help="Decision"),
                    annotation=str | None,
                )
            )

        @wraps(f)
        def wrapper(cli_ctx: typer.Context, *args, **kwargs):
            if cli_ctx.obj is None:
                cli_ctx.obj = {}
            missing: list[str] = []

            for name, decls in required_opts:
                if kwargs.get(name) is None:
                    missing.append(decls[0] if decls else f"--{name}")

            if require_agent:
                agent_ref = kwargs.pop("agent_ref", None)
                agent, err = resolve_agent(agent_ref, cli_ctx.obj.get("identity"))
                if err and not agent_optional:
                    missing.append(err)
                kwargs["agent"] = agent

            if require_project:
                project_ref = kwargs.pop("project_ref", None)
                global_flag = kwargs.pop("all_projects", False) if project_optional else False
                project, err = resolve_project(project_ref, project_optional, global_flag)
                if err:
                    missing.append(err)
                kwargs["project"] = project

            if require_decision:
                decision_ref = kwargs.pop("decision_ref", None)
                decision, err = resolve_decision(decision_ref)
                if decision_optional and err and not decision_ref:
                    decision, err = None, None
                if err:
                    missing.append(err)
                kwargs["decision"] = decision

            if missing:
                raise typer.BadParameter(f"Missing: {', '.join(missing)}")

            return f(cli_ctx, *args, **kwargs)

        cli_ctx_param = inspect.Parameter(
            "cli_ctx",
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            annotation=typer.Context,
        )
        wrapper.__signature__ = sig.replace(parameters=[cli_ctx_param, *new_params])  # type: ignore[attr-defined]
        return wrapper  # type: ignore[return-value]

    return decorator


def cli_entrypoint[F: Callable[..., Any]](f: F) -> F:
    """Decorator for consistent CLI error handling on entrypoint functions."""

    @wraps(f)
    def wrapper(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except ReferenceError as e:
            typer.echo(str(e), err=True)
            raise typer.Exit(1) from None
        except SpaceError as e:
            typer.echo(str(e), err=True)
            raise typer.Exit(1) from None

    return wrapper  # type: ignore[return-value]
