"""CLI factory and reusable type aliases for agent-friendly argument handling."""

from typing import Annotated, Any

import typer

_CONTEXT: dict[str, Any] = {
    "help_option_names": ["-h", "--help"],
    "allow_interspersed_args": False,
}


def create_app(
    name: str | None = None,
    help: str | None = None,
    *,
    no_args_is_help: bool = True,
) -> typer.Typer:
    """Create CLI app with standard settings."""
    return typer.Typer(
        name=name,
        help=help,
        add_completion=False,
        no_args_is_help=no_args_is_help,
        context_settings=_CONTEXT,
        rich_markup_mode=None,
    )


def create_subapp(name: str | None = None, help: str | None = None) -> typer.Typer:
    """Create subcommand app inheriting parent context."""
    return typer.Typer(
        name=name,
        help=help,
        context_settings=_CONTEXT,
        rich_markup_mode=None,
    )


AgentRef = Annotated[str | None, typer.Option("--as", "-a", help="Agent identity.")]
JsonOutput = Annotated[bool, typer.Option("--json", "-j", help="JSON output.")]
ShowAll = Annotated[bool, typer.Option("--all", help="Include archived.")]
ShowArchived = Annotated[bool, typer.Option("--archived", help="Show archived.")]
ProjectFilter = Annotated[str | None, typer.Option("--project", "-p", help="Filter by project.")]
