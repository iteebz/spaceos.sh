import importlib
import sys
import tomllib
from functools import cache
from pathlib import Path

import typer

from space.cli.ops import backup
from space.cli.ops import health as health_mod
from space.cli.ops import sleep as sleep_mod
from space.cli.ops import stats as stats_mod
from space.cli.ops import tail as tail_mod
from space.cli.os import swarm as swarm_mod
from space.cli.utils import output
from space.cli.utils.app import create_app
from space.lib import commands as cmd_registry
from space.os import daemon as daemon_mod


def _show_help(cli_ctx: typer.Context, param: typer.CallbackParam, value: bool) -> None:
    if value:
        typer.echo(cli_ctx.get_help())
        raise typer.Exit()


app = create_app(no_args_is_help=False)


@app.callback(invoke_without_command=True)
def main_callback(
    cli_ctx: typer.Context,
    json_output: bool = typer.Option(False, "--json", "-j", help="Output in JSON format."),
    help_: bool = typer.Option(
        False,
        "--help",
        "-h",
        callback=_show_help,
        is_eager=True,
        help="Show this message and exit.",
    ),
):
    output.init_context(cli_ctx, json_output=json_output)

    if cli_ctx.invoked_subcommand is None:
        typer.echo("Usage: space [OPTIONS] COMMAND [ARGS]...\n")
        typer.echo("Options:")
        typer.echo("  -j, --json  Output in JSON format.")
        typer.echo("  -h, --help  Show this message and exit.\n")
        typer.echo(cmd_registry.primitives())
        typer.echo("\nRun `space --help` for the full command list.")


@app.command("health")
def health(cli_ctx: typer.Context):
    """Database stats and integrity checks."""
    health_mod.render(cli_ctx)


@app.command("morning")
def morning(
    cli_ctx: typer.Context,
    hours: int = typer.Option(8, "--hours", "-h", help="Time window in hours"),
):
    """What happened overnight. Run this after sleeping."""
    stats_mod.render_status(cli_ctx, hours)


@app.command("stats")
def stats(
    cli_ctx: typer.Context,
    hours: int = typer.Option(24, "--hours", "-h", help="Time window in hours"),
    rsi: str = typer.Option(None, "--rsi", help="Compare before/after an RSI commit"),
    extension: bool = typer.Option(False, "--extension", help="Show code extension metrics"),
    stability: bool = typer.Option(False, "--stability", help="Show commit fix rate by agent"),
    governance: bool = typer.Option(False, "--governance", help="Show governance metrics"),
    projects: bool = typer.Option(False, "--projects", "-p", help="Show spawns per project"),
    absence: bool = typer.Option(False, "--absence", "-a", help="Show human absence metrics"),
    spawns: int = typer.Option(None, "--spawns", "-s", help="Show last N spawns with productivity"),
    export: str = typer.Option(None, "--export", help="Export public stats to file path"),
    overnight: bool = typer.Option(False, "--overnight", "-o", help="Morning report format"),
):
    """Swarm productivity metrics."""
    if overnight:
        stats_mod.render_status(cli_ctx, hours)
        return
    if spawns:
        stats_mod.render_spawns(cli_ctx, spawns)
        return
    stats_mod.render(
        cli_ctx, hours, rsi, extension, stability, governance, projects, absence, export
    )


@app.command("launch")
def launch():
    """Start API server and web UI."""
    from space.cli.ops import launch as launch_mod

    launch_mod.launch()


@app.command("status")
def status_cmd(
    cli_ctx: typer.Context,
    identity: str = typer.Option(None, "--as", help="Show inbox for this agent"),
):
    """What needs doing. Projects, open questions, unclaimed tasks, inbox."""
    from space.os import status as status_mod

    data = status_mod.get(identity)

    if output.is_json_mode(cli_ctx):
        output.respond(
            cli_ctx,
            {
                "projects": [
                    {
                        "name": p.name,
                        "open_questions": p.open_questions,
                        "unclaimed_tasks": p.unclaimed_tasks,
                        "committed_decisions": p.committed_decisions,
                    }
                    for p in data.projects
                ],
                "inbox": [{"id": i.id, "content": i.content} for i in data.inbox],
            },
        )
        return

    for p in data.projects:
        needs = []
        if p.open_questions:
            needs.append(f"{p.open_questions} questions")
        if p.unclaimed_tasks:
            needs.append(f"{p.unclaimed_tasks} tasks")
        if p.committed_decisions:
            needs.append(f"{p.committed_decisions} decisions")

        if needs:
            typer.echo(f"**{p.name}**: {', '.join(needs)}")
        else:
            typer.echo(f"**{p.name}**: clear")

    if data.inbox:
        typer.echo("")
        typer.echo("## Inbox")
        for item in data.inbox:
            typer.echo(f"  [{item.parent_type[0]}/{item.parent_id}] {item.content[:60]}...")


@app.command("import")
def import_cmd(
    cli_ctx: typer.Context,
    github_link: str = typer.Argument(..., help="GitHub link: https://github.com/owner/repo"),
    name: str = typer.Option(None, "--name", "-n", help="Project name (defaults to repo name)"),
    tags: list[str] = typer.Option(  # noqa: B008
        ["imported"],
        "--tag",
        "-t",
        help="Tags to apply (repeatable). Defaults to 'imported'.",
    ),
    as_agent: str = typer.Option(
        None, "--as", help="Record a decision as this agent identity (e.g. tyson)"
    ),
    decision: bool = typer.Option(
        True, "--decision/--no-decision", help="Record a decision when --as is set"
    ),
    commit_decision: bool = typer.Option(
        False,
        "--commit-decision",
        help="Immediately commit the decision (only when --as is set)",
    ),
):
    """One-click GitHub import: mirror repo, create default worktree, register project, tag it."""
    from space.cli.ops import import_cmd as import_cmd_mod

    import_cmd_mod.run(
        cli_ctx,
        github_link,
        name=name,
        tags=tags,
        as_agent=as_agent,
        decision=decision,
        commit_decision=commit_decision,
    )


app.add_typer(swarm_mod.app, name="swarm")
app.add_typer(backup.app, name="backup", hidden=True)
app.add_typer(sleep_mod.app, name="sleep", hidden=True)


@app.command("daemon")
def daemon_cmd(
    cli_ctx: typer.Context,
    action: str = typer.Argument("status", help="start|stop|restart|status"),
):
    """Manage daemon process."""
    if action == "status":
        pid = daemon_mod.pid()
        if pid:
            output.respond(cli_ctx, {"running": True, "pid": pid}, f"running (pid {pid})")
        else:
            output.respond(cli_ctx, {"running": False}, "stopped")
    elif action == "start":
        if daemon_mod.pid():
            output.respond(cli_ctx, {"started": False}, f"already running (pid {daemon_mod.pid()})")
        else:
            pid = daemon_mod.start()
            output.respond(cli_ctx, {"started": True, "pid": pid}, f"started (pid {pid})")
    elif action == "stop":
        if daemon_mod.stop():
            output.respond(cli_ctx, {"stopped": True}, "stopped")
        else:
            output.respond(cli_ctx, {"stopped": False}, "not running")
    elif action == "restart":
        daemon_mod.stop()
        pid = daemon_mod.start()
        output.respond(cli_ctx, {"restarted": True, "pid": pid}, f"restarted (pid {pid})")
    else:
        typer.echo(f"Unknown action: {action}", err=True)
        raise typer.Exit(1)


@app.command("commands", hidden=True)
def commands(
    cli_ctx: typer.Context,
    group: str = typer.Argument(None, help="Filter to specific group"),
    injected: bool = typer.Option(False, "--injected", "-i", help="Agent-facing only"),
):
    """Show command registry."""
    typer.echo(cmd_registry.render(parent=group, injected_only=injected))


@app.command("activity")
def activity(
    cli_ctx: typer.Context,
    limit: int = typer.Option(20, "--limit", "-n", help="Number of events to show"),
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow new events"),
):
    """Stream activity feed."""
    tail_mod.activity_feed(limit, follow)


@app.command("tail")
def tail(
    cli_ctx: typer.Context,
    agent: str = typer.Argument(None, help="Filter to specific agent"),
    lines: int = typer.Option(20, "--lines", "-n", help="Initial lines to show"),
    log: bool = typer.Option(
        False, "--log", "-l", help="Write to ~/.space/logs/tail-YYYY-MM-DD.log"
    ),
):
    """Tail raw spawn logs. Auto-attaches to new spawns."""
    tail_mod.tail_spawns(lines, agent, log=log)


@cache
def root_cmds() -> dict[str, str]:
    from importlib.metadata import entry_points

    result = {}
    for ep in entry_points(group="console_scripts"):
        if ep.value.startswith("space.cli.") and ep.name not in {"space", "space-api"}:
            result[ep.name] = ep.value.rsplit(":", 1)[0]
    if result:
        return result

    pyproject = Path(__file__).parent.parent.parent / "pyproject.toml"
    if pyproject.exists():
        scripts = tomllib.loads(pyproject.read_text())["project"]["scripts"]
        return {
            name: entry.rsplit(":", 1)[0]
            for name, entry in scripts.items()
            if name not in {"space", "space-api"}
        }
    return {}


def _maybe_delegate() -> bool:
    args = sys.argv[1:]
    if not args:
        return False

    first_arg = args[0]
    cmds = root_cmds()
    if first_arg in cmds:
        module_path = cmds[first_arg]
        sys.argv = [first_arg, *args[1:]]
        module = importlib.import_module(module_path)
        if hasattr(module, "main"):
            module.main()
        elif hasattr(module, "cli"):
            module.cli()
        elif hasattr(module, "app"):
            module.app()
        return True
    return False


def main() -> None:
    if _maybe_delegate():
        return
    app()
