import sqlite3
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, TypedDict

import typer

from space.cli.utils import output
from space.lib import format, store
from space.lib.store import migrations

DB_NAME = "space.db"

INTERNAL_TABLES = frozenset({"_migrations"})


def _get_core_tables(conn: sqlite3.Connection) -> list[str]:
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchall()
    return sorted(name for (name,) in rows if not ("_fts" in name or name in INTERNAL_TABLES))


def _has_column(conn: sqlite3.Connection, table: str, column: str) -> bool:
    rows = conn.execute(f"PRAGMA table_info({table})").fetchall()
    return any(row[1] == column for row in rows)


class PrimitiveCount(TypedDict):
    active: int
    archived: int


class HealthResult(TypedDict):
    ok: bool
    issues: list[str]
    counts: dict[str, int]
    fk_violations: dict[str, int]
    total_rows: int
    primitives: dict[str, PrimitiveCount]
    schema_drift: list[str]


def _count_table(conn: sqlite3.Connection, table: str, active_only: bool = False) -> int:
    if not active_only:
        return conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]  # noqa: S608
    if _has_column(conn, table, "archived_at"):
        return conn.execute(f"SELECT COUNT(*) FROM {table} WHERE archived_at IS NULL").fetchone()[0]  # noqa: S608
    return conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]  # noqa: S608


def _check_fk_violations(conn: sqlite3.Connection) -> dict[tuple[str, str], int]:
    rows = conn.execute("PRAGMA foreign_key_check").fetchall()
    violations: dict[tuple[str, str], int] = defaultdict(int)
    for row in rows:
        violations[(row["table"], row["parent"])] += 1
    return dict(violations)


def _check_integrity(conn: sqlite3.Connection) -> str | None:
    result = conn.execute("PRAGMA integrity_check").fetchone()[0]
    return None if result == "ok" else result


def backup_age() -> int | None:
    data_dir = Path.home() / ".space_backups" / "data"
    if not data_dir.exists():
        return None
    snapshots = sorted(data_dir.iterdir(), reverse=True)
    if not snapshots:
        return None
    try:
        ts = datetime.strptime(snapshots[0].name, "%Y%m%d_%H%M%S")
        return int((datetime.now() - ts).total_seconds())
    except ValueError:
        return None


def check_db() -> HealthResult:
    result: HealthResult = {
        "ok": True,
        "issues": [],
        "counts": {},
        "fk_violations": {},
        "total_rows": 0,
        "primitives": {},
        "schema_drift": [],
    }

    if not store.database_exists():
        result["ok"] = False
        result["issues"].append(f"{DB_NAME} missing")
        return result

    try:
        with store.ensure() as conn:
            core_tables = _get_core_tables(conn)

            integrity_error = _check_integrity(conn)
            if integrity_error:
                result["ok"] = False
                result["issues"].append(f"integrity: {integrity_error}")

            fk_violations = _check_fk_violations(conn)
            if fk_violations:
                result["ok"] = False
                result["fk_violations"] = {f"{t}→{p}": n for (t, p), n in fk_violations.items()}

            for table in core_tables:
                count = _count_table(conn, table)
                result["counts"][table] = count
                result["total_rows"] += count
                active = _count_table(conn, table, active_only=True)
                result["primitives"][table] = {"active": active, "archived": count - active}

            drift = check_schema_drift(conn)
            if drift:
                result["ok"] = False
                result["schema_drift"] = drift

    except sqlite3.Error as exc:
        result["ok"] = False
        result["issues"].append(str(exc))

    return result


def get_health_summary() -> dict[str, Any]:
    db = check_db()
    return {
        "ok": db["ok"],
        "total_rows": db["total_rows"],
        "backup_age_seconds": backup_age(),
        "primitives": db["primitives"],
        "fk_violations": db["fk_violations"],
        "issues": db["issues"],
        "counts": db["counts"],
        "schema_drift": db["schema_drift"],
    }


def run_all_checks() -> tuple[list[str], dict[str, dict[str, int]]]:
    db = check_db()
    issues = db["issues"] + [
        f"FK violation: {rel} ({n} rows)" for rel, n in db["fk_violations"].items()
    ]
    summaries = {DB_NAME: db["counts"]} if db["ok"] else {}
    return issues, summaries


ColumnInfo = tuple[str, str, bool, bool]  # name, type, notnull, pk


def _extract_schema(conn: sqlite3.Connection) -> dict[str, Any]:
    """Extract schema from a connection using SQLite introspection."""
    schema: dict[str, Any] = {"tables": {}, "indexes": set(), "triggers": set()}

    fts_internal = ("_data", "_idx", "_content", "_docsize", "_config")

    for (name,) in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchall():
        if name == "_migrations" or any(name.endswith(s) for s in fts_internal):
            continue
        cols: list[ColumnInfo] = [
            (r[1], r[2].upper(), bool(r[3]), bool(r[5]))
            for r in conn.execute(f"PRAGMA table_info({name})").fetchall()
        ]
        schema["tables"][name] = cols

    for (name,) in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='index' AND name NOT LIKE 'sqlite_%' AND sql IS NOT NULL"
    ).fetchall():
        schema["indexes"].add(name)

    for (name,) in conn.execute("SELECT name FROM sqlite_master WHERE type='trigger'").fetchall():
        schema["triggers"].add(name)

    return schema


def _build_expected_schema() -> dict[str, Any] | None:
    """Build expected schema by applying migrations to in-memory DB."""
    migs = migrations.get("space.core")
    if not migs:
        return None

    mem_conn = sqlite3.connect(":memory:")
    try:
        for _, migration in migs:
            if isinstance(migration, str):
                mem_conn.executescript(migration)
            elif callable(migration):
                migration(mem_conn)
        return _extract_schema(mem_conn)
    finally:
        mem_conn.close()


def check_schema_drift(conn: sqlite3.Connection) -> list[str]:
    """Compare live DB schema against migrations using SQLite introspection."""
    expected = _build_expected_schema()
    if not expected:
        return ["no migrations found"]

    live = _extract_schema(conn)
    drift: list[str] = []

    for table, expected_cols in expected["tables"].items():
        if table not in live["tables"]:
            drift.append(f"missing table: {table}")
            continue
        live_cols = live["tables"][table]
        expected_set = set(expected_cols)
        live_set = set(live_cols)
        for col in expected_set - live_set:
            name, _typ, _notnull, _pk = col
            if any(c[0] == name for c in live_set):
                drift.append(f"{table}.{name}: schema mismatch")
            else:
                drift.append(f"{table}.{name}: missing column")
        for col in live_set - expected_set:
            name = col[0]
            if not any(c[0] == name for c in expected_set):
                drift.append(f"{table}.{name}: extra column")

    drift.extend(f"extra table: {t}" for t in live["tables"] if t not in expected["tables"])
    drift.extend(f"missing index: {i}" for i in expected["indexes"] - live["indexes"])
    drift.extend(f"missing trigger: {t}" for t in expected["triggers"] - live["triggers"])

    return drift


def render(cli_ctx: typer.Context) -> None:
    summary = get_health_summary()

    if output.is_json_mode(cli_ctx):
        typer.echo(output.out_json(summary))
        if not summary["ok"]:
            raise typer.Exit(1)
        return

    status_icon = "✓" if summary["ok"] else "✗"
    backup_age = format.age_seconds(summary["backup_age_seconds"])
    typer.echo(f"{status_icon} {summary['total_rows']} rows | backup {backup_age} ago")

    typer.echo("\n[PRIMITIVES]")
    sorted_primitives = sorted(
        summary["primitives"].items(), key=lambda x: x[1]["active"], reverse=True
    )
    for table, counts in sorted_primitives:
        archived = counts["archived"]
        suffix = f" (+{archived})" if archived else ""
        typer.echo(f"  {table}: {counts['active']}{suffix}")

    if summary["fk_violations"]:
        typer.echo("\n[FK VIOLATIONS]")
        for rel, count in summary["fk_violations"].items():
            typer.echo(f"  ✗ {rel}: {count} rows")

    if summary.get("schema_drift"):
        typer.echo("\n[SCHEMA DRIFT]")
        for drift in summary["schema_drift"]:
            typer.echo(f"  ✗ {drift}")

    if summary["issues"]:
        typer.echo("\n[ISSUES]")
        for issue in summary["issues"]:
            typer.echo(f"  ✗ {issue}")
        raise typer.Exit(1)
