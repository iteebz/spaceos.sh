import json
import sys
import time
from dataclasses import dataclass
from datetime import date
from pathlib import Path

import typer

from space.core.models import SpawnStatus
from space.core.types import AgentId, DecisionId, InsightId, ReplyId, TaskId
from space.lib import ansi, paths, providers
from space.os import activity as activity_mod
from space.os import agents as agents_mod
from space.os import decisions, insights, replies, spawns, tasks

_HOME = str(Path.home())

TOOL_DISPLAY = {
    "WebFetch": "Fetch",
    "WebSearch": "Search",
}


def _log_path() -> Path:
    return paths.dot_space() / "logs" / f"tail-{date.today().isoformat()}.log"


def _write_log(line: str) -> None:
    p = _log_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a") as f:
        f.write(ansi.strip(line) + "\n")


@dataclass
class _StreamState:
    spawn_id: str
    identity: str
    path: Path
    position: int = 0
    ctx_pct: float | None = None


def _identity(agent_id: str, cache: dict[str, str]) -> str:
    if agent_id not in cache:
        agent = agents_mod.get(AgentId(agent_id))
        cache[agent_id] = agent.identity if agent else agent_id[:8]
    return cache[agent_id]


def _format_event(d: dict[str, object], identity: str, ctx_pct: float | None = None) -> str | None:
    etype = d.get("type")
    pct_str = f"{ctx_pct:>3.0f}%" if ctx_pct is not None else "   -"
    prefix = f"{ansi.cyan(pct_str)} {ansi.yellow(f'{identity[:10]:<10}')}"
    if etype == "assistant":
        msg = d.get("message")
        content = msg.get("content", []) if isinstance(msg, dict) else []
        if not content:
            return None
        c = content[0]
        if c.get("type") == "text":
            text = c.get("text", "").replace(_HOME, "~")
            lines = text.split("\n")
            first = lines[0]
            if len(lines) > 1:
                first += f" {ansi.dim(f'(+{len(lines) - 1} lines)')}"
            return f"{prefix} {ansi.green('>>')} {first}"
        if c.get("type") == "tool_use":
            raw_name = str(c.get("name") or "?")
            name: str = TOOL_DISPLAY.get(raw_name, raw_name)
            inp = c.get("input", {})
            if raw_name == "WebFetch":
                arg = inp.get("url", "")
            elif raw_name == "WebSearch":
                arg = inp.get("query", "")
            else:
                arg = (
                    inp.get("command")
                    or inp.get("pattern")
                    or inp.get("file_path")
                    or inp.get("query")
                    or ""
                )
            if isinstance(arg, str):
                arg = arg.replace(_HOME, "~").split("\n")[0]
            suffix = ""
            if name in ("Edit", "MultiEdit"):
                old = inp.get("old_string", "")
                new = inp.get("new_string", "")
                if isinstance(old, str) and isinstance(new, str):
                    add = len(new.split("\n"))
                    rem = len(old.split("\n"))
                    parts = []
                    if add > 0:
                        parts.append(ansi.green(f"+{add}"))
                    if rem > 0:
                        parts.append(ansi.red(f"-{rem}"))
                    if parts:
                        suffix = f" ({' '.join(parts)})"
            elif name == "Write":
                content = inp.get("content", "")
                if isinstance(content, str):
                    add = len(content.split("\n"))
                    suffix = f" ({ansi.green(f'+{add}')})"
            return f"{prefix} {ansi.magenta(name)} {arg}{suffix}"
    elif etype == "result":
        sub = d.get("subtype", "done")
        return f"{prefix} {ansi.dim(f'<< {sub}')}"
    return None


def _spawn_path(s, agent_cache: dict[str, str]) -> Path | None:
    agent = agents_mod.get(s.agent_id)
    provider = providers.map(agent.model) if agent and agent.model else "claude"
    p = paths.dot_space() / "spawns" / provider / f"{s.id}.jsonl"
    return p if p.exists() else None


def _read_stream(t: _StreamState) -> list[str]:
    out = []
    try:
        if t.path.stat().st_size <= t.position:
            return out
        with t.path.open() as f:
            f.seek(t.position)
            for line in f:
                line = line.rstrip()
                if line:
                    try:
                        d = json.loads(line)
                        if (msg := d.get("message")) and (u := msg.get("usage")):
                            inp = u.get("input_tokens", 0) + u.get("cache_read_input_tokens", 0)
                            if inp > 0:
                                t.ctx_pct = max(0, 100 - inp / 200000 * 100)
                        fmt = _format_event(d, t.identity, t.ctx_pct)
                        if fmt:
                            out.append(fmt)
                    except json.JSONDecodeError:
                        pass
            t.position = f.tell()
    except (OSError, FileNotFoundError):
        pass
    return out


def tail_spawns(lines: int = 20, agent: str | None = None, log: bool = False) -> None:
    streams: dict[str, _StreamState] = {}
    agent_cache: dict[str, str] = {}

    def _sync() -> tuple[list[str], list[str]]:
        active = spawns.fetch(status=SpawnStatus.ACTIVE)
        if agent:
            active = [
                s
                for s in active
                if _identity(s.agent_id, agent_cache).lower().startswith(agent.lower())
            ]
        active_ids = {s.id for s in active}
        current_ids = set(streams.keys())
        added, removed = [], []
        for s in active:
            if s.id not in current_ids:
                path = _spawn_path(s, agent_cache)
                if path:
                    ident = _identity(s.agent_id, agent_cache)
                    u = spawns.usage(s)
                    pct = u.get("percentage") if u else None
                    size = path.stat().st_size
                    pos = max(0, size - 8192)
                    streams[s.id] = _StreamState(s.id, ident, path, pos, ctx_pct=pct)
                    label = f"{ident} ({pct:.0f}%)" if pct else ident
                    added.append(label)
        for sid in current_ids - active_ids:
            removed.append(streams[sid].identity)
            del streams[sid]
        return added, removed

    added, _ = _sync()
    if added:
        typer.echo(f"streaming: {', '.join(added)}")
    else:
        typer.echo("waiting for spawns...")
    last_sync = time.time()

    try:
        while True:
            for t in list(streams.values()):
                for line in _read_stream(t):
                    sys.stdout.write(line + "\n")
                    sys.stdout.flush()
                    if log:
                        _write_log(line)
            if time.time() - last_sync > 1.0:
                added, removed = _sync()
                if added:
                    typer.echo(f"+ {', '.join(added)}")
                if removed:
                    typer.echo(f"- {', '.join(removed)}")
                last_sync = time.time()
            time.sleep(0.1)
    except KeyboardInterrupt:
        pass


def _get_content(primitive: str, primitive_id: str) -> str:
    try:
        if primitive == "task":
            t = tasks.get(TaskId(primitive_id))
            return t.content[:60] + "..." if len(t.content) > 60 else t.content
        if primitive == "insight":
            i = insights.get(InsightId(primitive_id))
            return i.content[:60] + "..." if len(i.content) > 60 else i.content
        if primitive == "decision":
            d = decisions.get(DecisionId(primitive_id))
            return d.content[:60] + "..." if len(d.content) > 60 else d.content
        if primitive == "reply":
            r = replies.get(ReplyId(primitive_id))
            return r.content[:60] + "..." if len(r.content) > 60 else r.content
    except Exception:
        return ""
    return ""


def activity_feed(limit: int = 20, follow: bool = False) -> None:
    agent_cache: dict[str, str] = {}

    def _format(e: activity_mod.Activity) -> str:
        ident = _identity(e.agent_id, agent_cache)
        ts = e.created_at[11:19] if e.created_at else ""
        content = _get_content(e.primitive, e.primitive_id)
        action_fmt = ansi.green if e.action == "completed" else ansi.yellow
        prim = e.primitive.capitalize()
        return f"[{ts}] {ident[:10]:<10} {ansi.magenta(f'{prim:<8}')} {action_fmt(f'{e.action:<10}')} {content}"

    events = activity_mod.fetch(limit=limit)
    for e in reversed(events):
        typer.echo(_format(e))

    if not follow:
        return

    last_id = events[0].id if events else 0
    try:
        while True:
            time.sleep(1)
            new_events = activity_mod.fetch(limit=50)
            for e in reversed(new_events):
                if e.id > last_id:
                    typer.echo(_format(e))
                    last_id = e.id
    except KeyboardInterrupt:
        pass
