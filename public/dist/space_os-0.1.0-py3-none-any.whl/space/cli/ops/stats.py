import json
from pathlib import Path

import typer

from space.cli.utils import output
from space.lib import git
from space.lib.format import truncate
from space.os import stats


def render(
    cli_ctx: typer.Context,
    hours: int = 24,
    rsi: str | None = None,
    extension: bool = False,
    stability: bool = False,
    governance: bool = False,
    projects: bool = False,
    absence: bool = False,
    export: str | None = None,
) -> None:
    if export:
        public = stats.public_stats()
        Path(export).write_text(json.dumps(public, indent=2))
        typer.echo(f"Exported to {export}")
        return

    if extension:
        ext = stats.code_extension()
        if output.is_json_mode(cli_ctx):
            typer.echo(output.out_json(ext))
            return
        typer.echo(f"[CODE EXTENSION] {ext['total']} agent-to-agent file extensions")
        for agent, data in sorted(ext["by_agent"].items(), key=lambda x: -x[1]["total"]):
            extends_str = ", ".join(
                f"{k}({v})" for k, v in sorted(data["extends"].items(), key=lambda x: -x[1])
            )
            typer.echo(f"  {agent}: {data['total']} files - {extends_str}")
        return

    if rsi:
        commit_ts = git.get_commit_timestamp(rsi)
        if not commit_ts:
            typer.echo(f"Commit not found: {rsi}")
            raise typer.Exit(1)
        comparison = stats.rsi_comparison(commit_ts, hours)
        if output.is_json_mode(cli_ctx):
            typer.echo(output.out_json(comparison))
            return
        typer.echo(f"[RSI COMPARISON] {rsi[:8]} @ {commit_ts}")
        typer.echo(f"\n[BEFORE] ({hours}h)")
        for row in comparison["before"]["artifacts_per_spawn"]:
            typer.echo(f"  {row['agent']}: {row['ratio']} artifacts/spawn ({row['spawns']} spawns)")
        comp_before = comparison["before"]["compounding"]
        typer.echo(f"  compounding: {comp_before['rate']}%")
        typer.echo(f"\n[AFTER] ({hours}h)")
        for row in comparison["after"]["artifacts_per_spawn"]:
            typer.echo(f"  {row['agent']}: {row['ratio']} artifacts/spawn ({row['spawns']} spawns)")
        comp_after = comparison["after"]["compounding"]
        typer.echo(f"  compounding: {comp_after['rate']}%")
        delta = comp_after["rate"] - comp_before["rate"]
        typer.echo(f"\n[DELTA] compounding: {delta:+.1f}%")
        return

    if stability:
        stab = stats.commit_stability(days=7)
        if output.is_json_mode(cli_ctx):
            typer.echo(output.out_json(stab))
            return
        overall = stab["overall"]
        typer.echo(
            f"[COMMIT STABILITY] (7d) {overall['fix_rate']}% correction rate ({overall['other_fixes']}/{overall['total']})"
        )
        typer.echo(
            "\n  Corrections = fixes by others (instability). Self-fixes = iterative refinement."
        )
        for row in stab["by_agent"]:
            self_fixes = row.get("self_fixes", 0)
            other_fixes = row.get("other_fixes", 0)
            typer.echo(
                f"  {row['agent']}: {row['fix_rate']}% ({other_fixes} corrections, {self_fixes} refinements)"
            )
        return

    if governance:
        corrections = stats.cross_agent_corrections()
        reversal = stats.decision_reversal_rate()
        half_life = stats.decision_half_life()
        influence = stats.decision_influence()
        precision = stats.decision_precision()
        decay = stats.knowledge_decay()
        if output.is_json_mode(cli_ctx):
            typer.echo(
                output.out_json(
                    {
                        "corrections": corrections,
                        "reversal": reversal,
                        "half_life": half_life,
                        "influence": influence,
                        "precision": precision,
                        "knowledge_decay": decay,
                    }
                )
            )
            return
        if corrections.get("error"):
            typer.echo(f"[CROSS-AGENT CORRECTIONS] {corrections['error']}")
        else:
            typer.echo(
                f"[CROSS-AGENT CORRECTIONS] {corrections['rate']}% ({corrections['corrections']}/{corrections['total_fixes']})"
            )
            typer.echo("  Adversarial oversight signal")
        typer.echo(
            f"\n[DECISION REVERSAL] {reversal['reversal_rate']}% ({reversal['reversed']}/{reversal['total_committed']})"
        )
        typer.echo("  Target: <5% (commitment stability)")
        if half_life["median_hours"] is not None:
            typer.echo(
                f"\n[DECISION HALF-LIFE] {half_life['median_hours']}h median (p25={half_life['p25_hours']}h, p75={half_life['p75_hours']}h, n={half_life['sample_size']})"
            )
        else:
            typer.echo("\n[DECISION HALF-LIFE] no data")
        typer.echo(
            f"\n[DECISION INFLUENCE] {influence['influence_rate']}% referenced ({influence['referenced']}/{influence['total_decisions']})"
        )
        typer.echo(
            f"\n[DECISION PRECISION] {precision['overall']['precision']}% accepted ({precision['overall']['actioned']}/{precision['overall']['actioned'] + precision['overall']['rejected']})"
        )
        if decay["buckets"]:
            typer.echo(f"\n[KNOWLEDGE DECAY] ({decay['weeks']}w)")
            for b in decay["buckets"][:6]:
                bar = "#" * int(b["rate"] / 2) if b["rate"] > 0 else "."
                typer.echo(f"  w{b['week']}: {b['rate']}% ({b['referenced']}/{b['total']}) {bar}")
        return

    if projects:
        dist = stats.project_distribution(hours)
        if output.is_json_mode(cli_ctx):
            typer.echo(output.out_json(dist))
            return
        typer.echo(f"[PROJECT DISTRIBUTION] ({hours}h, {dist['total']} spawns)")
        for row in dist["by_project"]:
            bar = "#" * int(row["share"] / 5) if row["share"] >= 5 else "."
            typer.echo(
                f"  {row['project']}: {row['spawns']} ({row['share']}%, {row['agents']} agents) {bar}"
            )
        return

    if absence:
        data = stats.absence_metrics(hours * 7)
        if output.is_json_mode(cli_ctx):
            typer.echo(output.out_json(data))
            return
        window_days = data["hours"] // 24
        typer.echo(f"[ABSENCE] ({window_days}d)")
        typer.echo(f"  block duration: {data['block_duration_hours']}h avg (mention → response)")
        typer.echo(f"  completion autonomy: {data['completion_autonomy']}%")
        typer.echo(
            f"  input/output ratio: {data['input_output_ratio']} ({data['human_inputs']} human / {data['swarm_outputs']} swarm)"
        )
        typer.echo(
            f"  tasks: {data['tasks_autonomous']}/{data['tasks_total']} completed autonomously"
        )
        return

    summary = stats.get_summary(hours)

    if output.is_json_mode(cli_ctx):
        typer.echo(output.out_json(summary))
        return

    typer.echo(f"[PRODUCTIVITY] ({hours}h)")
    for row in summary["artifacts_per_spawn"]:
        typer.echo(f"  {row['agent']}: {row['ratio']} artifacts/spawn ({row['spawns']} spawns)")

    loop = summary["loop_frequency"]
    if loop["max_consecutive"] > 2:
        typer.echo(f"\n[LOOPS] max {loop['max_consecutive']} consecutive ({loop['agent']})")

    typer.echo("\n[DECISIONS]")
    for status, count in summary["decision_flow"].items():
        typer.echo(f"  {status}: {count}")

    typer.echo(f"\n[QUESTIONS] {summary['open_questions']} open")

    if summary["engagement"]:
        typer.echo(f"\n[ENGAGEMENT] ({hours}h)")
        for row in summary["engagement"]:
            ratio = row["ratio"] or 0
            typer.echo(
                f"  {row['agent']}: {ratio} reply/insight ({row['insights']}i, {row['replies']}r)"
            )

    comp = summary["compounding"]
    window_days = comp.get("window_hours", 168) // 24
    typer.echo(
        f"\n[COMPOUNDING] ({window_days}d) {comp['rate']}% reference prior work ({comp['referencing']}/{comp['total']})"
    )
    if comp.get("by_agent"):
        for row in comp["by_agent"][:5]:
            if row["refs"] > 0:
                typer.echo(f"  {row['agent']}: {row['rate']}% ({row['refs']}/{row['total']})")

    di = summary["decision_influence"]
    typer.echo(
        f"\n[DECISION INFLUENCE] {di['influence_rate']}% decisions referenced ({di['referenced']}/{di['total_decisions']})"
    )
    if di["top"]:
        for prefix, count in di["top"][:3]:
            typer.echo(f"  d/{prefix}: {count} refs")

    dp = summary["decision_precision"]
    typer.echo(
        f"\n[DECISION PRECISION] {dp['overall']['precision']}% accepted ({dp['overall']['actioned']}/{dp['overall']['actioned'] + dp['overall']['rejected']})"
    )
    for row in dp["by_agent"]:
        if row["precision"] is not None:
            typer.echo(
                f"  {row['agent']}: {row['precision']}% ({row['actioned']}a/{row['rejected']}r)"
            )

    ts = summary["task_sovereignty"]
    window_days = ts.get("window_hours", 168) // 24
    typer.echo(
        f"\n[SOVEREIGNTY] ({window_days}d) {ts['overall_rate']:.0f}% self-directed ({ts['self_created']}/{ts['total']})"
    )

    if summary.get("silent_agents"):
        typer.echo(f"\n[SILENT] ({hours}h)")
        for row in summary["silent_agents"]:
            if row["hours_silent"]:
                typer.echo(f"  {row['agent']}: {row['hours_silent']}h since activity")
            else:
                typer.echo(f"  {row['agent']}: no recent activity")


def render_status(cli_ctx: typer.Context, hours: int = 24) -> None:
    data = stats.status(hours)

    if output.is_json_mode(cli_ctx):
        typer.echo(output.out_json(data))
        return

    typer.echo(f"[OVERNIGHT] ({hours}h)")
    typer.echo(f"  {data['spawns']} spawns, {data['insights']} insights")
    d = data["decisions"]
    typer.echo(f"  {d['total']} decisions ({d['actioned']} actioned, {d['rejected']} rejected)")

    if data["recent_summaries"]:
        typer.echo("\n[RECENT WORK]")
        for summary in data["recent_summaries"][:5]:
            line = truncate(summary.split("\n")[0])
            typer.echo(f"  - {line}")

    if data["open_questions"]:
        typer.echo(f"\n[OPEN QUESTIONS] ({len(data['open_questions'])})")
        for q in data["open_questions"][:3]:
            typer.echo(f"  [{q['agent']}] {truncate(q['content'])}")

    attention = []
    if data["unresolved_human_mentions"]:
        attention.append(f"{data['unresolved_human_mentions']} @human mentions unresolved")
    if data["silent_agents"]:
        attention.append(f"{', '.join(data['silent_agents'])} silent >{hours}h")

    if attention:
        typer.echo("\n[ATTENTION NEEDED]")
        for item in attention:
            typer.echo(f"  - {item}")


def render_spawns(cli_ctx: typer.Context, limit: int = 10) -> None:
    data = stats.spawn_stats(limit)

    if output.is_json_mode(cli_ctx):
        output.respond(cli_ctx, data)
        return

    if not data:
        typer.echo("[SPAWNS] no completed spawns")
        return

    insight_only_count = sum(1 for s in data if s["insight_only"])
    typer.echo(f"[SPAWNS] last {len(data)} ({insight_only_count} insight-only)")

    for s in data:
        marker = "!" if s["insight_only"] else " "
        artifacts = s["artifacts"]
        transitions = s["task_transitions"]
        summary = truncate(s["summary"][:50]) if s["summary"] else "-"
        typer.echo(
            f"{marker} {s['id']} @{s['agent']:10} {artifacts:2}a {transitions:2}t  {summary}"
        )


def render_swarm(cli_ctx: typer.Context) -> None:
    data = stats.swarm()

    if output.is_json_mode(cli_ctx):
        typer.echo(output.out_json(data))
        return

    has_content = False

    if data["spawns"]:
        typer.echo("[SPAWNS]")
        spawn_str = ", ".join(f"@{s['agent']}({s['count']})" for s in data["spawns"])
        typer.echo(f"  {spawn_str}")
        has_content = True

    if data["active"]:
        typer.echo("\n[ACTIVE]" if has_content else "[ACTIVE]")
        for t in data["active"]:
            typer.echo(f"  @{t['agent']}: {t['content']}")
        has_content = True

    if data["committed"]:
        typer.echo("\n[COMMITTED]" if has_content else "[COMMITTED]")
        for d in data["committed"]:
            typer.echo(f"  d/{d['id']}: {d['content']}")
        has_content = True

    if data["questions"]:
        typer.echo("\n[QUESTIONS]" if has_content else "[QUESTIONS]")
        for q in data["questions"]:
            typer.echo(f"  [{q['agent']}] {q['content']}")
        has_content = True

    if data["recent"]:
        typer.echo("\n[RECENT]" if has_content else "[RECENT]")
        for r in data["recent"]:
            typer.echo(f"  @{r['agent']}: {r['summary']}")
