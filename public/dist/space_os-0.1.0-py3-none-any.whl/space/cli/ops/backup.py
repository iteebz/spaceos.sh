from typing import Any

import typer

from space.lib import backup as backup_lib

app = typer.Typer(
    no_args_is_help=False, help="Snapshot database and spawn logs to ~/.space_backups."
)


@app.callback(invoke_without_command=True)
def callback(cli_ctx: typer.Context):
    if cli_ctx.invoked_subcommand is None:
        _display_backup_output(backup_lib.execute())


@app.command(name="now", hidden=True)
def backup():
    """Create backup now."""
    _display_backup_output(backup_lib.execute())


def _format_delta(delta: int | None) -> str:
    if delta is None or delta == 0:
        return ""
    return f" (+{delta})" if delta > 0 else f" ({delta})"


def _format_table_deltas(by_table: dict[str, int]) -> str:
    if not by_table:
        return ""
    parts = [
        f"{t} {'+' if d > 0 else ''}{d}"
        for t, d in sorted(by_table.items(), key=lambda x: -abs(x[1]))
    ]
    return "\n    ".join(parts)


def _display_backup_output(result: dict[str, Any]) -> None:
    timestamp = result["timestamp"]
    data_stats = result["data_stats"]
    row_deltas = result["row_deltas"]
    spawns_stats = result["spawns_stats"]

    typer.echo(f"✓ ~/.space_backups/data/{timestamp}")
    for db, info in data_stats.items():
        if "error" in info:
            typer.echo(f"  {db}: {info['error']}")
        else:
            delta_info = row_deltas.get(db, {})
            total_delta = delta_info.get("total")
            table_deltas = delta_info.get("by_table", {})

            typer.echo(f"  db: {info['rows']}{_format_delta(total_delta)}")
            if table_deltas:
                typer.echo(f"    {_format_table_deltas(table_deltas)}")

    total = spawns_stats.get("total", 0)
    new = spawns_stats.get("new", 0)
    typer.echo(f"  jsonl: {total}{_format_delta(new)}")


def main() -> None:
    app()
