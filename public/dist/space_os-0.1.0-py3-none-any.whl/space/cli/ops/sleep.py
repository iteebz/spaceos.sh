import sys
from pathlib import Path

import typer

from space.cli.utils import output
from space.core.models import Spawn, TaskStatus
from space.lib import git, paths, store
from space.lib.commands import space_app
from space.lib.format import truncate
from space.os import projects, spawns, tasks

app = space_app("sleep", purpose="close spawn with summary", injected=True, role="agents")
app.info.no_args_is_help = False


@app.callback(invoke_without_command=True)
def sleep_cmd(
    cli_ctx: typer.Context,
    summary: str | None = typer.Argument(None, help="What you accomplished"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    force: bool = typer.Option(False, "--force", "-f", help="Sleep despite uncommitted changes"),
    stdin: bool = typer.Option(False, "--stdin", help="Read summary from stdin"),
):
    output.init_context(cli_ctx, json_output=json_output)
    spawn_id = paths.spawn_id()
    if not spawn_id:
        typer.echo("Not in spawn context", err=True)
        raise typer.Exit(1)

    spawn = store.resolve(spawn_id, "spawns", Spawn)
    project = projects.get(spawn.project_id) if spawn.project_id else None
    has_uncommitted = _check_uncommitted(project.repo_path) if project else False

    if stdin:
        summary = sys.stdin.read().strip()
        if not summary:
            typer.echo("No summary provided on stdin", err=True)
            raise typer.Exit(1)

    if summary is None:
        _show_checklist(cli_ctx, spawn, has_uncommitted)
        return

    if has_uncommitted and not force:
        typer.echo("Uncommitted changes detected. Commit or use --force.", err=True)
        raise typer.Exit(1)

    result = spawns.done(spawn, summary)
    if "error" in result:
        output.respond(cli_ctx, result, result["error"])
        raise typer.Exit(1)

    output.respond(cli_ctx, result, "Done.")


def _show_checklist(cli_ctx: typer.Context, spawn, has_uncommitted: bool) -> None:
    all_tasks = tasks.fetch(assignee_id=spawn.agent_id, project_id=spawn.project_id)
    owned_tasks = [t for t in all_tasks if t.status == TaskStatus.ACTIVE]

    if output.is_json_mode(cli_ctx):
        output.echo_json(
            {
                "spawn_id": spawn.id,
                "tasks": [{"id": t.id, "content": truncate(t.content, 100)} for t in owned_tasks],
                "uncommitted": has_uncommitted,
            },
            cli_ctx,
        )
        return

    if owned_tasks:
        typer.echo("Open tasks:")
        for t in owned_tasks[:10]:
            typer.echo(f"  - [{t.id[:8]}] {truncate(t.content)}")
        typer.echo()
        typer.echo("Before sleeping:")
        typer.echo('  space task done <id> "result"    — complete work')
    else:
        typer.echo("No tasks tracked this session.")
        typer.echo()
        typer.echo("Before sleeping:")
        typer.echo('  space task add "what you did"    — log work (for provenance)')
    typer.echo('  space decision "commitment"      — record decisions')
    typer.echo('  space insight "pattern learned"  — capture patterns')
    if has_uncommitted:
        typer.echo()
        typer.echo("WARNING: Uncommitted changes detected. Commit or stash before sleeping.")
    typer.echo()
    typer.echo("Then:")
    typer.echo('  space sleep "summary"')


def _check_uncommitted(cwd: str | None) -> bool:
    if not cwd:
        return False
    path = Path(cwd)
    if not path.exists():
        return False
    try:
        return git.dirty(path)
    except git.GitError:
        return False


def main() -> None:
    app()
