import os
import shutil
import socket
import subprocess
import sys
import time
import tomllib
from pathlib import Path

import qrcode
import typer

from space.os import agents


def _print_qr(url: str) -> None:
    qr = qrcode.QRCode(border=1)
    qr.add_data(url)
    qr.print_ascii()


def _bin(name: str) -> str:
    path = shutil.which(name)
    if not path:
        typer.echo(f"Missing required executable: {name}", err=True)
        raise typer.Exit(1)
    return path


def _kill_existing():
    pkill = _bin("pkill")
    subprocess.run([pkill, "-9", "-f", "uvicorn.*space.api"], capture_output=True, check=False)
    subprocess.run([pkill, "-9", "-f", "python.*space.api"], capture_output=True, check=False)
    subprocess.run([pkill, "-9", "-f", "expo.*start"], capture_output=True, check=False)
    subprocess.run([pkill, "-9", "-f", "metro"], capture_output=True, check=False)
    subprocess.run([pkill, "-9", "-f", "node.*expo"], capture_output=True, check=False)
    for _ in range(20):
        lsof = _bin("lsof")
        result = subprocess.run(
            [lsof, "-ti:8081,8228"], capture_output=True, text=True, check=False
        )
        pids = [p for p in result.stdout.strip().split("\n") if p]
        if not pids:
            return
        kill = _bin("kill")
        for pid in pids:
            subprocess.run([kill, "-9", pid], check=False)
        time.sleep(0.2)


def _get_local_ip() -> str:
    for path in [
        "/Applications/Tailscale.app/Contents/MacOS/Tailscale",
        "/opt/homebrew/bin/tailscale",
        "tailscale",
    ]:
        try:
            result = subprocess.run([path, "ip", "-4"], capture_output=True, text=True, timeout=2)
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except Exception:  # noqa: S112
            continue
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        return local_ip
    except Exception:
        return "127.0.0.1"


MARKER = "# managed by space launch"


def _sync_bin_scripts() -> list[str]:
    bin_dir = Path.home() / "bin"
    bin_dir.mkdir(exist_ok=True)
    space_dir = Path.home() / "space"
    uv_path = shutil.which("uv") or "uv"

    current_scripts: dict[str, Path] = {}
    for pyproject in space_dir.glob("**/pyproject.toml"):
        if ".venv" in pyproject.parts or "node_modules" in pyproject.parts:
            continue
        with pyproject.open("rb") as f:
            data = tomllib.load(f)
        scripts = data.get("project", {}).get("scripts", {})
        for name in scripts:
            current_scripts[name] = pyproject.parent

    for script in bin_dir.iterdir():
        if script.is_file() and MARKER in script.read_text() and script.name not in current_scripts:
            script.unlink()

    created = []
    for name, repo_dir in current_scripts.items():
        script = bin_dir / name
        expected = f"""#!/bin/sh
{MARKER}
cd {repo_dir} || exit 1
exec {uv_path} run "$(basename "$0")" "$@"
"""
        if not script.exists() or script.read_text() != expected:
            script.write_text(expected)
            script.chmod(0o755)
            created.append(name)

    return created


def launch():
    if os.getenv("SPACE_CAFFEINATED") != "1":
        env = os.environ.copy()
        env["SPACE_CAFFEINATED"] = "1"
        caffeinate = _bin("caffeinate")
        os.execvpe(caffeinate, [caffeinate, "-dims", *sys.argv], env)  # noqa: S606

    typer.echo("\nlaunching space...")

    synced = _sync_bin_scripts()
    if synced:
        typer.echo(f"synced ~/bin: {', '.join(synced)}")

    registered, _skipped = agents.defaults.ensure()
    if registered:
        typer.echo(f"registered: {', '.join(registered)}")

    _kill_existing()

    repo_root = Path(__file__).resolve().parent.parent.parent
    app_dir = repo_root / "app"

    procs: dict[str, subprocess.Popen[bytes]] = {}

    uv = _bin("uv")
    pnpm = _bin("pnpm")

    procs["api"] = subprocess.Popen(
        [
            uv,
            "run",
            "uvicorn",
            "space.api.main:app",
            "--host",
            "0.0.0.0",  # noqa: S104
            "--port",
            "8228",
            "--reload",
            "--reload-include",
            "space/**/*.py",
        ],
        cwd=str(repo_root),
    )

    procs["expo"] = subprocess.Popen(
        [pnpm, "start"],
        cwd=str(app_dir),
    )

    local_ip = _get_local_ip()

    typer.echo("✓ API        http://localhost:8228")
    typer.echo("✓ Expo       http://localhost:8081")
    typer.echo(f"✓ Network    http://{local_ip}:8228")
    typer.echo("  (use 'space swarm on' to start daemon)\n")

    expo_url = f"exp://{local_ip}:8081"
    typer.echo("✓ Tailscale  (scan with Expo Go)")
    _print_qr(expo_url)
    typer.echo(f"  {expo_url}\n")

    try:
        while True:
            for name, proc in list(procs.items()):
                if proc.poll() is not None:
                    if name == "api":
                        continue
                    if proc.returncode != 0:
                        typer.echo(f"\033[31m✗ {name} died (exit={proc.returncode})\033[0m")
                    del procs[name]
            time.sleep(2)

    except KeyboardInterrupt:
        typer.echo("\nStopping...")
    finally:
        for proc in procs.values():
            proc.terminate()
        raise typer.Exit(0)
