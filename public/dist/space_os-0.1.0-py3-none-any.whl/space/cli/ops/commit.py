import contextlib
import re
import subprocess
from typing import Annotated

import typer

from space.core.errors import NotFoundError
from space.core.models import Agent, Decision, Insight, Task, TaskStatus
from space.lib import identity as identity_lib
from space.lib import paths, store
from space.lib.commands import space_app
from space.os import agents, tasks

app = space_app("commit", purpose="git commit with links", injected=True, role="agents")

VALID_TAGS = {"feat", "fix", "refactor", "perf", "test", "chore", "docs", "audit", "spec"}
VERB_PREFIXES = {"add", "fix", "update", "remove", "change", "implement", "create", "delete"}


def _validate_message(msg: str) -> tuple[bool, str]:
    pattern = r"^([a-z]+)\(([a-z0-9-]+)\):\s+(.+)$"
    match = re.match(pattern, msg)
    if not match:
        return False, "format must be: tag(scope): concept"

    tag, _, concept = match.groups()

    if tag not in VALID_TAGS:
        return False, f"invalid tag '{tag}', use: {', '.join(sorted(VALID_TAGS))}"

    if msg.endswith("."):
        return False, "no trailing period"

    words = concept.split()
    if len(words) < 2 or len(words) > 6:
        return False, "concept should be 2-6 words"

    first_word = words[0].lower()
    if first_word in VERB_PREFIXES:
        return False, f"avoid verb prefix '{first_word}'"

    return True, ""


def _run_ci() -> bool:
    result = subprocess.run(["just", "ci"], capture_output=False)  # noqa: S607
    return result.returncode == 0


def _git_has_changes() -> bool:
    result = subprocess.run(
        ["git", "status", "--porcelain"],  # noqa: S607
        capture_output=True,
        text=True,
    )
    return bool(result.stdout.strip())


def _git_commit(message: str, body_lines: list[str]) -> bool:
    subprocess.run(["git", "add", "-A"], check=True)  # noqa: S607

    full_message = message
    if body_lines:
        full_message = message + "\n\n" + "\n".join(body_lines)

    result = subprocess.run(["git", "commit", "-m", full_message])  # noqa: S607
    return result.returncode == 0


def _resolve_id(ref: str, table: str, model: type) -> str | None:
    try:
        obj = store.resolve(ref, table, model)
        return obj.id
    except NotFoundError:
        return None


def _do_commit(
    message: str,
    agent: Agent | None,
    no_ci: bool,
    no_task: bool,
    decision_refs: list[str],
    insight_refs: list[str],
    done: bool,
) -> tuple[Task | None, list[str]]:
    valid, err = _validate_message(message)
    if not valid:
        typer.echo(f"Invalid: {err}", err=True)
        raise typer.Exit(1)

    if not _git_has_changes():
        typer.echo("Nothing to commit", err=True)
        raise typer.Exit(1)

    if not no_ci:
        typer.echo("Running CI...")
        if not _run_ci():
            typer.echo("CI failed", err=True)
            raise typer.Exit(1)

    body_lines: list[str] = []

    active_task: Task | None = None
    if not no_task and agent:
        active_task = tasks.get_active(agent.id)
        if active_task:
            body_lines.append(f"Task: {active_task.id[:8]}")

    spawn_id = paths.spawn_id()
    if spawn_id:
        body_lines.append(f"Spawn: {spawn_id[:8]}")

    for d in decision_refs:
        did = _resolve_id(d, "decisions", Decision)
        if did:
            body_lines.append(f"Decision: {did[:8]}")
        else:
            typer.echo(f"Decision not found: {d}", err=True)

    for i in insight_refs:
        iid = _resolve_id(i, "insights", Insight)
        if iid:
            body_lines.append(f"Insight: {iid[:8]}")
        else:
            typer.echo(f"Insight not found: {i}", err=True)

    if not _git_commit(message, body_lines):
        typer.echo("Commit failed", err=True)
        raise typer.Exit(1)

    typer.echo(f"Committed: {message}")

    if done and active_task and agent:
        tasks.set_status(active_task.id, TaskStatus.DONE, agent_id=agent.id)
        typer.echo(f"Done: {active_task.id[:8]}")

    return active_task, body_lines


@app.callback(invoke_without_command=True)
def default(
    cli_ctx: typer.Context,
    message: str | None = typer.Argument(None, help="tag(scope): concept"),
    no_ci: bool = typer.Option(False, "--no-ci", help="Skip just ci"),
    no_task: bool = typer.Option(False, "--no-task", help="Don't link active task"),
    decision: Annotated[
        list[str] | None, typer.Option("--decision", "-d", help="Decision ID(s) to link")
    ] = None,
    insight: Annotated[
        list[str] | None, typer.Option("--insight", "-i", help="Insight ID(s) to link")
    ] = None,
    done: bool = typer.Option(False, "--done", help="Mark active task done after commit"),
):
    if message is None:
        typer.echo(cli_ctx.get_help())
        raise typer.Exit(0)

    identity = identity_lib.current()
    agent: Agent | None = None
    if identity:
        with contextlib.suppress(NotFoundError):
            agent = agents.get_by_identity(identity)

    _do_commit(
        message,
        agent,
        no_ci,
        no_task,
        decision or [],
        insight or [],
        done,
    )


def main() -> None:
    app()
