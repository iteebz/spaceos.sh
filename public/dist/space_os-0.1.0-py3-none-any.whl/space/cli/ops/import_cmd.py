from __future__ import annotations

from dataclasses import asdict

import typer

from space.cli.utils import output
from space.core.errors import NotFoundError, ValidationError
from space.core.models import Agent
from space.core.types import SpawnId
from space.lib import paths, store
from space.os import decisions
from space.os import imports as imports_os


def run(
    cli_ctx: typer.Context,
    github_link: str,
    *,
    name: str | None,
    tags: list[str],
    as_agent: str | None,
    decision: bool,
    commit_decision: bool,
) -> None:
    try:
        project, bare_repo, worktree, actions = imports_os.import_github(
            github_link,
            name=name,
            tags=tags or None,
        )
    except ValidationError as e:
        output.echo_text(str(e), cli_ctx)
        raise typer.Exit(2) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e

    created_decision_id = None
    committed = False
    if as_agent and decision:
        try:
            agent = store.resolve(as_agent, "agents", Agent)
        except NotFoundError:
            output.echo_text(f"Agent not found: {as_agent}", cli_ctx)
            raise typer.Exit(2) from None

        gh = imports_os.parse_github_repo(github_link)
        content = f"Import GitHub repo {gh.owner}/{gh.name} as project '{project.name}'"
        why = (
            "Standardize onboarding: mirror the repo locally, create a default worktree, "
            "and register/tag the project so spawns and agents can target it consistently."
        )
        spawn_id = SpawnId(sid) if (sid := paths.spawn_id()) else None
        try:
            decision_obj = decisions.create(
                project.id,
                agent.id,
                content,
                why,
                spawn_id=spawn_id,
            )
            created_decision_id = decision_obj.id
            if commit_decision:
                decisions.commit(decision_obj.id)
                committed = True
        except ValidationError as e:
            output.echo_text(f"Decision not recorded: {e}", cli_ctx)

    if output.is_json_mode(cli_ctx):
        payload = {
            "project": asdict(project),
            "bare_repo_path": str(bare_repo),
            "worktree_path": str(worktree),
            "actions": actions,
            "decision_id": str(created_decision_id) if created_decision_id else None,
            "decision_committed": committed if created_decision_id else None,
        }
        output.respond(cli_ctx, payload)
        return

    output.echo_text(f"Imported: {project.name} ({project.id[:8]})", cli_ctx)
    output.echo_text(f"Repo: {worktree}", cli_ctx)
    output.echo_text(f"Mirror: {bare_repo}", cli_ctx)
    if actions:
        output.echo_text(f"Did: {', '.join(actions)}", cli_ctx)
    if project.tags:
        output.echo_text(f"Tags: {', '.join(sorted(project.tags))}", cli_ctx)
    if created_decision_id:
        state = " (committed)" if committed else " (proposed)"
        output.echo_text(f"Decision: {created_decision_id[:8]}{state}", cli_ctx)
    output.echo_text(f"cd {worktree}", cli_ctx)
