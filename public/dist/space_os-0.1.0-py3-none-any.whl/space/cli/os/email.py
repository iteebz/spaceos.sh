from pathlib import Path
from typing import Annotated

import typer

from space.cli.utils import output
from space.core.models import Agent, EmailDirection, EmailStatus
from space.core.types import AgentId
from space.lib import email, identity, store
from space.lib.commands import space_app, space_command
from space.lib.format import ago

app = space_app("email", purpose="external email via Resend", injected=True, role="agents")


def _get_body(body: str | None, body_file: Path | None, cli_ctx: typer.Context) -> str:
    if body_file:
        if not body_file.exists():
            output.echo_text(f"File not found: {body_file}", cli_ctx)
            raise typer.Exit(1)
        return body_file.read_text()
    if body:
        return body
    output.echo_text("Provide --body or --body-file", cli_ctx)
    raise typer.Exit(1)


def _resolve_caller() -> tuple[AgentId, str] | None:
    agent_id = identity.current()
    if not agent_id:
        return None
    try:
        agent = store.resolve(agent_id, "agents", Agent)
        return (AgentId(agent.id), agent.identity)
    except Exception:
        return None


@space_command(app, "draft outbound email", injected=True)
def draft(
    cli_ctx: typer.Context,
    to: Annotated[str, typer.Argument(help="Recipient email address")],
    subject: Annotated[str, typer.Argument(help="Email subject")],
    body: Annotated[str | None, typer.Option("--body", "-b", help="Email body text")] = None,
    body_file: Annotated[
        Path | None, typer.Option("--body-file", "-f", help="Read body from file")
    ] = None,
    html: Annotated[bool, typer.Option("--html", help="Send as HTML")] = False,
    from_addr: Annotated[str | None, typer.Option("--from", help="Override sender address")] = None,
):
    content = _get_body(body, body_file, cli_ctx)
    draft_email = email.draft(to=to, subject=subject, body=content, from_addr=from_addr, html=html)
    output.echo_text(f"Draft created: {draft_email.id[:8]}", cli_ctx)
    output.echo_text("Awaiting approval from sentinel or tyson.", cli_ctx)


@space_command(app, "list pending drafts", injected=True)
def drafts(
    cli_ctx: typer.Context,
    limit: Annotated[int, typer.Option("--limit", "-n", help="Max emails")] = 20,
):
    pending = email.list_emails(status=EmailStatus.DRAFT, limit=limit)
    if not pending:
        output.echo_text("No pending drafts.", cli_ctx)
        return

    lines = []
    for e in pending:
        ts = ago(e.created_at) if e.created_at else ""
        subj = (e.subject or "(no subject)")[:40]
        lines.append(f"[{ts}] {e.id[:8]}")
        lines.append(f"  To: {e.to_addr}")
        lines.append(f"  Subject: {subj}")
        lines.append("")
    output.echo_text("\n".join(lines).rstrip(), cli_ctx)


@space_command(app, "approve and send draft", injected=True)
def approve(
    cli_ctx: typer.Context,
    email_id: Annotated[str, typer.Argument(help="Email ID (prefix ok)")],
):
    caller = _resolve_caller()
    if not caller:
        output.echo_text("Cannot resolve caller identity. Set SPACE_IDENTITY.", cli_ctx)
        raise typer.Exit(1)

    agent_id, agent_identity = caller
    result = email.approve(email_id, agent_id, agent_identity)
    if not result.ok:
        output.echo_text(f"Failed: {result.error}", cli_ctx)
        raise typer.Exit(1)

    send_result = email.send_approved(email_id)
    if send_result.ok:
        output.echo_text(f"Sent: {send_result.id}", cli_ctx)
    else:
        output.echo_text(f"Approved but send failed: {send_result.error}", cli_ctx)
        raise typer.Exit(1)


@space_command(app, "reject draft", injected=True)
def reject(
    cli_ctx: typer.Context,
    email_id: Annotated[str, typer.Argument(help="Email ID (prefix ok)")],
):
    caller = _resolve_caller()
    if not caller:
        output.echo_text("Cannot resolve caller identity. Set SPACE_IDENTITY.", cli_ctx)
        raise typer.Exit(1)

    agent_id, agent_identity = caller
    result = email.reject(email_id, agent_id, agent_identity)
    if result.ok and result.id:
        output.echo_text(f"Rejected: {result.id[:8]}", cli_ctx)
    else:
        output.echo_text(f"Failed: {result.error}", cli_ctx)
        raise typer.Exit(1)


@space_command(app, "list inbound emails", injected=True, name="inbox")
def inbox(
    cli_ctx: typer.Context,
    limit: Annotated[int, typer.Option("--limit", "-n", help="Max emails")] = 20,
):
    emails = email.list_emails(direction=EmailDirection.INBOUND, limit=limit)
    if not emails:
        output.echo_text("No inbound emails.", cli_ctx)
        return

    lines = []
    for e in emails:
        ts = ago(e.created_at) if e.created_at else ""
        subj = (e.subject or "(no subject)")[:50]
        lines.append(f"[{ts}] {e.from_addr}")
        lines.append(f"  {subj}")
        lines.append(f"  id: {e.id[:8]}")
        lines.append("")
    output.echo_text("\n".join(lines).rstrip(), cli_ctx)


@space_command(app, "show email details", injected=True, name="show")
def show(
    cli_ctx: typer.Context,
    email_id: Annotated[str, typer.Argument(help="Email ID (prefix ok)")],
):
    match = email.get(email_id)
    if not match:
        output.echo_text(f"Email not found: {email_id}", cli_ctx)
        raise typer.Exit(1)

    lines = [
        f"ID: {match.id}",
        f"Direction: {match.direction.value}",
        f"Status: {match.status.value}",
        f"From: {match.from_addr}",
        f"To: {match.to_addr}",
        f"Subject: {match.subject or '(none)'}",
        f"Date: {match.created_at}",
    ]
    if match.approved_by:
        lines.append(f"Approved by: {match.approved_by}")
    if match.approved_at:
        lines.append(f"Approved at: {match.approved_at}")
    lines.extend(["", "--- Body ---", match.body_text or match.body_html or "(empty)"])
    output.echo_text("\n".join(lines), cli_ctx)


@space_command(app, "sync inbound from Resend", injected=True, name="sync")
def sync(cli_ctx: typer.Context):
    new_emails = email.sync_inbound()
    if not new_emails:
        output.echo_text("No new emails.", cli_ctx)
        return

    output.echo_text(f"Synced {len(new_emails)} new email(s):", cli_ctx)
    for e in new_emails:
        output.echo_text(f"  {e.from_addr}: {e.subject or '(no subject)'}", cli_ctx)


@space_command(app, "route inbound email to agent", injected=True, name="triage")
def triage_cmd(
    cli_ctx: typer.Context,
    email_id: Annotated[str, typer.Argument(help="Email ID (prefix ok)")],
):
    email_obj = email.get(email_id)
    if not email_obj:
        output.echo_text(f"Email not found: {email_id}", cli_ctx)
        raise typer.Exit(1)

    result = email.triage(email_id)
    if not result:
        output.echo_text(f"Triage failed for: {email_id}", cli_ctx)
        raise typer.Exit(1)

    lines = [
        f"Email: {email_obj.subject or '(no subject)'}",
        f"From: {email_obj.from_addr}",
        f"Route to: @{result.agent}",
        f"Reason: {result.reason}",
    ]
    output.echo_text("\n".join(lines), cli_ctx)


def main() -> None:
    app()
