import json
import random
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

import typer

from space.cli.utils import output
from space.core.models import Agent, Spawn, SpawnStatus
from space.core.types import AgentId, SpawnId
from space.lib import config, format, paths, providers, store
from space.os import agents, daemon, spawns, stats

app = typer.Typer(
    help="autonomous agent spawning",
    context_settings={"help_option_names": ["-h", "--help"]},
    no_args_is_help=False,
    add_completion=False,
    rich_markup_mode=None,
)


@app.callback(invoke_without_command=True)
def swarm_callback(
    cli_ctx: typer.Context,
    watch: bool = typer.Option(False, "--watch", "-w", help="Live-updating display"),
):
    if cli_ctx.invoked_subcommand is None:
        if watch:
            _watch_loop(cli_ctx)
        else:
            _render_snapshot(cli_ctx)


def _clear_screen() -> None:
    sys.stdout.write("\033[H\033[J")
    sys.stdout.flush()


def _watch_loop(cli_ctx: typer.Context) -> None:
    try:
        while True:
            _clear_screen()
            _render_snapshot(cli_ctx)
            time.sleep(1)
    except KeyboardInterrupt:
        pass


def _bar(pct: float, width: int = 20) -> str:
    filled = int(pct / 100 * width)
    return "\033[32m" + "█" * filled + "\033[90m" + "░" * (width - filled) + "\033[0m"


def _render_snapshot(cli_ctx: typer.Context) -> None:
    data = stats.swarm()
    live_data = stats.live()
    daemon_status = daemon.status()

    if output.is_json_mode(cli_ctx):
        output.respond(cli_ctx, {**data, "live": live_data, "daemon": daemon_status})
        return

    has_content = False

    active_count = sum(1 for s in live_data if s["status"] == "active")
    last_skip = daemon_status.get("last_skip")
    if active_count == 0 and daemon_status.get("enabled") and isinstance(last_skip, str):
        skip_ago = format.ago(last_skip)
        typer.echo(f"\033[90m[DAEMON] no state change, skipping spawn ({skip_ago})\033[0m")
        has_content = True

    if live_data:
        typer.echo("\n[AGENTS]" if has_content else "[AGENTS]")
        for s in live_data:
            if s["status"] == "active":
                bar = _bar(s["health"], width=16)
                pct = f"{s['health']:>3.0f}%"
            else:
                bar = "\033[90m" + "·" * 16 + "\033[0m"
                pct = "   -"
            last = format.ago(s.get("last_active"))
            desc = s.get("description", "")
            task = s.get("task", "")
            role_color = "\033[2;33m" if s["status"] == "active" else "\033[90m"
            typer.echo(
                f"  \033[33m{s['identity']:<10}\033[0m {role_color}· {desc:<20}\033[0m "
                f"{bar} {pct} \033[2m{last:<4}\033[0m {task}"
            )
        has_content = True

    if data["active"]:
        typer.echo("\n[TASKS]" if has_content else "[TASKS]")
        for t in data["active"]:
            typer.echo(f"  @{t['agent']}: {t['content']}")
        has_content = True
    if data["committed"]:
        typer.echo("\n[COMMITTED]" if has_content else "[COMMITTED]")
        for d in data["committed"]:
            typer.echo(f"  d/{d['id']}: {d['content']}")
        has_content = True
    if data["questions"]:
        typer.echo("\n[QUESTIONS]" if has_content else "[QUESTIONS]")
        for q in data["questions"]:
            typer.echo(f"  [{q['agent']}] {q['content']}")
        has_content = True
    if data["recent"] and not live_data:
        typer.echo("\n[RECENT]" if has_content else "[RECENT]")
        for r in data["recent"]:
            typer.echo(f"  @{r['agent']}: {r['summary']}")


def _split_list(items: list[str] | None) -> list[str] | None:
    if not items:
        return None
    result = []
    for item in items:
        result.extend(x.strip() for x in item.split(",") if x.strip())
    return result or None


@app.command("on")
def on(
    cli_ctx: typer.Context,
    limit: int = typer.Option(None, "--limit", "-l", help="Stop after N spawns"),
    concurrency: int = typer.Option(None, "--concurrency", "-c", help="Max concurrent spawns"),
    force: bool = typer.Option(
        False, "--force", "-f", help="Spawn agents regardless of state change"
    ),
    agent_list: list[str] = typer.Option(None, "--agents", "-a", help="Allowed agents"),  # noqa: B008
    project_list: list[str] = typer.Option(None, "--projects", "-p", help="Target projects"),  # noqa: B008
):
    """Enable autonomous agent wakes."""
    agent_filter = _split_list(agent_list)
    project_filter = _split_list(project_list)
    reset_filters = agent_filter is None and project_filter is None and not force
    was_off = daemon.on(
        limit,
        concurrency,
        agent_filter,
        project_filter,
        force=force or None,
        reset_filters=reset_filters,
    )

    if was_off or not daemon.pid():
        daemon.start()

    cfg = config.load().swarm
    pid = daemon.pid()
    msg = "enabled" if was_off else "already on"
    if pid:
        msg += f" (pid {pid})"
    parts = []
    if cfg.limit:
        parts.append(f"limit: {cfg.limit}")
    if cfg.concurrency > 1:
        parts.append(f"concurrency: {cfg.concurrency}")
    if cfg.force:
        parts.append("force")
    if cfg.agents:
        parts.append(f"agents: {', '.join(cfg.agents)}")
    if cfg.projects:
        parts.append(f"projects: {', '.join(cfg.projects)}")
    if parts:
        msg += f" ({', '.join(parts)})"
    output.respond(
        cli_ctx,
        {
            "enabled": True,
            "pid": pid,
            "limit": cfg.limit,
            "concurrency": cfg.concurrency,
            "force": cfg.force,
            "agents": cfg.agents,
            "projects": cfg.projects,
        },
        msg,
    )


@app.command("off")
def off(cli_ctx: typer.Context):
    """Disable autonomous agent wakes and stop daemon."""
    was_on = daemon.off()
    daemon.stop()
    msg = "disabled" if was_on else "already off"
    output.respond(cli_ctx, {"enabled": False, "pid": None}, msg)


SLEEPY_BRRS = [
    "~brr... brr... (yawn)~",
    "~zzz... brr... zzz~",
    "~brr.......... brr..~",
    "~(sleepy brr noises)~",
    "~brr~ ...goodnight",
]


@app.command("sleep")
def sleep_cmd(cli_ctx: typer.Context):
    """Put the swarm to sleep. Sweet dreams, little agents."""
    was_on = daemon.off()
    daemon.stop()

    if output.is_json_mode(cli_ctx):
        output.respond(cli_ctx, {"enabled": False, "pid": None, "sleeping": True})
        return

    if was_on:
        brr = random.choice(SLEEPY_BRRS)  # noqa: S311
        typer.echo(f"\033[2m{brr}\033[0m")
    else:
        typer.echo("\033[2m~already asleep~\033[0m")


@app.command("status")
def status(cli_ctx: typer.Context):
    """Show autonomous spawn status."""
    enabled = daemon.is_on()
    cfg = config.load().swarm

    data = {
        "enabled": enabled,
        "limit": cfg.limit,
        "concurrency": cfg.concurrency,
        "force": cfg.force,
        "agents": cfg.agents,
        "projects": cfg.projects,
        "enabled_at": cfg.enabled_at,
    }

    if not enabled:
        output.respond(cli_ctx, data, "off")
        return

    parts = []
    if cfg.limit:
        parts.append(f"limit: {cfg.limit}")
    parts.append(f"concurrency: {cfg.concurrency}")
    if cfg.force:
        parts.append("force")
    if cfg.agents:
        parts.append(f"agents: {', '.join(cfg.agents)}")
    if cfg.projects:
        parts.append(f"projects: {', '.join(cfg.projects)}")

    msg = f"on ({', '.join(parts)})"
    output.respond(cli_ctx, data, msg)


CRASH_ERRORS = ["orphaned process", "terminated", "timeout"]


def _fetch_crashed(
    agent_id: AgentId | None = None,
    since: str | None = None,
    limit: int | None = None,
) -> list[Spawn]:
    return spawns.fetch(
        agent_id=agent_id,
        status=SpawnStatus.DONE,
        has_session=True,
        errors=CRASH_ERRORS,
        since=since,
        limit=limit,
    )


@app.command("continue")
def continue_cmd(
    cli_ctx: typer.Context,
    identity: str | None = typer.Option(None, "--agent", "-a", help="Filter by agent"),
    since: str | None = typer.Option(None, "--since", "-s", help="Time window (e.g. 1h, 1d)"),
    limit: int = typer.Option(10, "--limit", "-n", help="Max spawns to resume"),
    dry_run: bool = typer.Option(False, "--dry-run", "-d", help="List without resuming"),
):
    """Resume crashed/orphaned spawns with existing sessions."""
    since_iso: str | None = None
    if since:
        try:
            delta = format.parse_duration(since)
        except ValueError:
            typer.echo(f"Invalid duration: {since}", err=True)
            raise typer.Exit(1) from None
        since_iso = (datetime.now(UTC) - delta).isoformat()

    agent: Agent | None = None
    if identity:
        agent = store.resolve(identity, "agents", Agent)

    crashed = _fetch_crashed(
        agent_id=agent.id if agent else None,
        since=since_iso,
        limit=limit,
    )

    if not crashed:
        output.respond(cli_ctx, {"resumed": []}, "no crashed spawns")
        return

    if dry_run:
        agent_ids = list({s.agent_id for s in crashed})
        agent_map = agents.batch_get(agent_ids)
        lines = []
        for s in crashed:
            a = agent_map.get(s.agent_id)
            identity_str = a.identity if a else s.agent_id[:8]
            lines.append(f"  {s.id[:8]} @{identity_str} ({s.error})")
        typer.echo(f"[CRASHED] ({len(crashed)})")
        for line in lines:
            typer.echo(line)
        return

    resumed: list[dict[str, str]] = []
    for s in crashed:
        agent_obj = agents.get(s.agent_id)
        try:
            spawns.launch(agent=agent_obj, project_id=s.project_id, spawn=s)
            resumed.append({"id": s.id, "agent": agent_obj.identity})
            output.echo_text(f"Resumed: {s.id[:8]} ({agent_obj.identity})", cli_ctx)
        except Exception as e:
            output.echo_text(f"Failed: {s.id[:8]} - {e}", cli_ctx)

    output.respond(cli_ctx, {"resumed": resumed}, f"resumed {len(resumed)} spawns")


def _events_file(spawn: Spawn) -> Path | None:
    spawns_dir = paths.dot_space() / "spawns"
    for provider in providers.PROVIDER_NAMES:
        candidate = spawns_dir / provider / f"{spawn.id}.jsonl"
        if candidate.exists():
            return candidate
    return None


def _format_replay_event(
    d: dict[str, object], identity: str, ctx_pct: float | None = None
) -> str | None:
    etype = d.get("type")
    pct_str = f"{ctx_pct:>3.0f}%" if ctx_pct is not None else "   -"
    prefix = f"\033[36m{pct_str}\033[0m \033[33m{identity[:10]:<10}\033[0m"
    home = str(Path.home())

    if etype == "assistant":
        msg = d.get("message")
        content = msg.get("content", []) if isinstance(msg, dict) else []
        if not content:
            return None
        c = content[0]
        if c.get("type") == "text":
            text = c.get("text", "").replace(home, "~")
            lines = text.split("\n")
            first = lines[0]
            if len(lines) > 1:
                first += f" \033[2m(+{len(lines) - 1} lines)\033[0m"
            return f"{prefix} \033[32m>>\033[0m {first}"
        if c.get("type") == "tool_use":
            name = c.get("name", "?")
            inp = c.get("input", {})
            arg = (
                inp.get("command")
                or inp.get("pattern")
                or inp.get("file_path")
                or inp.get("query")
                or ""
            )
            if isinstance(arg, str):
                arg = arg.replace(home, "~").split("\n")[0][:60]
            return f"{prefix} \033[35m{name}\033[0m {arg}"
    elif etype == "result":
        sub = d.get("subtype", "done")
        return f"{prefix} \033[2m<< {sub}\033[0m"
    return None


def _parse_timestamp(ts: str | None) -> datetime | None:
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts)
    except (ValueError, TypeError):
        return None


@app.command("replay")
def replay_cmd(
    cli_ctx: typer.Context,
    spawn_id: str = typer.Argument(None, help="Spawn ID to replay"),
    speed: float = typer.Option(10.0, "--speed", "-s", help="Playback speed multiplier"),
    no_delay: bool = typer.Option(False, "--no-delay", help="Play all events instantly"),
    agent_filter: str = typer.Option(None, "--agent", "-a", help="Replay last spawn from agent"),
):
    """Replay a historical spawn session."""
    spawn: Spawn | None = None

    if agent_filter:
        agent = store.resolve(agent_filter, "agents", Agent)
        recent = spawns.fetch(agent_id=agent.id, limit=1)
        if not recent:
            typer.echo(f"No spawns found for agent: {agent_filter}", err=True)
            raise typer.Exit(1) from None
        spawn = recent[0]
    elif spawn_id:
        try:
            spawn = spawns.get(SpawnId(spawn_id))
        except Exception:
            typer.echo(f"Spawn not found: {spawn_id}", err=True)
            raise typer.Exit(1) from None
    else:
        recent = spawns.fetch(limit=1)
        if not recent:
            typer.echo("No spawns found", err=True)
            raise typer.Exit(1) from None
        spawn = recent[0]

    events_file = _events_file(spawn)
    if not events_file:
        typer.echo(f"No events file for spawn: {spawn.id[:8]}", err=True)
        raise typer.Exit(1) from None

    agent = agents.get(spawn.agent_id)
    identity = agent.identity if agent else spawn.id[:8]

    events: list[tuple[datetime | None, dict[str, object], float | None]] = []
    ctx_pct: float | None = None

    with events_file.open() as f:
        for line in f:
            line = line.rstrip()
            if not line:
                continue
            try:
                d = json.loads(line)
                ts = _parse_timestamp(d.get("timestamp"))
                if (msg := d.get("message")) and (u := msg.get("usage")):
                    inp = u.get("input_tokens", 0) + u.get("cache_read_input_tokens", 0)
                    if inp > 0:
                        ctx_pct = max(0, 100 - inp / 200000 * 100)
                events.append((ts, d, ctx_pct))
            except json.JSONDecodeError:
                continue

    if not events:
        typer.echo("No events to replay", err=True)
        raise typer.Exit(1) from None

    typer.echo(f"\033[2mReplaying {identity} @ {speed}x ({len(events)} events)\033[0m\n")

    prev_ts: datetime | None = None
    try:
        for ts, event, pct in events:
            if not no_delay and ts and prev_ts:
                delta = (ts - prev_ts).total_seconds()
                if delta > 0:
                    time.sleep(min(delta / speed, 2.0))
            prev_ts = ts

            formatted = _format_replay_event(event, identity, pct)
            if formatted:
                typer.echo(formatted)
    except KeyboardInterrupt:
        typer.echo("\n\033[2m[interrupted]\033[0m")

    typer.echo("\n\033[2m[replay complete]\033[0m")


def main() -> None:
    app()
