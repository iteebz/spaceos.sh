import json

import typer

from space.cli.utils import output
from space.cli.utils.decorators import cli_entrypoint
from space.core.errors import NotFoundError
from space.core.models import Project
from space.core.types import SpawnId
from space.lib import paths, store
from space.lib.commands import space_app, space_command
from space.lib.format import ago
from space.os import projects, spawns

app = space_app("project", purpose="Project registry. Projects map to git repositories.")


@space_command(app, "list registered projects", name="list", aliases=["ls"])
def list_projects(
    cli_ctx: typer.Context,
    show_all: bool = typer.Option(False, "--all", "-a", help="Include archived projects"),
    tag: str = typer.Option(None, "--tag", "-t", help="Filter by tag"),
    sort: str = typer.Option(
        "recent",
        "--sort",
        "-s",
        help="Sort by: recent, name, created",
    ),
    asc: bool = typer.Option(False, "--asc", help="Sort ascending (default desc for recent)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """List registered projects."""
    if tag:
        project_list = projects.fetch_by_tag(tag, include_archived=show_all)
    else:
        project_list = projects.fetch(include_archived=show_all)

    if not project_list:
        if json_output:
            typer.echo(json.dumps([], indent=2))
        else:
            output.echo_text("No projects found.", cli_ctx)
        return

    sort_key = (sort or "").strip().lower()
    if sort_key not in {"recent", "name", "created"}:
        typer.echo(f"Invalid --sort: {sort}. Use: recent, name, created", err=True)
        raise typer.Exit(2)

    last_active_by_project = projects.batch_last_active([p.id for p in project_list])
    if sort_key == "recent":
        project_list = sorted(
            project_list,
            key=lambda p: (last_active_by_project.get(p.id) or p.created_at or "", p.name),
            reverse=not asc,
        )
    elif sort_key == "created":
        project_list = sorted(
            project_list, key=lambda p: (p.created_at or "", p.name), reverse=not asc
        )
    else:
        project_list = sorted(project_list, key=lambda p: p.name, reverse=asc)

    data = [
        {
            "name": p.name,
            "project_id": p.id,
            "repo_path": p.repo_path,
            "tags": p.tags,
            "created_at": p.created_at,
            "last_active_at": last_active_by_project.get(p.id),
            "archived_at": p.archived_at,
        }
        for p in project_list
    ]

    if json_output:
        typer.echo(json.dumps(data, indent=2))
    else:
        lines = [
            f"{'name':<20} {'repo_path':<40} {'tags':<15} {'last':<6} {'created'}",
            "-" * 98,
        ]
        for p in project_list:
            name = p.name
            if p.archived_at:
                name = f"{name} (archived)"
            path = p.repo_path or "(no repo)"
            if len(path) > 38:
                path = "..." + path[-35:]
            tags_str = ",".join(p.tags) if p.tags else ""
            if len(tags_str) > 13:
                tags_str = tags_str[:12] + "..."
            last_str = ago(last_active_by_project.get(p.id))
            lines.append(f"{name:<20} {path:<40} {tags_str:<15} {last_str:<6} {ago(p.created_at)}")
        output.echo_text("\n".join(lines), cli_ctx)


@space_command(app, "show project details", name="info", aliases=["show", "get"])
def info(
    cli_ctx: typer.Context,
    ref: str = typer.Argument(..., help="Project name or ID"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """View project details."""
    try:
        project = store.resolve(ref, "projects", Project)
    except NotFoundError:
        typer.echo(f"Project not found: {ref}", err=True)
        raise typer.Exit(1) from None

    data = {
        "name": project.name,
        "project_id": project.id,
        "repo_path": project.repo_path,
        "tags": project.tags,
        "created_at": project.created_at,
        "archived_at": project.archived_at,
    }

    if json_output:
        typer.echo(json.dumps(data, indent=2))
    else:
        output.echo_text(f"Project: {project.name}", cli_ctx)
        output.echo_text(f"ID: {project.id}", cli_ctx)
        if project.repo_path:
            output.echo_text(f"Path: {project.repo_path}", cli_ctx)
        if project.tags:
            output.echo_text(f"Tags: {', '.join(project.tags)}", cli_ctx)
        output.echo_text(f"Created: {ago(project.created_at)}", cli_ctx)
        if project.archived_at:
            output.echo_text(f"Archived: {ago(project.archived_at)}", cli_ctx)


@space_command(app, "register a new project", name="create", aliases=["add", "new"])
def create(
    cli_ctx: typer.Context,
    name: str = typer.Argument(..., help="Project name"),
    path: str = typer.Option(None, "--path", "-d", help="Repository path"),
):
    """Register a new project."""
    try:
        project = projects.create(name, repo_path=path)
        output.echo_text(f"Created: {project.name} ({project.id[:8]})", cli_ctx)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


@space_command(app, "modify project fields", name="update", aliases=["edit", "modify"])
def update(
    cli_ctx: typer.Context,
    ref: str = typer.Argument(..., help="Project name or ID"),
    name: str = typer.Option(None, "--name", "-n", help="New name"),
    path: str = typer.Option(None, "--path", "-d", help="New repository path"),
):
    """Modify project fields."""
    try:
        project = store.resolve(ref, "projects", Project)
        projects.update(project.id, name=name, repo_path=path if path else None)
        output.echo_text(f"Updated: {project.name}", cli_ctx)
    except NotFoundError:
        typer.echo(f"Project not found: {ref}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


@space_command(app, "rename a project", name="rename", aliases=["mv"])
def rename(
    cli_ctx: typer.Context,
    ref: str = typer.Argument(..., help="Project name or ID"),
    new_name: str = typer.Argument(..., help="New name"),
):
    """Rename a project."""
    try:
        project = store.resolve(ref, "projects", Project)
        projects.update(project.id, name=new_name)
        output.echo_text(f"Renamed: {project.name} -> {new_name}", cli_ctx)
    except NotFoundError:
        typer.echo(f"Project not found: {ref}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


@space_command(app, "select project for current spawn", name="select", aliases=["choose", "pick"])
def select(
    cli_ctx: typer.Context,
    ref: str = typer.Argument(..., help="Project name or ID"),
):
    """Select project for current spawn. Used by unassigned agents."""
    spawn_id = paths.spawn_id()
    if not spawn_id:
        typer.echo("Not running in a spawn context", err=True)
        raise typer.Exit(1)

    try:
        project = store.resolve(ref, "projects", Project)
    except NotFoundError:
        typer.echo(f"Project not found: {ref}", err=True)
        raise typer.Exit(1) from None

    spawns.assign_project(SpawnId(spawn_id), project.id)
    output.echo_text(f"Selected: {project.name}", cli_ctx)
    output.echo_text("", cli_ctx)
    output.echo_text("Your artifacts now go to this project (persists for session).", cli_ctx)
    if project.repo_path:
        output.echo_text(f"cd {project.repo_path}", cli_ctx)


@space_command(app, "archive or restore projects", name="archive")
def archive(
    cli_ctx: typer.Context,
    refs: list[str],
    restore_flag: bool = typer.Option(False, "--restore", help="Restore instead of archive"),
    tags: list[str] = typer.Option([], "--tag", "-t", help="Tags to apply when archiving"),  # noqa: B008
):
    """Archive or restore projects."""
    for ref in refs:
        try:
            project = store.resolve(ref, "projects", Project)
        except NotFoundError:
            typer.echo(f"Project not found: {ref}", err=True)
            continue

        if restore_flag:
            projects.restore(project.id)
            output.echo_text(f"Restored: {project.name}", cli_ctx)
        else:
            projects.archive(project.id, tags=tags if tags else None)
            tag_str = f" [{', '.join(tags)}]" if tags else ""
            output.echo_text(f"Archived: {project.name}{tag_str}", cli_ctx)


@space_command(app, "manage project tags", name="tag", aliases=["tags"])
def tag(
    cli_ctx: typer.Context,
    ref: str = typer.Argument(..., help="Project name or ID"),
    tags: list[str] = typer.Argument(None, help="Tags to add"),  # noqa: B008
    remove: bool = typer.Option(False, "--remove", "-r", help="Remove tags instead of adding"),
    clear: bool = typer.Option(False, "--clear", help="Clear all tags"),
):
    """Manage project tags."""
    try:
        project = store.resolve(ref, "projects", Project)
    except NotFoundError:
        typer.echo(f"Project not found: {ref}", err=True)
        raise typer.Exit(1) from None

    if clear:
        projects.set_tags(project.id, None)
        output.echo_text(f"Cleared tags: {project.name}", cli_ctx)
        return

    if not tags:
        current = project.tags or []
        if current:
            output.echo_text(f"{project.name}: {', '.join(current)}", cli_ctx)
        else:
            output.echo_text(f"{project.name}: (no tags)", cli_ctx)
        return

    if remove:
        updated = projects.remove_tags(project.id, list(tags))
    else:
        updated = projects.add_tags(project.id, list(tags))

    current = updated.tags or []
    output.echo_text(f"{project.name}: {', '.join(current) if current else '(no tags)'}", cli_ctx)


@cli_entrypoint
def main():
    app()


if __name__ == "__main__":
    main()
