import re
from dataclasses import asdict

import typer

from space.cli.utils import output
from space.cli.utils.decorators import requires
from space.core.errors import NotFoundError, ValidationError
from space.core.models import Agent, Decision, Insight, Project
from space.core.types import INSIGHT_DOMAINS, SpawnId
from space.lib import paths, store
from space.lib.commands import space_app, space_command
from space.lib.format import agent_name, ago
from space.os import agents, insights, projects, replies

DEFAULT_LIST_LIMIT = 50

app = space_app("insight", purpose="atomic observations (≤280 chars)", injected=True, role="agents")


@space_command(app, "record atomic insight", injected=True, aliases=["create"])
@requires("agent", "project", "decision?")
def add(
    cli_ctx: typer.Context,
    agent: Agent,
    project: Project,
    decision: Decision | None,
    content: str = typer.Argument(..., help="Insight content (max 280 chars)"),
    domain: str = typer.Option(
        ..., "--domain", "-d", help=f"Domain ({', '.join(sorted(INSIGHT_DOMAINS))})"
    ),
    open_: bool = typer.Option(False, "--open", "-o", help="Mark as open question"),
):
    normalized = domain.lower().replace("_", "-").strip("/")
    if (
        not normalized
        or "//" in normalized
        or not re.match(r"^[a-z0-9\-]+(/[a-z0-9\-]+)*$", normalized)
    ):
        raise ValidationError(f"Invalid domain '{domain}'")

    is_question = not open_ and content.rstrip().endswith("?")
    if is_question:
        open_ = True

    _, invalid_mentions = replies.validate_mentions(content)
    if invalid_mentions:
        typer.echo(f"WARNING: unknown @mention(s): {', '.join(invalid_mentions)}", err=True)

    try:
        spawn_id = SpawnId(sid) if (sid := paths.spawn_id()) else None
        entry = insights.create(
            project.id,
            agent.id,
            content,
            normalized,
            spawn_id=spawn_id,
            decision_id=decision.id if decision else None,
            open=open_,
        )
    except ValidationError as e:
        output.echo_text(str(e), cli_ctx)
        raise typer.Exit(1) from None

    if output.echo_json(asdict(entry), cli_ctx):
        return

    open_mark = " [OPEN]" if entry.open else ""
    lines = [
        f"Insight {entry.id[:8]} by {agent.identity}{open_mark}",
        f"  #{entry.domain}: {entry.content}",
    ]
    output.echo_text("\n".join(lines), cli_ctx)


@space_command(app, "list insights", injected=True, name="list", aliases=["ls"])
@requires("project?")
def list_insights(
    cli_ctx: typer.Context,
    project: Project | None,
    domain: str = typer.Option(None, "--domain", "-d", help="Filter by domain"),
    all_: bool = typer.Option(False, "--all", "-a", help="Include archived"),
    limit: int = typer.Option(DEFAULT_LIST_LIMIT, "--limit", "-n", help="Limit results"),
    as_agent: str = typer.Option(None, "--as", help="Filter by agent identity"),
    open_: bool = typer.Option(False, "--open", "-o", help="Show only open questions"),
    closed: bool = typer.Option(False, "--closed", "-c", help="Show only closed questions"),
):
    """List insights."""
    agent_id = store.resolve(as_agent, "agents", Agent).id if as_agent else None
    if open_ and closed:
        output.echo_text("Cannot specify both --open and --closed", cli_ctx)
        raise typer.Exit(1)
    if open_:
        entries = insights.fetch_open(project_id=project.id if project else None, limit=limit)
        if agent_id:
            entries = [e for e in entries if e.agent_id == agent_id]
    elif closed:
        entries = insights.fetch_closed(project_id=project.id if project else None, limit=limit)
        if agent_id:
            entries = [e for e in entries if e.agent_id == agent_id]
    else:
        entries = insights.fetch(
            agent_id=agent_id,
            domain=domain,
            include_archived=all_,
            limit=limit,
            project_id=project.id if project else None,
        )

    if not entries:
        if output.is_json_mode(cli_ctx):
            output.echo_json([], cli_ctx)
        else:
            msg = (
                "No open questions."
                if open_
                else "No closed questions."
                if closed
                else "No insights found."
            )
            output.echo_text(msg, cli_ctx)
        return

    if output.echo_json([asdict(e) for e in entries], cli_ctx):
        return

    lines = []
    for e in entries:
        ts = ago(e.created_at)
        marks = ""
        if e.open:
            marks += " [OPEN]"
        if e.archived_at:
            marks += " [ARCHIVED]"
        lines.append(f"[{ts}] ({e.id[:8]}) {e.content} #{e.domain}{marks}")
    output.echo_text("\n".join(lines), cli_ctx)


@space_command(app, "show insight", injected=True, name="show", aliases=["get"])
def show(
    cli_ctx: typer.Context,
    insight_id: str = typer.Argument(..., help="Insight ID"),
):
    """Show insight details with reply thread."""
    try:
        entry = store.resolve(insight_id, "insights", Insight)
    except NotFoundError:
        output.echo_text(f"Not found: {insight_id}", cli_ctx)
        raise typer.Exit(1) from None

    thread = replies.fetch_for_parent("insight", entry.id)

    if output.echo_json(
        {"insight": asdict(entry), "replies": [asdict(r) for r in thread]}, cli_ctx
    ):
        return

    agent_obj = agents.get(entry.agent_id)
    project_obj = projects.try_get(entry.project_id)
    project_name = project_obj.name if project_obj else f"(deleted:{entry.project_id[:8]})"
    lines = [
        f"ID: {entry.id}",
        f"Project: {project_name}",
        f"Domain: {entry.domain}",
        f"Agent: {agent_obj.identity}",
        f"Created: {entry.created_at}",
    ]
    if entry.open:
        lines.append("Status: OPEN")
    if entry.decision_id:
        lines.append(f"Decision: {entry.decision_id[:8]}")
    if entry.archived_at:
        lines.append(f"Archived: {entry.archived_at}")

    lines.append(f"\n{entry.content}")

    if thread:
        author_ids = list({r.author_id for r in thread})
        author_map = agents.batch_get(author_ids)
        lines.append(f"\n--- {len(thread)} replies ---")
        for r in thread:
            author = author_map.get(r.author_id)
            ts = ago(r.created_at)
            name = agent_name(author, r.author_id[:8])
            lines.append(f"  [{ts}] {name}: {r.content}")

    output.echo_text("\n".join(lines), cli_ctx)


@space_command(app, "reply to insight", injected=True, name="reply")
@requires("agent", "project?")
def reply_cmd(
    cli_ctx: typer.Context,
    agent: Agent,
    project: Project | None,
    insight_id: str = typer.Argument(..., help="Insight ID to reply to"),
    content: str = typer.Argument(..., help="Reply content"),
):
    """Reply to an insight."""
    try:
        entry = store.resolve(insight_id, "insights", Insight)
    except NotFoundError:
        output.echo_text(f"Not found: {insight_id}", cli_ctx)
        raise typer.Exit(1) from None

    _, invalid_mentions = replies.validate_mentions(content)
    if invalid_mentions:
        typer.echo(f"WARNING: unknown @mention(s): {', '.join(invalid_mentions)}", err=True)

    spawn_id = SpawnId(sid) if (sid := paths.spawn_id()) else None
    reply_entry = replies.create(
        parent_id=entry.id,
        author_id=agent.id,
        content=content,
        spawn_id=spawn_id,
        project_id=project.id if project else None,
    )

    if output.echo_json(asdict(reply_entry), cli_ctx):
        return

    output.echo_text(f"Reply {reply_entry.id[:8]} on insight/{entry.id[:8]}", cli_ctx)


@space_command(app, "archive insight", injected=True, name="archive")
@requires("agent")
def archive(
    cli_ctx: typer.Context,
    agent: Agent,
    insight_id: str = typer.Argument(..., help="Insight ID to archive"),
    restore: bool = typer.Option(False, "--restore", help="Restore archived entry"),
):
    """Archive or restore an insight."""
    try:
        entry = store.resolve(insight_id, "insights", Insight)
    except NotFoundError:
        output.echo_text(f"Not found: {insight_id}", cli_ctx)
        raise typer.Exit(1) from None

    insights.archive(entry.id, restore=restore)
    action = "Restored" if restore else "Archived"
    output.respond(cli_ctx, {"id": entry.id, "archived": not restore}, f"{action} {insight_id[:8]}")


@space_command(app, "delete insight", injected=True, name="rm", aliases=["delete"])
@requires("agent")
def rm(
    cli_ctx: typer.Context,
    agent: Agent,
    insight_id: str = typer.Argument(..., help="Insight ID to delete"),
):
    """Delete an insight."""
    try:
        entry = store.resolve(insight_id, "insights", Insight)
    except NotFoundError:
        output.echo_text(f"Not found: {insight_id}", cli_ctx)
        raise typer.Exit(1) from None

    insights.delete(entry.id)
    output.respond(cli_ctx, {"deleted": entry.id}, f"Deleted {insight_id[:8]}")


@space_command(app, "close open insight", injected=True, name="close")
@requires("agent", "project?")
def close(
    cli_ctx: typer.Context,
    agent: Agent,
    project: Project | None,
    insight_id: str = typer.Argument(..., help="Insight ID to close"),
    resolution: str = typer.Argument(..., help="Resolution/answer"),
    solo: bool = typer.Option(
        None,
        "--solo/--swarm",
        help="Could single agent have found this? (--solo=yes, --swarm=no)",
    ),
):
    """Close an open insight with resolution (creates reply)."""
    try:
        entry = store.resolve(insight_id, "insights", Insight)
    except NotFoundError:
        output.echo_text(f"Not found: {insight_id}", cli_ctx)
        raise typer.Exit(1) from None

    if not entry.open:
        output.echo_text(f"Insight {insight_id[:8]} is not open", cli_ctx)
        raise typer.Exit(1)

    _, invalid_mentions = replies.validate_mentions(resolution)
    if invalid_mentions:
        typer.echo(f"WARNING: unknown @mention(s): {', '.join(invalid_mentions)}", err=True)

    spawn_id = SpawnId(sid) if (sid := paths.spawn_id()) else None
    replies.create(
        parent_id=entry.id,
        author_id=agent.id,
        content=resolution,
        spawn_id=spawn_id,
        project_id=project.id if project else None,
    )
    insights.close(entry.id, counterfactual=solo)
    output.respond(cli_ctx, {"id": entry.id, "open": False}, f"Closed {insight_id[:8]}")


def main() -> None:
    app()
