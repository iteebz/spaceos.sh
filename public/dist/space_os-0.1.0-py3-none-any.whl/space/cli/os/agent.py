import difflib

import typer
from click import get_current_context
from click.core import ParameterSource

from space import ctx
from space.cli.utils import output
from space.cli.utils.decorators import cli_entrypoint, requires
from space.core.errors import NotFoundError
from space.core.models import Agent
from space.core.types import UNSET
from space.lib import providers, store
from space.lib.commands import space_app, space_command
from space.lib.format import ago
from space.os import agents

app = space_app("agent", purpose="identity registry", injected=True, role="agents")


@app.callback()
def main_callback(cli_ctx: typer.Context):
    if cli_ctx.resilient_parsing:
        return
    if cli_ctx.invoked_subcommand is None:
        typer.echo(cli_ctx.get_help())


@space_command(app, "list available agents", injected=True, name="list", aliases=["ls"])
def list_agents(
    cli_ctx: typer.Context,
    include_archived: bool = typer.Option(False, "--archived", "-a", help="Include archived"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """List registered agents (AI only, use 'agent humans' for humans)."""
    output.init_context(cli_ctx, json_output=json_output)
    agent_list = agents.fetch(type="ai", include_archived=include_archived)

    if not agent_list:
        if json_output:
            output.echo_json([], cli_ctx)
        else:
            output.echo_text("No agents found.", cli_ctx)
        return

    last_active_map = agents.batch_last_active([a.id for a in agent_list])
    agents_data = [
        {
            "identity": a.identity,
            "agent_id": a.id,
            "type": a.type,
            "constitution": a.constitution,
            "model": a.model,
            "last_active": last_active_map.get(a.id),
        }
        for a in agent_list
    ]

    agents_data.sort(key=lambda d: d["last_active"] or "", reverse=True)

    if json_output:
        output.echo_json(agents_data, cli_ctx)
    else:
        lines = [
            f"{'identity':<16} {'constitution':<16} {'model':<24} {'active'}",
            "-" * 64,
        ]
        lines.extend(
            f"{d['identity'] or '-':<16} {d['constitution'] or '-':<16} {d['model'] or '-':<24} {ago(d['last_active'])}"
            for d in agents_data
        )
        output.echo_text("\n".join(lines), cli_ctx)


@space_command(app, "list human agents", injected=True, name="humans")
def list_humans(
    cli_ctx: typer.Context,
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """List human agents."""
    output.init_context(cli_ctx, json_output=json_output)
    agent_list = agents.fetch(type="human")

    if not agent_list:
        if json_output:
            output.echo_json([], cli_ctx)
        else:
            output.echo_text("No humans found.", cli_ctx)
        return

    last_active_map = agents.batch_last_active([a.id for a in agent_list])
    agents_data = [
        {"identity": a.identity, "agent_id": a.id, "last_active": last_active_map.get(a.id)}
        for a in agent_list
    ]
    agents_data.sort(key=lambda d: d["last_active"] or "", reverse=True)

    if json_output:
        output.echo_json(agents_data, cli_ctx)
    else:
        lines = [f"{'identity':<20} {'active'}", "-" * 28]
        lines.extend(f"{d['identity'] or '-':<20} {ago(d['last_active'])}" for d in agents_data)
        output.echo_text("\n".join(lines), cli_ctx)


@space_command(app, "view constitution", name="info", aliases=["show", "get"])
def info(cli_ctx: typer.Context, identity: str):
    """View agent constitution."""
    try:
        agent = store.resolve(identity, "agents", Agent)
    except NotFoundError:
        typer.echo(f"Agent not found: {identity}", err=True)
        raise typer.Exit(1) from None

    if not agent.constitution:
        typer.echo(f"{agent.identity} has no constitution", err=True)
        raise typer.Exit(1)

    const_path = ctx.constitution_path(agent.constitution)
    if not const_path.exists():
        typer.echo(f"Constitution file not found: {const_path}", err=True)
        raise typer.Exit(1)

    output.echo_text(const_path.read_text().strip(), cli_ctx)


@space_command(app, "register agent", name="create", aliases=["add", "new"])
def create(
    cli_ctx: typer.Context,
    identity: str,
    model: str | None = typer.Option(
        None, "--model", "-m", help="Model ID. Run 'agent models' to list available models"
    ),
    constitution: str | None = typer.Option(
        None, "--constitution", "-c", help="Constitution filename (e.g., zealot.md) - optional"
    ),
):
    """Register a new agent."""
    try:
        agent_type = "ai" if model else "human"
        agent = agents.create(
            identity,
            type=agent_type,
            model=model,
            constitution=constitution,
        )
        output.echo_text(f"✓ Registered {identity} ({agent.id[:8]})", cli_ctx)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


@space_command(app, "modify agent", name="update", aliases=["edit", "modify"])
def update(
    cli_ctx: typer.Context,
    identity: str,
    model: str | None = typer.Option(None, "--model", "-m", help="Full model name"),
    constitution: str | None = typer.Option(
        None, "--constitution", "-c", help="Constitution filename"
    ),
    clear_model: bool = typer.Option(False, "--clear-model", help="Clear stored model"),
    clear_constitution: bool = typer.Option(
        False, "--clear-constitution", help="Clear stored constitution"
    ),
):
    """Modify agent fields (constitution, model)."""
    try:
        agent = store.resolve(identity, "agents", Agent)

        ctx_obj = get_current_context(silent=True)
        sources = {}
        if ctx_obj:
            for param in ctx_obj.command.params:
                if param.name:
                    sources[param.name] = ctx_obj.get_parameter_source(param.name)

        if clear_model and sources.get("model") not in (None, ParameterSource.DEFAULT):
            raise ValueError("Use either --model or --clear-model, not both")
        if clear_constitution and sources.get("constitution") not in (
            None,
            ParameterSource.DEFAULT,
        ):
            raise ValueError("Use either --constitution or --clear-constitution, not both")

        model_update = (
            None
            if clear_model
            else (model if sources.get("model") != ParameterSource.DEFAULT else UNSET)
        )
        constitution_update = (
            None
            if clear_constitution
            else (constitution if sources.get("constitution") != ParameterSource.DEFAULT else UNSET)
        )

        agents.update(
            agent.id,
            constitution=constitution_update,
            model=model_update,
        )
        output.echo_text(f"✓ Updated {identity}", cli_ctx)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


@space_command(app, "change identity", name="rename")
def rename(cli_ctx: typer.Context, old_ref: str, new_name: str):
    try:
        agent = store.resolve(old_ref, "agents", Agent)
        agents.rename(agent.id, new_name)
        output.echo_text(f"✓ Renamed {old_ref} → {new_name}", cli_ctx)
    except NotFoundError:
        typer.echo(f"Agent not found: {old_ref}", err=True)
        raise typer.Exit(1) from None
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


@space_command(app, "merge agents", name="merge")
@requires("agent")
def merge(
    cli_ctx: typer.Context,
    agent: Agent,
    id_from: str = typer.Argument(..., help="Source agent to delete"),
    id_to: str = typer.Argument(..., help="Target agent to absorb data"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt"),
):
    """Soft-delete source agent with pointer to target. Data keeps original attribution."""
    try:
        agent_from = store.resolve(id_from, "agents", Agent)
    except NotFoundError:
        output.echo_text(f"Error: Agent '{id_from}' not found", cli_ctx)
        raise typer.Exit(1) from None

    try:
        agent_to = store.resolve(id_to, "agents", Agent)
    except NotFoundError:
        output.echo_text(f"Error: Agent '{id_to}' not found", cli_ctx)
        raise typer.Exit(1) from None

    from_display = agent_from.identity or id_from[:8]
    to_display = agent_to.identity or id_to[:8]

    if not force:
        typer.echo(
            f"\n⚠️  Merge {from_display} → {to_display}\n"
            f"   Source agent will be archived with merged_into pointer. Irreversible.\n"
        )
        if not typer.confirm("Continue?"):
            typer.echo("Aborted.")
            raise typer.Exit(0)

    result = agents.merge(agent_from.id, agent_to.id, agent.id)

    if not result:
        output.echo_text("Error: Could not merge agents", cli_ctx)
        raise typer.Exit(1)

    output.echo_text(f"✓ Merged {from_display} → {to_display}", cli_ctx)


@space_command(app, "archive agent", name="archive")
def archive(
    cli_ctx: typer.Context,
    identities: list[str],
    restore: bool = typer.Option(False, "--restore", help="Restore instead of archive"),
):
    """Archive or restore agents."""

    for identity in identities:
        try:
            agent = store.resolve(identity, "agents", Agent)
        except NotFoundError:
            typer.echo(f"Agent not found: {identity}", err=True)
            continue

        if restore:
            agents.unarchive(agent.id)
            output.echo_text(f"Restored {identity}", cli_ctx)
        else:
            agents.archive(agent.id)
            output.echo_text(f"Archived {identity}", cli_ctx)


@space_command(app, "register default agents", name="ensure")
def ensure(cli_ctx: typer.Context):
    """Register all agents from constitutions directory with default model."""
    registered, skipped = agents.defaults.ensure()
    if registered:
        output.echo_text(f"Registered: {', '.join(registered)}", cli_ctx)
    if skipped:
        output.echo_text(f"Already exist: {', '.join(skipped)}", cli_ctx)
    if not registered and not skipped:
        output.echo_text("No constitutions found.", cli_ctx)


@space_command(app, "list LLM models", name="models")
def models(cli_ctx: typer.Context):
    first = True
    for prov in providers.PROVIDER_NAMES:
        provider_models = providers.MODELS.get(prov, [])
        if not provider_models:
            continue

        if not first:
            output.echo_text("", cli_ctx)
        first = False

        if prov == "claude":
            header = "Claude Code"
        elif prov == "codex":
            header = "Codex CLI"
        elif prov == "gemini":
            header = "Gemini CLI"
        else:
            header = prov.capitalize()

        output.echo_text(f"{header}:", cli_ctx)
        for model in provider_models:
            mid = model["id"]
            desc = model.get("description") or ""
            output.echo_text(f"  - {mid:<22} {desc}", cli_ctx)

    if not first:
        output.echo_text(
            "\nNote: Codex reasoning effort configured in ~/.codex/config.toml\n", cli_ctx
        )


@space_command(app, "preview agent prompt/constitution", name="prompt")
def prompt_cmd(
    cli_ctx: typer.Context,
    identity: str = typer.Argument(..., help="Agent identity"),
    diff_with: str | None = typer.Option(None, "--diff", "-d", help="Compare with another agent"),
):
    """Preview agent's CLAUDE.md content (constitution + context)."""
    preview1 = ctx.preview(identity)

    if diff_with:
        preview2 = ctx.preview(diff_with)
        diff = difflib.unified_diff(
            preview1.splitlines(keepends=True),
            preview2.splitlines(keepends=True),
            fromfile=identity,
            tofile=diff_with,
        )
        typer.echo("".join(diff))
    else:
        typer.echo(preview1)


@cli_entrypoint
def main():
    """Entry point for agents command."""
    app()


if __name__ == "__main__":
    main()
