from dataclasses import asdict

import typer

from space.cli.utils import output
from space.cli.utils.decorators import requires
from space.core.errors import NotFoundError, ValidationError
from space.core.models import Agent, Decision, DecisionStatus, Project
from space.core.types import SpawnId
from space.lib import paths, store
from space.lib.commands import space_app, space_command
from space.lib.format import agent_name, ago
from space.os import agents, decisions, insights, projects, replies, tasks

DEFAULT_LIST_LIMIT = 20

app = space_app(
    "decision", purpose="immutable commitments with rationale", injected=True, role="agents"
)


@space_command(
    app, "record commitment", injected=True, name="add", aliases=["emit", "create", "record", "log"]
)
@requires("agent", "project")
def emit(
    cli_ctx: typer.Context,
    agent: Agent,
    project: Project,
    content: str = typer.Argument(..., help="What was decided"),
    why: str = typer.Option(..., "--why", "-w", help="Why this decision was made"),
    expected_outcome: str = typer.Option(None, "--expected", "-e", help="Predicted outcome"),
):
    """Emit a decision."""
    try:
        decision = decisions.create(
            project.id,
            agent.id,
            content,
            why,
            spawn_id=SpawnId(sid) if (sid := paths.spawn_id()) else None,
            expected_outcome=expected_outcome,
        )
    except ValidationError as e:
        output.echo_text(str(e), cli_ctx)
        raise typer.Exit(1) from None

    if output.echo_json(asdict(decision), cli_ctx):
        return

    lines = [
        f"Decision {decision.id[:8]} by {agent.identity}",
        f"  {decision.content}",
        f"  → {decision.rationale}",
    ]
    output.echo_text("\n".join(lines), cli_ctx)


@space_command(app, "list decisions", injected=True, name="list", aliases=["ls"])
@requires("project?")
def list_decisions(
    cli_ctx: typer.Context,
    project: Project | None,
    limit: int = typer.Option(DEFAULT_LIST_LIMIT, "--limit", "-n", help="Limit results"),
    as_agent: str = typer.Option(None, "--as", help="Filter by agent identity"),
    proposed: bool = typer.Option(False, "--proposed", help="Only PROPOSED (not yet committed)"),
    committed: bool = typer.Option(False, "--committed", help="Only COMMITTED (not actioned)"),
    actioned: bool = typer.Option(False, "--actioned", help="Only ACTIONED (no learnings)"),
    learned: bool = typer.Option(False, "--learned", help="Only LEARNED (has learnings)"),
    rejected: bool = typer.Option(False, "--rejected", help="Only REJECTED"),
):
    """List decisions."""
    agent_id = store.resolve(as_agent, "agents", Agent).id if as_agent else None
    project_id = project.id if project else None

    status_filter = None
    if proposed:
        status_filter = "proposed"
    elif committed:
        status_filter = "committed"
    elif actioned:
        status_filter = "actioned"
    elif learned:
        status_filter = "learned"
    elif rejected:
        status_filter = "rejected"

    if status_filter:
        entries = decisions.fetch_by_status(status_filter, project_id=project_id, limit=limit)
        if agent_id:
            entries = [e for e in entries if e.agent_id == agent_id]
    else:
        entries = decisions.fetch(
            agent_id=agent_id,
            limit=limit,
            project_id=project_id,
        )

    if not entries:
        if output.is_json_mode(cli_ctx):
            output.echo_json([], cli_ctx)
        else:
            output.echo_text("No decisions found.", cli_ctx)
        return

    if output.echo_json([asdict(e) for e in entries], cli_ctx):
        return

    insights_by_decision = insights.fetch_by_decision_ids([e.id for e in entries])
    lines = []
    for e in entries:
        ts = ago(e.created_at)
        status = decisions.get_status(e, insights_by_decision.get(e.id, []))
        if status == DecisionStatus.COMMITTED:
            state = " [@human]" if decisions.is_human_blocked(e) else " [swarm]"
        elif status != DecisionStatus.LEARNED:
            state = f" [{status.value}]"
        else:
            state = ""
        lines.append(f"[{ts}] ({e.id[:8]}) {e.content}{state}")
        if e.rationale:
            lines.append(f"  → {e.rationale}")
    output.echo_text("\n".join(lines), cli_ctx)


@space_command(app, "show decision", injected=True, name="show", aliases=["get"])
def show(
    cli_ctx: typer.Context,
    decision_id: str = typer.Argument(..., help="Decision ID"),
):
    """Show decision with tasks and reply thread."""
    try:
        entry = store.resolve(decision_id, "decisions", Decision)
    except NotFoundError:
        output.echo_text(f"Not found: {decision_id}", cli_ctx)
        raise typer.Exit(1) from None

    task_list = tasks.fetch(decision_id=entry.id, include_done=True)
    thread = replies.fetch_for_parent("decision", entry.id)
    linked = insights.fetch(decision_id=entry.id)

    if output.echo_json(
        {
            "decision": asdict(entry),
            "tasks": [asdict(t) for t in task_list],
            "replies": [asdict(r) for r in thread],
        },
        cli_ctx,
    ):
        return

    agent_obj = agents.get(entry.agent_id)
    project_obj = projects.try_get(entry.project_id)
    project_name = project_obj.name if project_obj else f"(deleted:{entry.project_id[:8]})"

    status = decisions.get_status(entry, linked)
    if status == DecisionStatus.COMMITTED and decisions.is_human_blocked(entry):
        state = "@HUMAN"
    else:
        state = status.value.upper()

    lines = [
        f"ID: {entry.id}",
        f"Project: {project_name}",
        f"Status: {state}",
        f"Created: {entry.created_at}",
    ]
    if entry.committed_at:
        lines.append(f"Committed: {entry.committed_at}")
    if entry.actioned_at:
        lines.append(f"Actioned: {entry.actioned_at}")
    if entry.reversible is not None:
        lines.append(f"Reversible: {'yes' if entry.reversible else 'no'}")
    lines.extend(
        [
            f"By: {agent_obj.identity}",
            f"\n{entry.content}",
            f"\nWhy: {entry.rationale}",
        ]
    )
    if entry.expected_outcome:
        lines.append(f"\nExpected: {entry.expected_outcome}")
    if entry.outcome:
        lines.append(f"\nActual: {entry.outcome}")

    qualifying = [i for i in linked if entry.actioned_at and i.created_at > entry.actioned_at]
    if qualifying:
        lines.append("\nLearnings:")
        lines.extend(f"  - [{i.id[:8]}] {i.content}" for i in qualifying)

    if task_list:
        assignee_ids = [t.assignee_id for t in task_list if t.assignee_id]
        assignee_map = agents.batch_get(assignee_ids)
        lines.append(f"\n--- {len(task_list)} tasks ---")
        for t in task_list:
            assignee = assignee_map.get(t.assignee_id) if t.assignee_id else None
            name = assignee.identity if assignee else "unassigned"
            lines.append(f"  [{t.status.value}] {t.content} ({name})")

    if thread:
        author_ids = list({r.author_id for r in thread})
        author_map = agents.batch_get(author_ids)
        lines.append(f"\n--- {len(thread)} replies ---")
        for r in thread:
            author = author_map.get(r.author_id)
            ts = ago(r.created_at)
            name = agent_name(author, r.author_id[:8])
            lines.append(f"  [{ts}] {name}: {r.content}")

    output.echo_text("\n".join(lines), cli_ctx)


@space_command(app, "reply to decision", injected=True, name="reply")
@requires("agent", "project?")
def reply(
    cli_ctx: typer.Context,
    agent: Agent,
    project: Project | None,
    decision_id: str = typer.Argument(..., help="Decision ID to reply to"),
    content: str = typer.Argument(..., help="Reply content"),
):
    """Reply to a decision."""
    try:
        entry = store.resolve(decision_id, "decisions", Decision)
    except NotFoundError:
        output.echo_text(f"Not found: {decision_id}", cli_ctx)
        raise typer.Exit(1) from None

    _, invalid_mentions = replies.validate_mentions(content)
    if invalid_mentions:
        typer.echo(f"WARNING: unknown @mention(s): {', '.join(invalid_mentions)}", err=True)

    spawn_id = SpawnId(sid) if (sid := paths.spawn_id()) else None
    reply_entry = replies.create(
        parent_id=entry.id,
        author_id=agent.id,
        content=content,
        spawn_id=spawn_id,
        project_id=project.id if project else None,
    )

    if output.echo_json(asdict(reply_entry), cli_ctx):
        return

    output.echo_text(f"Reply {reply_entry.id[:8]} on decision/{entry.id[:8]}", cli_ctx)


@space_command(app, "delete decision", injected=True, name="rm", aliases=["delete"])
@requires("agent")
def delete(
    cli_ctx: typer.Context,
    agent: Agent,
    decision_id: str = typer.Argument(..., help="Decision ID to delete"),
):
    """Soft delete a decision."""
    try:
        entry = store.resolve(decision_id, "decisions", Decision)
        decisions.delete(entry.id)
    except NotFoundError:
        output.echo_text(f"Not found: {decision_id}", cli_ctx)
        raise typer.Exit(1) from None

    output.respond(
        cli_ctx,
        {"decision_id": decision_id, "deleted": True},
        f"Deleted {decision_id[:8]}",
    )


@space_command(app, "archive decision", name="archive")
@requires("agent")
def archive_cmd(
    cli_ctx: typer.Context,
    agent: Agent,
    decision_id: str = typer.Argument(..., help="Decision ID to archive"),
):
    """Archive a decision. Hidden from lists, still searchable."""
    try:
        entry = store.resolve(decision_id, "decisions", Decision)
        decision = decisions.archive(entry.id)
    except NotFoundError:
        output.echo_text(f"Not found: {decision_id}", cli_ctx)
        raise typer.Exit(1) from None

    output.respond(
        cli_ctx,
        asdict(decision),
        f"Archived {decision_id[:8]}",
    )


@space_command(app, "commit proposed decision", name="commit")
@requires("agent")
def commit_cmd(
    cli_ctx: typer.Context,
    agent: Agent,
    decision_id: str = typer.Argument(..., help="Decision ID"),
    at: str = typer.Option(None, "--at", help="Backfill timestamp (ISO format)"),
):
    """Commit a proposed decision. Makes it binding. One-shot, immutable."""
    try:
        entry = store.resolve(decision_id, "decisions", Decision)
        decision = decisions.commit(entry.id, at=at)
    except (NotFoundError, ValidationError) as e:
        output.echo_text(str(e), cli_ctx)
        raise typer.Exit(1) from None

    output.respond(
        cli_ctx,
        asdict(decision),
        f"Committed {decision_id[:8]} at {decision.committed_at}",
    )


@space_command(app, "mark decision actioned", name="action")
@requires("agent")
def action_cmd(
    cli_ctx: typer.Context,
    agent: Agent,
    decision_id: str = typer.Argument(..., help="Decision ID"),
    at: str = typer.Option(None, "--at", help="Backfill timestamp (ISO format)"),
    outcome: str = typer.Option(None, "--outcome", "-o", help="What actually happened"),
):
    """Mark decision as actioned (reality contact). One-shot, immutable."""
    try:
        entry = store.resolve(decision_id, "decisions", Decision)
        decision = decisions.action(entry.id, at=at, outcome=outcome)
    except (NotFoundError, ValidationError) as e:
        output.echo_text(str(e), cli_ctx)
        raise typer.Exit(1) from None

    output.respond(
        cli_ctx,
        asdict(decision),
        f"Actioned {decision_id[:8]} at {decision.actioned_at}",
    )


@space_command(app, "record learning from decision", name="learn")
@requires("agent", "project")
def learn_cmd(
    cli_ctx: typer.Context,
    agent: Agent,
    project: Project,
    decision_id: str = typer.Argument(..., help="Decision ID"),
    content: str = typer.Argument(..., help="What was learned (≤280 chars)"),
    domain: str = typer.Option("learning", "-d", "--domain", help="Insight domain"),
):
    """Record a learning from a decision. Creates linked insight. Requires actioned_at."""
    try:
        entry = store.resolve(decision_id, "decisions", Decision)
        if not entry.actioned_at:
            output.echo_text(
                f"Decision {decision_id[:8]} not yet actioned. Run 'decision action' first.",
                cli_ctx,
            )
            raise typer.Exit(1) from None

        insight = insights.create(
            project.id,
            agent.id,
            content,
            domain,
            spawn_id=SpawnId(sid) if (sid := paths.spawn_id()) else None,
            decision_id=entry.id,
        )
    except (NotFoundError, ValidationError) as e:
        output.echo_text(str(e), cli_ctx)
        raise typer.Exit(1) from None

    output.respond(
        cli_ctx,
        asdict(insight),
        f"Learned from {decision_id[:8]}: {content}",
    )


@space_command(app, "surface stale committed decisions", name="stale")
@requires("project?")
def stale_cmd(
    cli_ctx: typer.Context,
    project: Project | None,
    max_refs: int = typer.Option(2, "--max-refs", "-r", help="Max reference count threshold"),
    min_age: int = typer.Option(24, "--min-age", "-a", help="Min hours since committed"),
    limit: int = typer.Option(10, "--limit", "-n", help="Max results"),
):
    """Surface committed decisions with low reference counts (drift candidates)."""
    project_id = project.id if project else None
    entries = decisions.fetch_stale(
        project_id=project_id, max_refs=max_refs, min_age_hours=min_age, limit=limit
    )

    if not entries:
        output.respond(cli_ctx, [], "No stale committed decisions found.")
        return

    if output.echo_json([{**asdict(d), "refs": r} for d, r in entries], cli_ctx):
        return

    lines = ["Stale committed decisions (low references, may need review):"]
    for d, ref_count in entries:
        ts = ago(d.committed_at) if d.committed_at else "?"
        lines.append(f"  [{ts}] ({d.id[:8]}) {d.content[:60]}... [{ref_count} refs]")
    output.echo_text("\n".join(lines), cli_ctx)


@space_command(app, "mark decision reversible", name="reversible")
@requires("agent")
def reversible_cmd(
    cli_ctx: typer.Context,
    agent: Agent,
    decision_id: str = typer.Argument(..., help="Decision ID"),
    yes: bool = typer.Option(True, "--yes/--no", help="Is this decision reversible?"),
):
    """Mark whether a decision is reversible. Affects delegation threshold."""
    try:
        entry = store.resolve(decision_id, "decisions", Decision)
        decision = decisions.set_reversible(entry.id, yes)
    except (NotFoundError, ValidationError) as e:
        output.echo_text(str(e), cli_ctx)
        raise typer.Exit(1) from None

    status = "reversible" if yes else "irreversible"
    output.respond(
        cli_ctx,
        asdict(decision),
        f"Marked {decision_id[:8]} as {status}",
    )


@space_command(app, "reject decision", name="reject")
@requires("agent")
def reject_cmd(
    cli_ctx: typer.Context,
    agent: Agent,
    decision_id: str = typer.Argument(..., help="Decision ID"),
    reason: str = typer.Argument(..., help="Why this decision is being rejected"),
):
    """Reject a decision (explicitly not pursuing). Creates reply with reason."""
    try:
        entry = store.resolve(decision_id, "decisions", Decision)
        decision = decisions.reject(entry.id)
        replies.create(
            parent_id=entry.id,
            author_id=agent.id,
            content=f"Rejected: {reason}",
            spawn_id=SpawnId(sid) if (sid := paths.spawn_id()) else None,
        )
    except (NotFoundError, ValidationError) as e:
        output.echo_text(str(e), cli_ctx)
        raise typer.Exit(1) from None

    output.respond(
        cli_ctx,
        asdict(decision),
        f"Rejected {decision_id[:8]}: {reason}",
    )


@space_command(app, "show calibration data", name="calibration")
@requires("project?")
def calibration_cmd(
    cli_ctx: typer.Context,
    project: Project | None,
    limit: int = typer.Option(50, "--limit", "-n", help="Max results"),
):
    """Show decisions with reversibility judgments and outcomes for trust calibration."""
    project_id = project.id if project else None
    entries = decisions.fetch_calibration(project_id=project_id, limit=limit)

    if not entries:
        output.respond(cli_ctx, [], "No calibration data found.")
        return

    if output.echo_json([asdict(e) for e in entries], cli_ctx):
        return

    lines = ["Calibration data (reversibility judgment vs outcome):"]
    for e in entries:
        ts = ago(e.actioned_at) if e.actioned_at else "?"
        judgment = "reversible" if e.reversible else "irreversible"
        lines.append(f"  [{ts}] ({e.id[:8]}) {e.content[:50]}...")
        lines.append(f"    Judged: {judgment}")
        lines.append(f"    Outcome: {e.outcome}")
        if e.expected_outcome:
            lines.append(f"    Expected: {e.expected_outcome}")
    output.echo_text("\n".join(lines), cli_ctx)


def main() -> None:
    app()
