import contextlib
import sys
from dataclasses import asdict
from typing import Annotated

import typer

from space.cli.utils import output
from space.cli.utils.decorators import requires
from space.core.errors import NotFoundError, StateError, ValidationError
from space.core.models import Agent, Decision, Project, Task, TaskStatus
from space.core.types import SpawnId
from space.lib import identity as identity_lib
from space.lib import paths, store
from space.lib.commands import space_app, space_command
from space.lib.format import truncate
from space.os import agents, decisions, projects, replies, tasks

app = space_app("task", purpose="work items", injected=True, role="agents")


def _resolve_task(task_ref: str) -> Task:
    try:
        return store.resolve(task_ref, "tasks", Task)
    except NotFoundError:
        typer.echo(f"Task not found: {task_ref}", err=True)
        raise typer.Exit(1) from None


DEFAULT_LIST_LIMIT = 50


@space_command(app, "show project tasks", injected=True, name="list", aliases=["ls"])
@requires("project?", "decision?")
def list_tasks(
    cli_ctx: typer.Context,
    project: Project | None,
    decision: Decision | None,
    show_done: bool = typer.Option(False, "--done", help="Include terminal tasks"),
    as_agent: str = typer.Option(None, "--as", help="Filter by creator identity"),
    mine: bool = typer.Option(False, "--mine", "-m", help="Show only tasks assigned to you"),
    unassigned: bool = typer.Option(False, "--unassigned", "-u", help="Show only unassigned tasks"),
    limit: int = typer.Option(DEFAULT_LIST_LIMIT, "--limit", "-n", help="Limit results"),
):
    creator_id = store.resolve(as_agent, "agents", Agent).id if as_agent else None

    current_identity = identity_lib.current()
    agent_id = agents.get_by_identity(current_identity).id if current_identity else None

    task_list = tasks.fetch(
        decision_id=decision.id if decision else None,
        creator_id=creator_id,
        assignee_id=agent_id if mine else None,
        include_done=show_done,
        project_id=project.id if project else None,
        unassigned=unassigned,
        limit=limit,
    )

    if not task_list:
        output.echo_text("No tasks", cli_ctx)
        return

    output.echo_text(tasks.format_task_list(task_list, agent_id=agent_id), cli_ctx)


@space_command(app, "show task", injected=True, name="show", aliases=["get"])
def show(
    cli_ctx: typer.Context,
    task_id: str = typer.Argument(..., help="Task ID"),
):
    """Show task details with thread."""
    task = _resolve_task(task_id)
    project = projects.try_get(task.project_id)
    project_name = project.name if project else f"(deleted:{task.project_id[:8]})"
    creator = agents.get(task.creator_id)
    assignee = agents.get(task.assignee_id) if task.assignee_id else None

    task_replies = replies.fetch_for_parent("task", task.id)
    reply_author_ids = list({r.author_id for r in task_replies})
    reply_authors = agents.batch_get(reply_author_ids) if reply_author_ids else {}

    if output.echo_json(
        {"task": asdict(task), "replies": [asdict(r) for r in task_replies]}, cli_ctx
    ):
        return

    lines = [
        f"ID: {task.id}",
        f"Project: {project_name}",
        f"Status: {task.status.value.upper()}",
        f"Created: {task.created_at}",
        f"Creator: {creator.identity}",
    ]
    if assignee:
        lines.append(f"Assignee: {assignee.identity}")
    if task.started_at:
        lines.append(f"Started: {task.started_at}")
    if task.completed_at:
        lines.append(f"Completed: {task.completed_at}")

    lines.append(f"\n{task.content}")

    if task.result:
        lines.append(f"\nResult: {task.result}")

    if task.decision_id:
        decision = decisions.get(task.decision_id)
        lines.append(f"\n--- Parent Decision ({decision.id[:8]}) ---")
        lines.append(f"  {decision.content}")
        if decision.rationale:
            lines.append(f"  → {decision.rationale}")

    if task_replies:
        lines.append("\n--- Thread ---")
        for r in task_replies:
            author = reply_authors.get(r.author_id)
            author_name = author.identity if author else r.author_id[:8]
            lines.append(f"  [{author_name}] {r.content}")

    output.echo_text("\n".join(lines), cli_ctx)


@space_command(app, "create work item", injected=True, name="add", aliases=["create", "new"])
@requires("agent", "project", "decision?")
def create(
    cli_ctx: typer.Context,
    agent: Agent,
    project: Project,
    decision: Decision | None,
    contents: Annotated[
        list[str],
        typer.Argument(
            help="Task description(s). Pass '-' to read newline-separated tasks from stdin."
        ),
    ],
    done: bool = typer.Option(False, "--done", help="Mark immediately complete"),
    result: Annotated[str | None, typer.Option("--result", "-r", help="Completion notes")] = None,
):
    task_contents: list[str]
    if contents == ["-"]:
        stdin_lines = [line.strip() for line in sys.stdin.read().splitlines()]
        task_contents = [line for line in stdin_lines if line]
        if not task_contents:
            raise typer.BadParameter("No tasks provided on stdin")
    elif any(content == "-" for content in contents):
        raise typer.BadParameter("'-' can only be used as the sole CONTENT argument")
    else:
        task_contents = contents

    spawn_id = SpawnId(sid) if (sid := paths.spawn_id()) else None
    for content in task_contents:
        task = tasks.create(
            project.id,
            agent.id,
            content,
            spawn_id=spawn_id,
            decision_id=decision.id if decision else None,
            done=done,
            result=result,
        )
        output.echo_text(f"{'Done' if done else 'Added'}: {task.id[:8]}", cli_ctx)


@space_command(app, "assign to yourself", injected=True, aliases=["assign", "take"])
@requires("agent")
def claim(
    cli_ctx: typer.Context,
    agent: Agent,
    task_id: str = typer.Argument(..., help="Task ID to claim"),
):
    active = tasks.get_active(agent.id)
    if active:
        typer.echo(
            f"Already have active task: {active.id[:8]} - {truncate(active.content)}", err=True
        )
        raise typer.Exit(1)
    task = _resolve_task(task_id)
    tasks.set_status(task.id, TaskStatus.ACTIVE, agent_id=agent.id)
    output.echo_text(f"Claimed: {task_id[:8]}", cli_ctx)


@space_command(app, "create and claim task", injected=True, name="doing", aliases=["start"])
@requires("agent", "project", "decision?")
def doing(
    cli_ctx: typer.Context,
    agent: Agent,
    project: Project,
    decision: Decision | None,
    content: str = typer.Argument(..., help="What you're doing"),
):
    active = tasks.get_active(agent.id)
    if active:
        typer.echo(
            f"Already have active task: {active.id[:8]} - {truncate(active.content)}", err=True
        )
        typer.echo("Run `task done` or `task release` first.", err=True)
        raise typer.Exit(1)

    spawn_id = SpawnId(sid) if (sid := paths.spawn_id()) else None
    task = tasks.create(
        project.id,
        agent.id,
        content,
        spawn_id=spawn_id,
        assignee_id=agent.id,
        decision_id=decision.id if decision else None,
    )
    tasks.set_status(task.id, TaskStatus.ACTIVE, agent_id=agent.id)
    output.echo_text(f"Doing: ({task.id[:8]}) {content}", cli_ctx)


@space_command(app, "unclaim task", injected=True, name="release")
@requires("agent")
def release(
    cli_ctx: typer.Context,
    agent: Agent,
    task_id: str = typer.Argument(None, help="Task ID (defaults to your active task)"),
):
    if task_id:
        task = _resolve_task(task_id)
    else:
        task = tasks.get_active(agent.id)
        if not task:
            typer.echo("No active task to release", err=True)
            raise typer.Exit(1)
    tasks.set_status(task.id, TaskStatus.PENDING, agent_id=agent.id)
    output.echo_text(f"Released: {task.id[:8]}", cli_ctx)


@space_command(app, "switch focus", injected=True, name="switch")
@requires("agent", "project?", "decision?")
def switch(
    cli_ctx: typer.Context,
    agent: Agent,
    project: Project | None,
    decision: Decision | None,
    content: str = typer.Argument(..., help="Task ID or new focus"),
):
    existing = None
    if len(content) <= 36:
        with contextlib.suppress(NotFoundError):
            existing = store.resolve(content, "tasks", Task)
    if existing:
        old_task = tasks.get_active(agent.id)
        if old_task:
            tasks.set_status(old_task.id, TaskStatus.DONE, agent_id=agent.id)
            output.echo_text(f"Done: ({old_task.id[:8]}) {truncate(old_task.content)}", cli_ctx)
        tasks.set_status(existing.id, TaskStatus.ACTIVE, agent_id=agent.id)
        output.echo_text(f"Doing: ({existing.id[:8]}) {existing.content}", cli_ctx)
        return

    if not project:
        typer.echo("Project required when creating new task", err=True)
        raise typer.Exit(1)

    spawn_id = SpawnId(sid) if (sid := paths.spawn_id()) else None
    old_task, new_task = tasks.switch(
        agent.id,
        project.id,
        content,
        spawn_id=spawn_id,
        decision_id=decision.id if decision else None,
    )
    if old_task:
        output.echo_text(f"Done: ({old_task.id[:8]}) {old_task.content[:40]}", cli_ctx)
    output.echo_text(f"Doing: ({new_task.id[:8]}) {content}", cli_ctx)


@space_command(app, "mark complete", injected=True, aliases=["complete", "finish"])
@requires("agent")
def done(
    cli_ctx: typer.Context,
    agent: Agent,
    task_id: str = typer.Argument(None, help="Task ID (defaults to your active task)"),
    result: Annotated[str | None, typer.Option("--result", "-r", help="Completion notes")] = None,
):
    if task_id:
        task = _resolve_task(task_id)
    else:
        task = tasks.get_active(agent.id)
        if not task:
            typer.echo("No active task to complete", err=True)
            raise typer.Exit(1)
    if task.status == TaskStatus.PENDING:
        tasks.set_status(task.id, TaskStatus.ACTIVE, agent_id=agent.id)
    tasks.set_status(task.id, TaskStatus.DONE, agent_id=agent.id, result=result)
    output.echo_text(f"Done: {task.id[:8]}", cli_ctx)


@space_command(app, "cancel task", injected=True, name="cancel")
@requires("agent")
def cancel(
    cli_ctx: typer.Context,
    agent: Agent,
    task_id: str = typer.Argument(..., help="Task ID to cancel"),
    result: Annotated[
        str | None, typer.Option("--result", "-r", help="Cancellation reason")
    ] = None,
):
    task = _resolve_task(task_id)
    if task.status == TaskStatus.PENDING:
        tasks.set_status(task.id, TaskStatus.ACTIVE, agent_id=agent.id)
    tasks.set_status(task.id, TaskStatus.CANCELLED, agent_id=agent.id, result=result)
    output.echo_text(f"Cancelled: {task_id[:8]}", cli_ctx)


@space_command(app, "update task content", injected=True, name="edit", aliases=["update", "modify"])
def edit(
    cli_ctx: typer.Context,
    task_id: str = typer.Argument(..., help="Task ID to edit"),
    content: str = typer.Argument(..., help="New task content"),
):
    task = _resolve_task(task_id)
    tasks.update_content(task.id, content)
    output.echo_text(f"Updated: {task_id[:8]}", cli_ctx)


@space_command(app, "release with context", injected=True, name="handoff")
@requires("agent", "project?")
def handoff(
    cli_ctx: typer.Context,
    agent: Agent,
    project: Project | None,
    context: str = typer.Argument(..., help="Context for next agent"),
    task_id: str = typer.Argument(None, help="Task ID (defaults to your active task)"),
):
    if task_id:
        task = _resolve_task(task_id)
    else:
        task = tasks.get_active(agent.id)
        if not task:
            typer.echo("No active task to hand off", err=True)
            raise typer.Exit(1)
    spawn_id = SpawnId(sid) if (sid := paths.spawn_id()) else None
    replies.create(
        task.id,
        agent.id,
        context,
        spawn_id=spawn_id,
        project_id=project.id if project else None,
    )
    tasks.set_status(task.id, TaskStatus.PENDING, agent_id=agent.id)
    output.echo_text(f"Handed off: {task.id[:8]} with context", cli_ctx)


@space_command(app, "reply to task", injected=True, name="reply")
@requires("agent", "project?")
def reply(
    cli_ctx: typer.Context,
    agent: Agent,
    project: Project | None,
    task_id: str = typer.Argument(..., help="Task ID to reply to"),
    content: str = typer.Argument(..., help="Reply content"),
):
    task = _resolve_task(task_id)

    _, invalid_mentions = replies.validate_mentions(content)
    if invalid_mentions:
        typer.echo(f"WARNING: unknown @mention(s): {', '.join(invalid_mentions)}", err=True)

    spawn_id = SpawnId(sid) if (sid := paths.spawn_id()) else None
    reply_entry = replies.create(
        task.id,
        agent.id,
        content,
        spawn_id=spawn_id,
        project_id=project.id if project else None,
    )
    output.echo_text(f"Reply {reply_entry.id[:8]} added to task {task.id[:8]}", cli_ctx)


@space_command(app, "unassigned tasks", injected=True, name="backlog")
@requires("project?")
def backlog(
    cli_ctx: typer.Context,
    project: Project | None,
    show_done: bool = typer.Option(False, "--done", help="Include terminal tasks"),
):
    task_list = tasks.fetch(
        unassigned=True, include_done=show_done, project_id=project.id if project else None
    )

    if not task_list:
        output.echo_text("No unassigned tasks", cli_ctx)
        return

    output.echo_text(tasks.format_task_list(task_list), cli_ctx)


def main() -> None:
    try:
        app()
    except SystemExit:
        raise
    except (NotFoundError, StateError, ValidationError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise SystemExit(1) from e
