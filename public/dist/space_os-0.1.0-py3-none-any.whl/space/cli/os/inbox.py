from dataclasses import asdict
from typing import Any

import typer

from space.cli.utils import output
from space.cli.utils.decorators import requires
from space.core.models import Agent
from space.lib.commands import space_app
from space.lib.format import agent_name, ago
from space.os import agents, insights, replies

app = space_app("inbox", purpose="unresolved @mentions", injected=True, role="agents")
app.info.no_args_is_help = False


@app.callback(invoke_without_command=True)
@requires("agent")
def default(
    cli_ctx: typer.Context,
    agent: Agent,
):
    """Show unresolved @mentions for agent."""
    if cli_ctx.invoked_subcommand is not None:
        return

    reply_entries = replies.inbox(agent.identity)
    insight_entries = insights.inbox(agent.identity)

    if not reply_entries and not insight_entries:
        if output.is_json_mode(cli_ctx):
            output.echo_json([], cli_ctx)
        else:
            output.echo_text("No unresolved mentions.", cli_ctx)
        return

    all_json: list[dict[str, Any]] = []
    all_json.extend({"type": "reply", **asdict(e)} for e in reply_entries)
    all_json.extend({"type": "insight", **asdict(e)} for e in insight_entries)
    if output.echo_json(all_json, cli_ctx):
        return

    lines = []

    if insight_entries:
        insight_author_ids = list({e.agent_id for e in insight_entries})
        insight_author_map = agents.batch_get(insight_author_ids)
        for e in insight_entries:
            author = insight_author_map.get(e.agent_id)
            ts = ago(e.created_at)
            name = agent_name(author, e.agent_id[:8])
            lines.append(f"[{ts}] {name} on insight/{e.id[:8]}")
            lines.append(f"  {e.content}")
            lines.append("")

    if reply_entries:
        reply_author_ids = list({e.author_id for e in reply_entries})
        reply_author_map = agents.batch_get(reply_author_ids)
        for e in reply_entries:
            author = reply_author_map.get(e.author_id)
            ts = ago(e.created_at)
            name = agent_name(author, e.author_id[:8])
            lines.append(f"[{ts}] {name} on {e.parent_type}/{e.parent_id[:8]}")
            lines.append(f"  {e.content}")
            lines.append("")

    output.echo_text("\n".join(lines).rstrip(), cli_ctx)


def main() -> None:
    app()
