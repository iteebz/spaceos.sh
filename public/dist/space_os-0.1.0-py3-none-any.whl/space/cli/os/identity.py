import typer

from space.core.errors import ConflictError, NotFoundError
from space.core.models import Agent
from space.lib import store
from space.os import agents

app = typer.Typer()


@app.command(name="set")
def set(name: str = typer.Argument(..., help="Your identity name")):
    """Set your human identity."""
    if " " in name:
        typer.echo("Identity cannot contain spaces. Use hyphens instead.", err=True)
        raise typer.Exit(1)

    try:
        existing = store.resolve(name, "agents", Agent)
        if existing.model:
            typer.echo(
                f"Identity '{name}' already registered as agent. Choose different name.", err=True
            )
            raise typer.Exit(1)
    except (NotFoundError, ValueError):
        pass

    try:
        human_agent = store.resolve("human", "agents", Agent)
    except (NotFoundError, ValueError):
        typer.echo(
            "No human identity found. Register yourself: agents register <name> [--model <model>].",
            err=True,
        )
        raise typer.Exit(1) from None

    if name == "human":
        typer.echo("Already set to: human")
        return

    try:
        agents.rename(human_agent.id, name)
        typer.echo(f"Identity set to: {name}")
    except ConflictError as e:
        typer.echo(f"Failed to set identity: {e}", err=True)
        raise typer.Exit(1) from None


@app.command(name="get")
def get():
    """Show your current identity."""
    humans = agents.fetch(type="human")
    if humans:
        typer.echo(humans[0].identity)
    else:
        typer.echo(
            "No human identity found. Register yourself: agents register <name> [--model <model>].",
            err=True,
        )
        raise typer.Exit(1)
