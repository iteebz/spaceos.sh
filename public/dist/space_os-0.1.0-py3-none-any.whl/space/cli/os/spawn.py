import contextlib
import json
from datetime import UTC, datetime
from typing import Any

import typer

from space.cli.utils import output
from space.cli.utils.decorators import requires
from space.core.errors import NotFoundError, StateError
from space.core.models import Agent, Project, Spawn, SpawnSource, SpawnStatus
from space.core.types import AgentId
from space.lib import format, hooks, store
from space.lib.commands import space_app, space_command
from space.lib.format import truncate
from space.os import agents, decisions, insights, projects, spawns, tasks

app = space_app("spawn", purpose="execution lifecycle", injected=False, role="humans")
app.info.no_args_is_help = False


def _spawn_table(
    spawn_list: list[Spawn],
    agent_map: dict[AgentId, Any],
    show_summary: bool = False,
) -> list[str]:
    lines = [
        f"{'ID':<8} {'Identity':<20} {'Status':<12} {'Created':<8}",
        "-" * 52,
    ]
    for s in spawn_list:
        created = format.ago(s.created_at)
        agent = agent_map.get(s.agent_id)
        identity = agent.identity if agent else s.agent_id[:8]
        lines.append(f"{s.id[:8]:<8} {identity:<20} {s.status.value:<12} {created:<8}")
        if show_summary and s.summary:
            lines.append(f"  {truncate(s.summary)}")
    return lines


def _resolve_agent_and_project(identity: str) -> tuple[Agent, Project]:
    agent = store.resolve(identity, "agents", Agent)
    if not agent.model:
        typer.echo(f"Agent {identity} has no model configured", err=True)
        raise typer.Exit(1)

    project = projects.infer_from_cwd()
    if not project:
        typer.echo("No project found in current directory", err=True)
        raise typer.Exit(1)

    return agent, project


@space_command(app, "list spawns", name="list", aliases=["ls"])
@requires("project?")
def list_spawns(
    cli_ctx: typer.Context,
    project: Project | None,
    active: bool = typer.Option(False, "--active", "-a", help="Only active spawns"),
    done: bool = typer.Option(False, "--done", "-d", help="Only completed spawns"),
    identity: str | None = typer.Option(None, "--identity", "-i", help="Filter by agent"),
    limit: int = typer.Option(20, "--limit", "-n", help="Max spawns to show"),
):
    """List recent spawns."""
    status_filter: list[str] | None = None
    if active and done:
        typer.echo("Cannot use both --active and --done", err=True)
        raise typer.Exit(1)
    if active:
        status_filter = ["active"]
    elif done:
        status_filter = ["done"]

    project_id = project.id if project else None
    agent = store.resolve(identity, "agents", Agent) if identity else None

    spawns_list = spawns.fetch(
        agent_id=agent.id if agent else None,
        status=status_filter,
        project_id=project_id,
        limit=limit,
    )

    if output.is_json_mode(cli_ctx):
        data = [{"id": s.id, "agent_id": s.agent_id, "status": s.status} for s in spawns_list]
        typer.echo(json.dumps(data))
        return

    if not spawns_list:
        output.echo_text("No spawns.", cli_ctx)
        return

    agent_ids = list({s.agent_id for s in spawns_list})
    agent_map = agents.batch_get(agent_ids)
    for line in _spawn_table(spawns_list, agent_map):
        output.echo_text(line, cli_ctx)


def _get_spawn_refs(spawn: Spawn) -> dict[str, list[dict[str, str]]]:
    refs: dict[str, list[dict[str, str]]] = {}

    task_list = tasks.fetch(spawn_ids=[spawn.id])
    if task_list:
        refs["tasks"] = [
            {"id": t.id[:8], "content": truncate(t.content), "status": t.status.value}
            for t in task_list
        ]

    insight_list = insights.fetch(spawn_id=spawn.id, include_archived=True)
    if insight_list:
        refs["insights"] = [
            {"id": i.id[:8], "content": truncate(i.content), "domain": i.domain}
            for i in insight_list
        ]

    decision_list = decisions.fetch(spawn_id=spawn.id)
    if decision_list:
        refs["decisions"] = [
            {"id": d.id[:8], "content": truncate(d.content)} for d in decision_list
        ]

    children = spawns.fetch(caller_ids=[spawn.id])
    if children:
        agent_ids = list({c.agent_id for c in children})
        agent_map = agents.batch_get(agent_ids)
        refs["children"] = [
            {
                "id": c.id[:8],
                "agent": agent_map.get(
                    c.agent_id, Agent(id=c.agent_id, identity=c.agent_id[:8])
                ).identity,
                "status": c.status.value,
            }
            for c in children
        ]

    return refs


def _usage_bar(pct: float, used: int, limit: int, width: int = 20) -> str:
    filled = int(pct / 100 * width)
    bar = "█" * filled + "░" * (width - filled)
    return f"[{bar}] {pct}% ({used:,}/{limit:,})"


@space_command(app, "show spawn details", name="show")
def show(
    cli_ctx: typer.Context,
    spawn_id: str,
    refs: bool = typer.Option(False, "--refs", "-r", help="Show related entities"),
    usage: bool = typer.Option(False, "--usage", "-u", help="Show context usage"),
):
    spawn = store.resolve(spawn_id, "spawns", Spawn)
    agent = agents.get(spawn.agent_id)
    trace_path = spawns.events_file_path(spawn.id)
    resumed = spawns.was_resumed(spawn.id)

    if output.is_json_mode(cli_ctx):
        data: dict[str, Any] = {
            "id": spawn.id,
            "agent": agent.identity,
            "status": spawn.status,
            "resumed": resumed,
            "summary": spawn.summary,
            "created_at": spawn.created_at,
            "trace": str(trace_path) if trace_path else None,
        }
        if refs:
            data["refs"] = _get_spawn_refs(spawn)
        if usage:
            data["usage"] = spawns.usage(spawn)
        typer.echo(json.dumps(data))
        return

    output.echo_text(f"{spawn.id[:8]} ({agent.identity})", cli_ctx)
    output.echo_text(f"Status: {spawn.status}", cli_ctx)
    if resumed is not None:
        output.echo_text(f"Resumed: {resumed}", cli_ctx)
    if spawn.summary:
        output.echo_text(f"Summary: {spawn.summary}", cli_ctx)
    if trace_path:
        output.echo_text(f"Trace: {trace_path}", cli_ctx)

    if usage:
        usage_data = spawns.usage(spawn)
        if usage_data:
            output.echo_text(
                f"Context: {_usage_bar(usage_data['percentage'], usage_data['context_used'], usage_data['context_limit'])}",
                cli_ctx,
            )

    if refs:
        spawn_refs = _get_spawn_refs(spawn)
        if spawn_refs:
            output.echo_text("", cli_ctx)
            output.echo_text("References:", cli_ctx)
            for ref_type, items in spawn_refs.items():
                output.echo_text(f"  {ref_type}:", cli_ctx)
                for item in items:
                    if ref_type == "children":
                        output.echo_text(
                            f"    [{item['id']}] {item['agent']} ({item['status']})", cli_ctx
                        )
                    else:
                        output.echo_text(f"    [{item['id']}] {item['content']}", cli_ctx)


def _format_log_entry(e: spawns.LogEntry) -> list[str]:
    start_time = e.created_at[11:16] if e.created_at else "?"
    end_time = e.last_active_at[11:16] if e.last_active_at else "?"
    duration = format.format_duration(e.duration_seconds) if e.duration_seconds else "?"

    lines = [
        f"{e.id} {e.agent_identity} [{e.source}] {start_time}->{end_time} ({duration}) {e.status}"
    ]

    if e.summary:
        lines.append(f'  "{e.summary}"')

    if e.error:
        lines.append(f"  error: {truncate(e.error)}")

    if e.primitives:
        prim_strs = [f"{k}: {v['r']}r/{v['w']}w" for k, v in e.primitives.items()]
        lines.append(f"  {', '.join(prim_strs)}")

    return lines


@space_command(app, "spawn session history", name="history")
def history_cmd(
    cli_ctx: typer.Context,
    identity: str | None = typer.Argument(None, help="Agent identity"),
    since: str | None = typer.Option(None, "--since", "-s", help="Time window (e.g. 8h, 1d)"),
    limit: int = typer.Option(10, "--limit", "-n", help="Max entries"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    since_iso: str | None = None
    if since:
        try:
            delta = format.parse_duration(since)
        except ValueError:
            typer.echo(f"Invalid duration: {since}", err=True)
            raise typer.Exit(1) from None
        since_iso = (datetime.now(UTC) - delta).isoformat()

    agent_id = None
    if identity:
        agent = store.resolve(identity, "agents", Agent)
        agent_id = agent.id

    entries = spawns.log(
        agent_id=agent_id,
        since=since_iso,
        limit=limit,
    )

    if json_output:
        data = [
            {
                "id": e.id,
                "agent": e.agent_identity,
                "status": e.status,
                "created_at": e.created_at,
                "last_active_at": e.last_active_at,
                "duration_seconds": e.duration_seconds,
                "summary": e.summary,
                "error": e.error,
                "primitives": e.primitives,
            }
            for e in entries
        ]
        typer.echo(json.dumps(data, indent=2))
        return

    if not entries:
        msg = "No spawns"
        if since:
            msg += f" in last {since}"
        output.echo_text(f"{msg}.", cli_ctx)
        return

    for e in entries:
        for line in _format_log_entry(e):
            output.echo_text(line, cli_ctx)
        output.echo_text("", cli_ctx)


@space_command(app, "show spawn trace", name="trace")
def trace_cmd(
    cli_ctx: typer.Context,
    spawn_id: str,
    limit: int = typer.Option(100, "--limit", "-n", help="Max events"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    spawn = store.resolve(spawn_id, "spawns", Spawn)
    page = spawns.read_events(spawn.id, limit=limit)

    if json_output:
        typer.echo(json.dumps(page.events, indent=2))
        return

    if not page.events:
        output.echo_text("No trace events.", cli_ctx)
        return

    for event in page.events:
        line = spawns.format_event(event)
        if line:
            output.echo_text(line, cli_ctx)

    if page.has_more:
        output.echo_text(f"... +{page.total - limit} more events", cli_ctx)


@space_command(app, "extract spawn scenario", name="extract")
def extract_cmd(
    cli_ctx: typer.Context,
    spawn_id: str,
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    context_only: bool = typer.Option(False, "--context", "-c", help="Only output context"),
):
    """Extract the original prompt/context from a spawn transcript."""
    spawn = store.resolve(spawn_id, "spawns", Spawn)
    scenario = spawns.extract_scenario(spawn.id)

    if not scenario:
        output.echo_text("No scenario found (missing transcript or context_init event).", cli_ctx)
        raise typer.Exit(1)

    if context_only:
        typer.echo(scenario.context or "")
        return

    if json_output:
        data = {
            "spawn_id": spawn.id,
            "context": scenario.context,
            "context_case": scenario.context_case,
            "model": scenario.model,
            "tools": scenario.tools,
            "session_id": scenario.session_id,
        }
        typer.echo(json.dumps(data, indent=2))
        return

    output.echo_text(f"Spawn: {spawn.id[:8]}", cli_ctx)
    output.echo_text(f"Model: {scenario.model}", cli_ctx)
    output.echo_text(f"Context case: {scenario.context_case}", cli_ctx)
    output.echo_text(f"Tools: {len(scenario.tools)}", cli_ctx)
    output.echo_text("", cli_ctx)
    output.echo_text("--- Context ---", cli_ctx)
    typer.echo(scenario.context or "")


@space_command(app, "resume spawn", name="resume")
def resume_cmd(
    cli_ctx: typer.Context,
    spawn_id: str,
    prompt: str = typer.Argument("continue", help="Prompt to send (default: continue)"),
):
    """Resume a completed spawn with existing session."""
    spawn = store.resolve(spawn_id, "spawns", Spawn)
    agent = agents.get(spawn.agent_id)

    output.echo_text(f"Resuming {spawn_id[:8]} ({agent.identity})...", cli_ctx)
    try:
        spawns.launch(agent=agent, project_id=spawn.project_id, spawn=spawn, instruction=prompt)
    except StateError as e:
        output.echo_text(str(e), cli_ctx)
        raise typer.Exit(1) from None
    output.echo_text(f"Resumed: {spawn_id[:8]}", cli_ctx)


@space_command(app, "stop spawn", name="stop", aliases=["kill"])
def stop_cmd(cli_ctx: typer.Context, ref: str):
    spawn: Spawn | None = None
    with contextlib.suppress(NotFoundError):
        spawn = store.resolve(ref, "spawns", Spawn)

    if not spawn:
        try:
            agent = store.resolve(ref, "agents", Agent)
            active = spawns.fetch(agent_id=agent.id, status=["active"])
            if not active:
                typer.echo(f"No active spawn for: {ref}", err=True)
                raise typer.Exit(1)
            if len(active) > 1:
                typer.echo(f"Multiple active spawns for {ref}, specify spawn ID", err=True)
                raise typer.Exit(1)
            spawn = active[0]
        except NotFoundError:
            typer.echo(f"Spawn not found: {ref}", err=True)
            raise typer.Exit(1) from None

    if spawn.status != SpawnStatus.ACTIVE:
        output.echo_text(f"Spawn already {spawn.status}", cli_ctx)
        return

    spawns.terminate(spawn.id)
    output.echo_text(f"Stopped: {spawn.id[:8]}", cli_ctx)


@space_command(app, "swarm spawn", name="swarm")
def swarm_cmd(
    cli_ctx: typer.Context,
    identity: str = typer.Argument(..., help="Agent identity"),
    timeout: int = typer.Option(3600, "--timeout", "-t", help="Timeout in seconds"),
):
    """Launch swarm spawn (daemon mode)."""
    agent, project = _resolve_agent_and_project(identity)
    spawn = spawns.launch(
        agent=agent,
        project_id=project.id,
        source=SpawnSource.SWARM,
        timeout_seconds=timeout,
    )
    output.echo_text(f"Spawned: {spawn.id[:8]} ({agent.identity})", cli_ctx)


@space_command(app, "fire-and-forget spawn", name="run")
def run_cmd(
    cli_ctx: typer.Context,
    identity: str = typer.Argument(..., help="Agent identity"),
    instruction: str = typer.Argument(..., help="What to do"),
    timeout: int = typer.Option(3600, "--timeout", "-t", help="Timeout in seconds"),
):
    """Launch directed spawn with instruction."""
    agent, project = _resolve_agent_and_project(identity)
    spawn = spawns.launch(
        agent=agent,
        project_id=project.id,
        instruction=instruction,
        source=SpawnSource.MANUAL,
        timeout_seconds=timeout,
    )
    output.echo_text(f"Spawned: {spawn.id[:8]} ({agent.identity})", cli_ctx)


@space_command(app, "launch batch of spawns", name="batch")
def batch_cmd(
    cli_ctx: typer.Context,
    identities: list[str] = typer.Argument(..., help="Agent identities"),  # noqa: B008
    instruction: str | None = typer.Option(None, "--instruction", help="Instruction for all"),
    timeout: int = typer.Option(3600, "--timeout", "-t", help="Timeout in seconds"),
    notify: bool = typer.Option(
        True, "--notify/--no-notify", "-n/-N", help="Push on batch complete"
    ),
):
    """Launch multiple spawns with optional notification on batch completion."""
    project = projects.infer_from_cwd()
    if not project:
        typer.echo("No project found in current directory", err=True)
        raise typer.Exit(1)

    spawn_ids: list[str] = []
    for identity in identities:
        agent = store.resolve(identity, "agents", Agent)
        if not agent.model:
            typer.echo(f"Agent {identity} has no model configured", err=True)
            continue
        spawn = spawns.launch(
            agent=agent,
            project_id=project.id,
            instruction=instruction,
            source=SpawnSource.MANUAL if instruction else SpawnSource.SWARM,
            timeout_seconds=timeout,
        )
        spawn_ids.append(spawn.id)
        output.echo_text(f"Spawned: {spawn.id[:8]} ({agent.identity})", cli_ctx)

    if spawn_ids and notify:
        batch_id = hooks.create_batch(spawn_ids, notify=True)
        output.echo_text(f"Batch: {batch_id} ({len(spawn_ids)} spawns)", cli_ctx)


@space_command(app, "replay spawn with different constitution", name="replay")
def replay_cmd(
    cli_ctx: typer.Context,
    spawn_id: str = typer.Argument(..., help="Spawn to replay"),
    target: str = typer.Option(..., "--as", "-a", help="Target agent identity"),
    dry_run: bool = typer.Option(False, "--dry-run", "-n", help="Show modified context only"),
    timeout: int = typer.Option(300, "--timeout", "-t", help="Timeout in seconds"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """Replay a spawn scenario with a different agent's constitution."""
    spawn = store.resolve(spawn_id, "spawns", Spawn)
    result = spawns.replay_scenario(
        spawn.id,
        target,
        dry_run=dry_run,
        timeout_seconds=timeout,
    )

    if isinstance(result, str):
        if dry_run:
            typer.echo(result)
            return
        typer.echo(result, err=True)
        raise typer.Exit(1)

    if json_output:
        data = {
            "spawn_id": result.spawn_id,
            "original_identity": result.original_identity,
            "replay_identity": result.replay_identity,
            "model": result.model,
            "output": result.output,
            "exit_code": result.exit_code,
        }
        typer.echo(json.dumps(data, indent=2))
        return

    output.echo_text(f"Replay: {result.spawn_id[:8]}", cli_ctx)
    output.echo_text(
        f"Original: {result.original_identity} → Replay: {result.replay_identity}", cli_ctx
    )
    output.echo_text(f"Model: {result.model}", cli_ctx)
    output.echo_text(f"Exit: {result.exit_code}", cli_ctx)
    output.echo_text("", cli_ctx)
    output.echo_text("--- Output ---", cli_ctx)
    typer.echo(result.output)


def main() -> None:
    app()
