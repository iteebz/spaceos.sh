from datetime import UTC, datetime, timedelta
from typing import Annotated

import typer

from space.cli.utils import output
from space.cli.utils.decorators import requires
from space.core.models import Project
from space.lib.commands import space_app, space_command
from space.lib.format import truncate
from space.os import search

app = space_app("search", purpose="query all primitives", injected=True, role="agents")


def _parse_date(date_str: str) -> str:
    try:
        dt = datetime.fromisoformat(date_str)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
        return dt.isoformat()
    except ValueError as e:
        raise typer.BadParameter(
            f"Invalid date format: {date_str}. Use ISO format (YYYY-MM-DD)"
        ) from e


def _recent_to_after(days: int) -> str:
    dt = datetime.now(UTC) - timedelta(days=days)
    return dt.isoformat()


def _format_result(result: search.SearchResult, verbose: bool = False) -> str:
    lines = []
    source_tag = f"[{result.source}]"
    ref = result.reference

    content = result.content.replace("\n", " ").strip()
    if not verbose:
        content = truncate(content, 200)

    lines.append(f"{source_tag} {ref}")
    lines.append(f"  {content}")

    if verbose and result.metadata:
        meta_parts = [f"{k}={v}" for k, v in result.metadata.items() if v]
        if meta_parts:
            lines.append(f"  ({', '.join(meta_parts)})")

    return "\n".join(lines)


@space_command(app, "search primitives", injected=True, usage="search")
@requires("project?")
def search_cmd(
    cli_ctx: typer.Context,
    project: Project | None,
    query: Annotated[str, typer.Argument(help="Query to search")],
    scope: Annotated[
        str,
        typer.Option(
            "--scope",
            help="Scope: spawns|messages|insights|decisions|tasks|all",
        ),
    ] = "all",
    after: Annotated[
        str | None, typer.Option("--after", help="Filter after date (ISO format)")
    ] = None,
    before: Annotated[
        str | None, typer.Option("--before", help="Filter before date (ISO format)")
    ] = None,
    recent: Annotated[int | None, typer.Option("--recent", help="Filter to last N days")] = None,
    limit: Annotated[int, typer.Option("--limit", "-n", help="Max results")] = 20,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show metadata")] = False,
    json_output: Annotated[bool, typer.Option("--json", "-j", help="JSON output")] = False,
) -> None:
    """Search all context sources.

    Examples:
      search "auth"                  # Search everything
      search "config" --scope canon  # Canon only
      search "bug" --recent 7        # Last 7 days
    """
    valid_scopes = ("all", *search.SOURCES)
    if scope not in valid_scopes:
        typer.echo(f"Error: Invalid scope '{scope}'. Use: {', '.join(valid_scopes)}")
        raise typer.Exit(1)

    if recent and after:
        typer.echo("Error: Cannot use both --recent and --after")
        raise typer.Exit(1)

    after_iso = _recent_to_after(recent) if recent else (_parse_date(after) if after else None)
    before_iso = _parse_date(before) if before else None

    results = search.query(
        query,
        scope=scope,
        after=after_iso,
        before=before_iso,
        limit=limit,
        project_id=project.id if project else None,
    )

    if json_output:
        data = [
            {
                "source": r.source,
                "content": r.content,
                "reference": r.reference,
                "timestamp": r.timestamp,
                "weight": r.weight,
                "metadata": r.metadata,
            }
            for r in results
        ]
        typer.echo(output.out_json({"query": query, "scope": scope, "results": data}))
        return

    if not results:
        typer.echo(f"No results for '{query}'")
        return

    typer.echo(f"Found {len(results)} results:\n")
    for result in results:
        typer.echo(_format_result(result, verbose))
        typer.echo()


def main() -> None:
    app()


if __name__ == "__main__":
    main()
