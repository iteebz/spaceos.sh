"""Skill reference for agents."""

import re
from pathlib import Path
from typing import Annotated

import typer

from space.lib.commands import space_app, space_command

app = space_app("skill", purpose="reference material for tasks", injected=True, role="agents")

SKILLS_DIR = Path(__file__).parent.parent.parent / "ctx" / "skills"

FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)
DESCRIPTION_RE = re.compile(r"^description:\s*(.+)$", re.MULTILINE)


def _parse_skill(path: Path) -> tuple[str, str | None]:
    """Return (name, description) for a skill file."""
    content = path.read_text()
    desc = None
    if (match := FRONTMATTER_RE.match(content)) and (
        desc_match := DESCRIPTION_RE.search(match.group(1))
    ):
        desc = desc_match.group(1).strip()
    return path.stem, desc


def _list_skills() -> list[tuple[str, str | None]]:
    if not SKILLS_DIR.exists():
        return []
    return sorted(_parse_skill(p) for p in SKILLS_DIR.glob("*.md"))


@space_command(app, "list available skills", injected=True, name="list")
def list_skills(cli_ctx: typer.Context) -> None:
    """List available skill references."""
    skills = _list_skills()
    if not skills:
        typer.echo("No skills found.")
        return
    for name, desc in skills:
        if desc:
            typer.echo(f"  {name}: {desc}")
        else:
            typer.echo(f"  {name}")


@space_command(app, "show skill content", injected=True, name="show")
def show_skill(
    cli_ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Skill name")],
) -> None:
    """Show skill reference content."""
    skills = _list_skills()
    names = [n for n, _ in skills]
    if name not in names:
        typer.echo(f"Unknown skill: {name}")
        typer.echo(f"Available: {', '.join(names)}")
        raise typer.Exit(1)

    path = SKILLS_DIR / f"{name}.md"
    typer.echo(path.read_text())


def main() -> None:
    app()


if __name__ == "__main__":
    main()
