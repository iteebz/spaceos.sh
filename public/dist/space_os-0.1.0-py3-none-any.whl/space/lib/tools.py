"""Canonical tool taxonomy with provider mappings.

Defines a cross-provider tool abstraction. Constitutions declare allowed
capabilities; we compute provider-specific deny lists at spawn time.
"""

from enum import StrEnum


class Tool(StrEnum):
    SHELL = "shell"
    WRITE = "write"
    EDIT = "edit"
    READ = "read"
    LS = "ls"
    GLOB = "glob"
    GREP = "grep"
    FETCH = "fetch"
    SEARCH = "search"


ALL_TOOLS = frozenset(Tool)

PROVIDER_TOOLS: dict[str, dict[Tool, list[str]]] = {
    "claude": {
        Tool.SHELL: ["Bash"],
        Tool.WRITE: ["Write"],
        Tool.EDIT: ["Edit", "MultiEdit"],
        Tool.READ: ["Read"],
        Tool.LS: ["LS"],
        Tool.GLOB: ["Glob"],
        Tool.GREP: ["Grep"],
        Tool.FETCH: ["WebFetch"],
        Tool.SEARCH: ["WebSearch"],
    },
    "gemini": {
        Tool.SHELL: ["run_shell_command"],
        Tool.WRITE: ["write_file"],
        Tool.EDIT: ["replace"],
        Tool.READ: ["read_file"],
        Tool.LS: ["list_directory"],
        Tool.GLOB: ["glob"],
        Tool.GREP: ["search_file_content"],
        Tool.FETCH: ["web_fetch"],
        Tool.SEARCH: ["google_web_search"],
    },
    "codex": {
        Tool.SHELL: ["shell"],
        Tool.WRITE: ["shell"],
        Tool.EDIT: ["shell"],
        Tool.READ: ["shell"],
        Tool.LS: ["shell"],
        Tool.GLOB: ["shell"],
        Tool.GREP: ["shell"],
    },
}

ALWAYS_DISALLOWED: dict[str, list[str]] = {
    "claude": ["NotebookRead", "NotebookEdit", "Task", "TodoWrite"],
    "gemini": [],
    "codex": [],
}


def all_provider_tools(provider: str) -> set[str]:
    """Get all tool names for a provider."""
    mapping = PROVIDER_TOOLS.get(provider, {})
    return {tool for tools in mapping.values() for tool in tools}


def disallowed_for(provider: str, allowed: set[Tool] | None = None) -> list[str]:
    """Compute provider-specific deny list from allowed capabilities.

    If allowed is None, returns only the always-disallowed tools.
    """
    base_disallowed = set(ALWAYS_DISALLOWED.get(provider, []))

    if allowed is None:
        return sorted(base_disallowed)

    mapping = PROVIDER_TOOLS.get(provider, {})
    all_tools = all_provider_tools(provider)
    allowed_tools = {t for cap in allowed for t in mapping.get(cap, [])}

    return sorted(base_disallowed | (all_tools - allowed_tools))


def allowed_for(provider: str, allowed: set[Tool] | None = None) -> list[str]:
    """Compute provider-specific allow list from capabilities.

    Used for providers that support --allowed-tools (gemini).
    """
    if allowed is None:
        mapping = PROVIDER_TOOLS.get(provider, {})
        return sorted({t for tools in mapping.values() for t in tools})

    mapping = PROVIDER_TOOLS.get(provider, {})
    return sorted({t for cap in allowed for t in mapping.get(cap, [])})


def parse_tools(tools_list: list[str] | None) -> set[Tool] | None:
    """Parse tool strings from constitution frontmatter."""
    if tools_list is None:
        return None
    result = set()
    for t in tools_list:
        try:
            result.add(Tool(t.lower()))
        except ValueError:
            continue
    return result if result else None
