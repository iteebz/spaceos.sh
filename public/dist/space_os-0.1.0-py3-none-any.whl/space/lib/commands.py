"""Unified CLI command registry. Single source of truth for agent-facing commands."""

from collections.abc import Callable
from dataclasses import dataclass, field
from functools import wraps
from typing import Any, Literal

import typer

from space.core.errors import ReferenceError, SpaceError

Role = Literal["agents", "humans", "system"]

SPACE_APP_ATTR = "_space_name"


@dataclass
class Command:
    name: str
    parent: str
    usage: str
    purpose: str
    injected: bool = False
    aliases: list[str] = field(default_factory=list)


@dataclass
class Group:
    name: str
    purpose: str
    injected: bool = False
    role: Role | None = None
    commands: dict[str, Command] = field(default_factory=dict)


registry: dict[str, Group] = {}


CONTEXT_SETTINGS = {
    "help_option_names": ["-h", "--help"],
    "allow_interspersed_args": False,
}


def space_app(
    name: str,
    *,
    purpose: str,
    injected: bool = False,
    role: Role | None = None,
) -> typer.Typer:
    """Create and register a Space CLI group."""
    registry[name] = Group(name=name, purpose=purpose, injected=injected, role=role)
    app = typer.Typer(
        help=purpose,
        context_settings=CONTEXT_SETTINGS,
        no_args_is_help=True,
        add_completion=False,
        rich_markup_mode=None,
    )
    setattr(app, SPACE_APP_ATTR, name)
    return app


def space_command(
    app: typer.Typer,
    purpose: str,
    *,
    injected: bool = False,
    name: str | None = None,
    usage: str | None = None,
    aliases: list[str] | None = None,
    hidden: bool = False,
):
    """Register a Space CLI command under a group.

    Infers from context:
        - name: from function name
        - parent: from app (set by space_app)
        - usage: "{parent} {name}" (override for custom)
    """

    def decorator[F: Callable[..., Any]](f: F) -> F:
        cmd_name = name or f.__name__
        parent = getattr(app, SPACE_APP_ATTR, None)
        if not parent:
            raise ValueError(f"App missing {SPACE_APP_ATTR} - use space_app() to create")

        cmd_usage = usage or f"{parent} {cmd_name}"

        if parent not in registry:
            registry[parent] = Group(name=parent, purpose="", injected=False)

        registry[parent].commands[cmd_name] = Command(
            name=cmd_name,
            parent=parent,
            usage=cmd_usage,
            purpose=purpose,
            injected=injected,
            aliases=aliases or [],
        )

        @wraps(f)
        def _wrapped(*args: Any, **kwargs: Any):
            try:
                return f(*args, **kwargs)
            except ReferenceError as e:
                typer.echo(str(e), err=True)
                raise typer.Exit(1) from None
            except SpaceError as e:
                typer.echo(str(e), err=True)
                raise typer.Exit(1) from None

        app.command(name=cmd_name, help=purpose, hidden=hidden)(_wrapped)
        for alias in aliases or []:
            app.command(name=alias, hidden=True)(_wrapped)

        return f

    return decorator


def load() -> None:
    """Explicit bootstrap. Call before generate()."""
    from space.cli.ops import sleep
    from space.cli.os import (
        agent,
        decision,
        email,
        identity,
        inbox,
        insight,
        search,
        skill,
        spawn,
        task,
    )

    del agent, decision, email, identity, inbox, insight, search, skill, spawn, task, sleep

    registry["project"] = Group(
        name="project", purpose="repository binding", injected=False, role="agents"
    )
    registry["health"] = Group(
        name="health", purpose="database diagnostics", injected=False, role="system"
    )
    registry["backup"] = Group(name="backup", purpose="snapshots", injected=False, role="system")
    registry["launch"] = Group(name="launch", purpose="start server", injected=False, role="humans")


def generate(
    level: str = "commands",
    parent: str | None = None,
    injected_only: bool = True,
) -> str:
    """Generate command documentation."""
    if level == "groups":
        groups = registry.values()
        if injected_only:
            groups = [g for g in groups if g.injected]
        return "\n".join(f"- `{g.name}` — {g.purpose}" for g in groups)

    commands = []
    for group in registry.values():
        if parent and group.name != parent:
            continue
        for cmd in group.commands.values():
            if injected_only and not cmd.injected:
                continue
            commands.append(cmd)

    return "\n".join(f"- `{c.usage}` — {c.purpose}" for c in commands)


def render(parent: str | None = None, injected_only: bool = False) -> str:
    """Render command tree for CLI display."""
    load()
    lines = []

    groups = sorted(registry.values(), key=lambda g: g.name)
    if injected_only:
        groups = [g for g in groups if g.injected]

    for group in groups:
        if parent and group.name != parent:
            continue

        cmds = sorted(group.commands.values(), key=lambda c: c.name)
        if injected_only:
            cmds = [c for c in cmds if c.injected]
        if not cmds:
            continue

        tag = " [agent]" if group.injected else ""
        lines.append(f"{group.name}{tag}")
        for cmd in cmds:
            alias_str = f" ({', '.join(cmd.aliases)})" if cmd.aliases else ""
            inj = " *" if cmd.injected else ""
            lines.append(f"  {cmd.name}{alias_str}{inj} — {cmd.purpose}")

    return "\n".join(lines)


def primitives() -> str:
    """Generate PRIMITIVES help text from registry, grouped by role."""
    load()

    by_role: dict[str, list[Group]] = {"agents": [], "humans": [], "system": []}

    for group in registry.values():
        if group.role:
            by_role[group.role].append(group)

    lines = []
    titles = {"agents": "Agents:", "humans": "Humans:", "system": "System:"}

    for role in ["agents", "humans", "system"]:
        groups = sorted(by_role[role], key=lambda g: g.name)
        if not groups:
            continue
        if lines:
            lines.append("")
        lines.append(titles[role])
        lines.extend(f"  {g.name:<10} — {g.purpose}" for g in groups)

    return "\n".join(lines)
