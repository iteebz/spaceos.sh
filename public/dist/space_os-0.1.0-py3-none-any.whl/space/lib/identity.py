"""Identity resolution from environment.

Pure utilities only - no domain imports.
"""

import os

from space.core.types import AgentId


def resolve(explicit: str | None) -> AgentId | None:
    if val := explicit or os.environ.get("SPACE_IDENTITY"):
        return AgentId(val)
    return None


def current() -> AgentId | None:
    if val := os.environ.get("SPACE_IDENTITY"):
        return AgentId(val)
    return None
