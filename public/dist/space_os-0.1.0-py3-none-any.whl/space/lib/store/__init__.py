"""Database connection management and utilities."""

from space.lib.store.connection import (
    ARCHIVABLE_TABLES,
    Row,
    _reset_for_testing,
    close_all,
    database_exists,
    ensure,
    from_row,
    set_test_db_path,
    transaction,
    unarchive,
    write,
)
from space.lib.store.health import (
    check_backup_has_data,
    compare_snapshots,
    get_backup_stats,
    repair_fts_if_needed,
)
from space.lib.store.resolve import resolve
from space.lib.store.sqlite import checkpoint_wal, connect, fts_search, fts_tokenize, placeholders

__all__ = [
    "ARCHIVABLE_TABLES",
    "Row",
    "_reset_for_testing",
    "check_backup_has_data",
    "checkpoint_wal",
    "close_all",
    "compare_snapshots",
    "connect",
    "database_exists",
    "ensure",
    "from_row",
    "fts_search",
    "fts_tokenize",
    "get_backup_stats",
    "placeholders",
    "repair_fts_if_needed",
    "resolve",
    "set_test_db_path",
    "transaction",
    "unarchive",
    "write",
]
