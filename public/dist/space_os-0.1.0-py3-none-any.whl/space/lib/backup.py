import logging
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

from space.lib import config, paths, state

logger = logging.getLogger(__name__)


def _sqlite_backup(src_path: Path, dst_path: Path) -> None:
    src_conn = sqlite3.connect(src_path, timeout=30)
    dst_conn = sqlite3.connect(dst_path)
    try:
        src_conn.backup(dst_conn)
    finally:
        dst_conn.close()
        src_conn.close()


def _backup_data_snapshot(timestamp: str) -> dict[str, Any]:
    src = paths.dot_space()
    if not src.exists():
        return {}

    backup_path = Path.home() / ".space_backups" / "data" / timestamp
    backup_path.parent.mkdir(parents=True, exist_ok=True)
    backup_path.mkdir(parents=True, exist_ok=True)

    for db_file in sorted(src.glob("*.db")):
        dst_file = backup_path / db_file.name
        try:
            _sqlite_backup(db_file, dst_file)
        except sqlite3.Error as e:
            logger.error(f"Failed to backup {db_file.name}: {e}")
            if dst_file.exists():
                dst_file.unlink()

    stats = _get_backup_stats(backup_path)

    for db_file in backup_path.glob("*.db"):
        try:
            with sqlite3.connect(str(db_file), timeout=2) as conn:
                result = conn.execute("PRAGMA integrity_check").fetchone()[0]
                if result != "ok":
                    logger.error(f"Backup integrity check failed for {db_file.name}: {result}")
        except Exception as e:
            logger.error(f"Failed to verify backup {db_file.name}: {e}")

    Path(backup_path).chmod(0o555)

    return stats


def _backup_spawns() -> dict[str, int]:
    src = paths.dot_space() / "spawns"
    backup_path = Path.home() / ".space_backups" / "spawns"

    if not src.exists():
        return {"total": 0, "new": 0}

    backup_path.parent.mkdir(parents=True, exist_ok=True)

    existing: set[Path] = set()
    if backup_path.exists():
        existing = {f.relative_to(backup_path) for f in backup_path.rglob("*") if f.is_file()}
        Path(backup_path).chmod(0o755)
        for item in backup_path.rglob("*"):
            Path(item).chmod(0o755 if item.is_dir() else 0o644)
        shutil.rmtree(backup_path)

    total = 0
    new = 0
    backup_path.mkdir()
    for item in src.iterdir():
        if item.is_file():
            shutil.copy2(item, backup_path / item.name)
            rel = Path(item.name)
            total += 1
            if rel not in existing:
                new += 1
        elif item.is_dir():
            dest_dir = backup_path / item.name
            shutil.copytree(item, dest_dir)
            for f in dest_dir.rglob("*"):
                if f.is_file():
                    total += 1
                    rel = f.relative_to(backup_path)
                    if rel not in existing:
                        new += 1

    Path(backup_path).chmod(0o555)

    return {"total": total, "new": new}


def _is_core_table(name: str) -> bool:
    return not ("_fts" in name or name.startswith("fts_"))


def _get_backup_stats(backup_path: Path) -> dict[str, Any]:
    stats: dict[str, Any] = {}
    for db_file in backup_path.glob("*.db"):
        try:
            db_file.chmod(0o644)
            with sqlite3.connect(str(db_file), timeout=2, check_same_thread=False) as conn:
                tables = [
                    r[0]
                    for r in conn.execute(
                        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
                    )
                    if _is_core_table(r[0])
                ]
                table_counts = {}
                total = 0
                for table in tables:
                    try:
                        count = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]  # noqa: S608
                        table_counts[table] = count
                        total += count
                    except sqlite3.OperationalError:
                        pass

                stats[db_file.name] = {
                    "tables": len(table_counts),
                    "rows": total,
                    "by_table": table_counts,
                }
        except sqlite3.DatabaseError:
            stats[db_file.name] = {"tables": 0, "rows": 0, "by_table": {}}

    return stats


def _get_previous_backup() -> Path | None:
    data_dir = Path.home() / ".space_backups" / "data"
    if not data_dir.exists():
        return None
    snapshots = sorted(data_dir.iterdir(), reverse=True)
    return snapshots[0] if snapshots else None


def _calculate_row_delta(
    current_stats: dict[str, Any], previous_path: Path | None
) -> dict[str, Any]:
    if not previous_path or not previous_path.exists():
        return {db: {"total": None, "by_table": {}} for db in current_stats}

    previous_stats = _get_backup_stats(previous_path)
    deltas: dict[str, Any] = {}
    for db, info in current_stats.items():
        prev_info = previous_stats.get(db, {})
        prev_total = prev_info.get("rows", 0)
        prev_by_table = prev_info.get("by_table", {})

        table_deltas = {}
        for table, count in info.get("by_table", {}).items():
            delta = count - prev_by_table.get(table, 0)
            if delta != 0:
                table_deltas[table] = delta

        deltas[db] = {
            "total": info["rows"] - prev_total,
            "by_table": table_deltas,
        }
    return deltas


def _read_counter() -> int:
    return state.get("backup_counter", 0)


def _write_counter(n: int) -> None:
    state.set("backup_counter", n)


def on_spawn_complete() -> dict[str, Any] | None:
    cfg = config.load()
    threshold = cfg.backup.spawns_per_backup
    count = _read_counter() + 1
    if count >= threshold:
        _write_counter(0)
        return execute()
    _write_counter(count)
    return None


def execute() -> dict[str, Any]:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    previous_backup = _get_previous_backup()
    data_stats = _backup_data_snapshot(timestamp)
    row_deltas = _calculate_row_delta(data_stats, previous_backup)
    spawns_stats = _backup_spawns()

    return {
        "timestamp": timestamp,
        "data_stats": data_stats,
        "row_deltas": row_deltas,
        "spawns_stats": spawns_stats,
    }
