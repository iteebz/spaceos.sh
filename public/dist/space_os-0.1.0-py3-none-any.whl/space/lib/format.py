import re
from datetime import UTC, datetime, timedelta

from space.core.models import Agent

MINUTE = 60
HOUR = 3600
DAY = 86400
WEEK = 604800
MONTH = 2592000
YEAR = 31536000


def age_seconds(seconds: int | float | None) -> str:
    if seconds is None:
        return "never"
    if seconds < MINUTE:
        return "now" if seconds < 10 else f"{int(seconds)}s"
    if seconds < HOUR:
        return f"{int(seconds / MINUTE)}m"
    if seconds < DAY:
        return f"{int(seconds / HOUR)}h"
    if seconds < WEEK:
        return f"{int(seconds / DAY)}d"
    if seconds < MONTH:
        return f"{int(seconds / WEEK)}w"
    if seconds < YEAR:
        return f"{int(seconds / MONTH)}mo"
    return f"{int(seconds / YEAR)}y"


def ago(timestamp_str: str | None) -> str:
    if not timestamp_str:
        return "-"
    try:
        timestamp = datetime.fromisoformat(str(timestamp_str))
    except (ValueError, TypeError):
        return "-"

    if timestamp.tzinfo is None:
        timestamp = timestamp.replace(tzinfo=UTC)

    now = datetime.now(UTC)
    diff = now - timestamp
    return age_seconds(diff.total_seconds())


def duration(t1: str | datetime, t2: str | datetime | None = None) -> str:
    def to_dt(t: str | datetime) -> datetime:
        if isinstance(t, str):
            dt = datetime.fromisoformat(t)
        else:
            dt = t
        return dt.replace(tzinfo=UTC) if dt.tzinfo is None else dt

    dt1 = to_dt(t1)
    dt2 = to_dt(t2) if t2 else datetime.now(UTC)
    seconds = abs((dt2 - dt1).total_seconds())
    return format_duration(seconds)


def format_duration(seconds: float) -> str:
    if seconds < MINUTE:
        return f"{int(seconds)}s"
    if seconds < HOUR:
        return f"{int(seconds / MINUTE)}m"
    if seconds < DAY:
        hours = int(seconds / HOUR)
        mins = int((seconds % HOUR) / MINUTE)
        return f"{hours}h {mins}m" if mins else f"{hours}h"
    days = int(seconds / DAY)
    hours = int((seconds % DAY) / HOUR)
    return f"{days}d {hours}h" if hours else f"{days}d"


def parse_duration(spec: str) -> timedelta:
    """Parse duration like '30m', '2h', '1d', '2w', '2h30m'."""
    spec = (spec or "").strip().lower()
    if not spec:
        raise ValueError("duration required")

    pattern = r"^(?:(\d+)w)?(?:(\d+)d)?(?:(\d+)h)?(?:(\d+)m)?$"
    match = re.match(pattern, spec)
    if not match or not any(match.groups()):
        raise ValueError(f"invalid duration: {spec}")

    weeks = int(match.group(1) or 0)
    days = int(match.group(2) or 0)
    hours = int(match.group(3) or 0)
    minutes = int(match.group(4) or 0)

    return timedelta(weeks=weeks, days=days, hours=hours, minutes=minutes)


def agent_name(agent: Agent | None, fallback: str = "unknown") -> str:
    """Format agent name with type suffix."""
    if not agent:
        return fallback
    suffix = "(human)" if agent.type == "human" else "(ai)"
    return f"{agent.identity}{suffix}"


def truncate(text: str, length: int = 70, suffix: str = "...") -> str:
    """Truncate text with ellipsis if exceeds length."""
    if len(text) <= length:
        return text
    return text[: length - len(suffix)] + suffix
