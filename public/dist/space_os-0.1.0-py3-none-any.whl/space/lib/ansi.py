import re

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def strip(text: str) -> str:
    return _ANSI_RE.sub("", text)


def red(text: str) -> str:
    return f"\033[31m{text}\033[0m"


def green(text: str) -> str:
    return f"\033[32m{text}\033[0m"


def yellow(text: str) -> str:
    return f"\033[33m{text}\033[0m"


def magenta(text: str) -> str:
    return f"\033[35m{text}\033[0m"


def cyan(text: str) -> str:
    return f"\033[36m{text}\033[0m"


def dim(text: str) -> str:
    return f"\033[2m{text}\033[0m"
