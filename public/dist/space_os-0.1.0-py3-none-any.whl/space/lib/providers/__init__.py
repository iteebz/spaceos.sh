from types import ModuleType

from space.core.errors import NotFoundError

from . import claude, codex, gemini
from .models import MODELS, map
from .models import is_valid as is_valid_model
from .types import Provider, ProviderName, UsageStats

PROVIDER_NAMES: tuple[ProviderName, ...] = ("claude", "codex", "gemini")

__all__ = [
    "MODELS",
    "PROVIDER_NAMES",
    "Provider",
    "UsageStats",
    "claude",
    "codex",
    "gemini",
    "get_provider",
    "is_valid_model",
    "map",
]

_PROVIDERS: dict[ProviderName, ModuleType] = {
    "claude": claude,
    "codex": codex,
    "gemini": gemini,
}


def get_provider(name: ProviderName) -> ModuleType:
    provider = _PROVIDERS.get(name)
    if provider is None:
        raise NotFoundError(f"Unknown provider: {name}") from None
    return provider
