from pathlib import Path
from typing import Any

from space.lib.providers.types import ProviderEvent, UsageStats
from space.lib.tools import Tool, allowed_for

from . import base

TOOL_NAME_MAP = {
    "Shell": "Bash",
    "WriteFile": "Write",
    "ReadFile": "Read",
    "ReadManyFiles": "Read",
    "ReadFolder": "LS",
    "FindFiles": "Glob",
    "SearchText": "Grep",
}


def launch_args(allowed_tools: set[Tool] | None = None, has_prompt: bool = False) -> list[str]:
    tools = allowed_for("gemini", allowed_tools)
    args = ["--allowed-tools", ",".join(tools)]
    if has_prompt:
        args.append("--prompt-interactive")
    return args


def task_launch_args(allowed_tools: set[Tool] | None = None) -> list[str]:
    tools = allowed_for("gemini", allowed_tools)
    return ["--yolo", "--allowed-tools", ",".join(tools)]


def build_command(
    model: str,
    session_id: str | None,
    context: str | None,
    root_dir: str,
    cwd: str | None = None,
    allowed_tools: set[Tool] | None = None,
    images: list[str] | None = None,
) -> tuple[list[str], str | None]:
    args = ["gemini", "--output-format", "stream-json"]
    args += launch_args(allowed_tools)
    args += ["--model", model]
    args += ["--include-directories", cwd or root_dir]
    if session_id:
        args += ["--resume", session_id]
    if context:
        args.append(context)
    return args, None


def normalize_event(
    event: dict[str, Any], identity: str, tool_map: dict[str, str] | None = None
) -> ProviderEvent | None:
    msg_type = event.get("type")
    timestamp = event.get("timestamp")

    if tool_map is None:
        tool_map = {}

    if msg_type == "message":
        role = event.get("role")
        content = event.get("content", "")
        if role == "assistant" and content:
            return base.normalize_event("text", content, identity, timestamp)

    elif msg_type == "tool_use":
        tool_id = event.get("tool_id", "")
        tool_name = event.get("tool_name", "")
        params = event.get("parameters", {})

        normalized_name = TOOL_NAME_MAP.get(tool_name, tool_name)
        if tool_id and normalized_name:
            tool_map[tool_id] = normalized_name

        return base.normalize_event(
            "tool_call",
            {
                "tool_name": normalized_name,
                "input": params,
                "tool_use_id": tool_id,
            },
            identity,
            timestamp,
        )

    elif msg_type == "tool_result":
        tool_id = event.get("tool_id", "")
        status = event.get("status", "")
        output = event.get("output", "")

        if not output and "error" in event:
            output = str(event["error"])

        is_error = status == "error"

        return base.normalize_event(
            "tool_result",
            {
                "output": output,
                "is_error": is_error,
                "tool_use_id": tool_id,
            },
            identity,
            timestamp,
        )

    return None


def parse_usage(events_file: Path) -> UsageStats:
    """Parse usage from tail of file. Only needs last result event."""
    model = "unknown"
    stats = {}

    for event in base.iter_jsonl_tail(events_file, label="gemini.parse_usage", max_lines=20):
        if (not model or model == "unknown") and event.get("model"):
            model = event["model"]
        if event.get("type") == "result" and "stats" in event and not stats:
            stats = event["stats"]
        if stats and model != "unknown":
            break

    return UsageStats(
        stats.get("input_tokens", 0),
        stats.get("output_tokens", 0),
        0,
        0,
        model,
    )


def context_limit(model: str) -> int:
    return 1000000
