"""Codex provider.

Normalize stdout events and supply launch arguments.
"""

from pathlib import Path
from typing import Any

from space.lib.providers.types import ProviderEvent, UsageStats
from space.lib.tools import Tool

from . import base


def launch_args() -> list[str]:
    """Return launch arguments for headless Codex execution."""
    return ["--json", "--dangerously-bypass-approvals-and-sandbox", "--skip-git-repo-check"]


task_launch_args = launch_args


def build_command(
    model: str,
    session_id: str | None,
    context: str | None,
    root_dir: str,
    cwd: str | None = None,
    allowed_tools: set[Tool] | None = None,
    images: list[str] | None = None,
) -> tuple[list[str], str | None]:
    """Build Codex CLI launch command."""
    args = ["codex", "exec", *launch_args(), "--model", model]
    if session_id:
        args += ["resume", session_id, "-"]
    else:
        args += ["-"]
    return args, context


def normalize_event(
    event: dict[str, Any], identity: str, tool_map: dict[str, str] | None = None
) -> ProviderEvent | None:
    """Normalize Codex event to unified display format."""
    timestamp = event.get("timestamp")
    event_type = event.get("type")
    item = event.get("item", {})
    item_type = item.get("type")

    if tool_map is None:
        tool_map = {}

    if event_type == "item.started" and item_type == "command_execution":
        item_id = item.get("id", "")
        command = item.get("command", "")
        tool_map[item_id] = "Bash"

        return base.normalize_event(
            "tool_call",
            {
                "tool_name": "Bash",
                "input": {"command": command},
                "tool_use_id": item_id,
            },
            identity,
            timestamp,
        )

    if event_type == "item.completed" and item_type == "command_execution":
        item_id = item.get("id", "")
        output = item.get("aggregated_output", "")
        exit_code = item.get("exit_code", 0)
        is_error = exit_code != 0

        return base.normalize_event(
            "tool_result",
            {
                "output": output,
                "is_error": is_error,
                "tool_use_id": item_id,
            },
            identity,
            timestamp,
        )

    if event_type == "item.completed" and item_type == "reasoning":
        text = item.get("text", "")
        if text:
            return base.normalize_event("text", text, identity, timestamp)

    return None


def parse_usage(events_file: Path) -> UsageStats:
    """Parse usage from tail of file. Only needs last turn.completed event."""
    model = "unknown"
    usage = {}

    for event in base.iter_jsonl_tail(events_file, label="codex.parse_usage", max_lines=20):
        if (not model or model == "unknown") and event.get("model"):
            model = event["model"]
        if event.get("type") == "turn.completed" and "usage" in event and not usage:
            usage = event["usage"]
        if usage and model != "unknown":
            break

    return UsageStats(
        usage.get("input_tokens", 0),
        usage.get("output_tokens", 0),
        usage.get("cached_input_tokens", 0),
        0,
        model,
    )


def context_limit(model: str) -> int:
    """Return context window size for Codex models."""
    return 272000
