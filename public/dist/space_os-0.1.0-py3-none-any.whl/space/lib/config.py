"""Unified config: ~/.space/config.yaml"""

from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Any

import yaml

from space.lib import paths


@dataclass
class BackupConfig:
    spawns_per_backup: int = 5


@dataclass
class EmailConfig:
    api_key: str | None = None
    from_addr: str = "hello@spaceos.sh"


@dataclass
class SwarmConfig:
    enabled: bool = False
    limit: int | None = None
    enabled_at: str | None = None
    concurrency: int = 1
    force: bool = False
    agents: list[str] | None = None
    projects: list[str] | None = None
    non_opus_ratio: float | None = None
    non_opus_model: str | None = None


@dataclass
class Config:
    swarm: SwarmConfig = field(default_factory=SwarmConfig)
    backup: BackupConfig = field(default_factory=BackupConfig)
    email: EmailConfig = field(default_factory=EmailConfig)
    stats_json_path: str | None = None


def _config_path() -> Path:
    return paths.dot_space() / "config.yaml"


def _from_dict(data: dict[str, Any]) -> Config:
    swarm_data = data.get("swarm", {})
    backup_data = data.get("backup", {})
    email_data = data.get("email", {})
    return Config(
        swarm=SwarmConfig(
            **{k: v for k, v in swarm_data.items() if k in {f.name for f in fields(SwarmConfig)}}
        ),
        backup=BackupConfig(
            **{k: v for k, v in backup_data.items() if k in {f.name for f in fields(BackupConfig)}}
        ),
        email=EmailConfig(
            **{k: v for k, v in email_data.items() if k in {f.name for f in fields(EmailConfig)}}
        ),
        stats_json_path=data.get("stats_json_path"),
    )


def load() -> Config:
    p = _config_path()
    if not p.exists():
        return Config()
    data: dict[str, Any] = yaml.safe_load(p.read_text()) or {}
    return _from_dict(data)


def save(cfg: Config) -> None:
    p = _config_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(yaml.safe_dump(asdict(cfg), default_flow_style=False))
